<!--Login jruri che bhai-->
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    // since the username is not set in session, the user is not-logged-in
    // he is trying to access this page unauthorized
    // so let's clear all session variables and redirect him to index
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}


?>
<!--/ Login jruri che bhai-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<!--CSS LIST-->



\
  <link rel="stylesheet" href="./css/old/main-15fb9c894a3a54abf167.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />









<!--font / icon-->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<!--comman css-->
<link rel="stylesheet" href="./css/style.css">
<!--Navbar css-->
<link rel="stylesheet" href="./css/header navbar.css">
<!--Mobi Navbar css-->
<link rel="stylesheet" href="./css/mobi navbar.css">
<!--image sidder-->
<link rel="stylesheet" href="./css/image sidder.css">
<!--Selection01-->
<link rel="stylesheet" href="./css/selection01.css">
<!--image sidder-->
<link rel="stylesheet" href="./css/section01.css">
<!--image sidder-->
<link rel="stylesheet" href="./css/section02.css">
<!--image sidder-->
<link rel="stylesheet" href="./css/section03.css">

<!--/ CSS LIST-->

<link rel="manifest" href="./js/manifest.json">
    <script>
        //if browser support service worker
        if('serviceWorker' in navigator) {
          navigator.serviceWorker.register('./js/sw.js');
        };
      </script>
    <title>M home servies</title>
</head>
<body>




    <!--Navbar--><nav>
    <header class="HeaderDesktop__root--s8DyY HeaderDesktop__darkRoot--a6Gqb CityDesktop__headerContainerClas--aTY6a">
    <div class="HeaderDesktop__container--KbkCc">
      <a aria-current="page" class="HeaderDesktop__brand--VMMpj" href=""><img onclick="alert(' Login and SignIn not requied')" alt="Navlakha Home Services" class="HeaderDesktop__brandTxtImage--jAoEE" src="http://homedon.unaux.com/final/media/logo/jogf __6th ug.png"></a>
      <div class="HeaderDesktop__Menu--KIIgg">
        <ul class="HeaderDesktop__items--ypdVW">
          <li class="CityDesktop__linksClass--D1X9J"><a href="/helpcenter" target="_blank" rel="noopener">Blog</a></li>
          <li class="CityDesktop__linksClass--D1X9J"><a target="_blank" rel="noopener" style="border-bottom:2px solid #fff;height:20px" href="/helpcenter">Register as a Professional</a></li>
          <li class="CityDesktop__linksClass--D1X9J"><a href="/helpcenter">Help Center</a></li>
          <li class="CityDesktop__linksClass--D1X9J"><div class="dropdown">
  <button class="dropbtn"><?php echo $username;?></button>
  <div class="dropdown-content">
    <a href="profile.php">Profile</a>
    <a href="logout.php">Logout</a>
  </div>
</div></div></a></li>
        </ul></div></div></header><br>


<!--/ Navbar-->


    <!--Image sidder-->


    
 
<div class="slideshow-container">

<div class="mySlides fade">
  <img  src="./Header-banner/g1_983hq_.png" style="width:100%">
 
</div>

<div class="mySlides fade">
  <img src="./Header-banner/n_hair_ui-op.png" style="width:100%">
 
</div>

<div class="mySlides fade">
  <img src="./Header-banner/g1_983hq_.png" style="width:100%">
  
</div>
<hr>
</div>
<br>
<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
</div>


    <!--selection01-->
    <div class="BasePreviewComponent__container--UEpbd BaseTemplate__headerFix--MkwmL"><div class="Header__container--k8uSz"><h1 class="Header__heading--as48j">home services</h1></div><div class="Grid__container--ngZmu"><div class="Grid__row--RIytp">

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="./vv/ApplianceRepair"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/category_72d18950.webp" alt="Appliance Repair" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Appliance Repair</span></a></div>

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="./vv/clean"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/category_6b1f5250.webp" alt="" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Cleaning</span></a></div>

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="./book-pc"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/1604066433584-3d7851.webp" alt="" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Pest Control</span></a></div>

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="./vv/HomeR"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/1662525927640-954478.webp" alt="" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Home Repairs</span></a></div>

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="#"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/category_6fbad370.webp" alt="" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Home Painting</span></a></div>

</div></div></div>
    <!--/ selection01-->
    <!--selection02-->
    <div class="BasePreviewComponent__container--UEpbd BaseTemplate__headerFix--MkwmL"><div class="Grid__container--ngZmu"><div class="Grid__row--RIytp">

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="./vv/ApplianceRepair"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/category_72d18950.webp" alt="Appliance Repair" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Appliance Repair</span></a></div>

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="./vv/clean"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/category_6b1f5250.webp" alt="" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Cleaning</span></a></div>

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="./book-pc"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/1604066433584-3d7851.webp" alt="" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Pest Control</span></a></div>

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="./vv/HomeR"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/1662525927640-954478.webp" alt="" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Home Repairs</span></a></div>

<div class="Grid__item--Bd1fa" style="width: 20%; max-width: 20%;"><a href="#"><div class="LazyLoadImage__imageContainer--EQxRu Grid__imageContainer--iS49C"><div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div><img class="Grid__image--Sqo4J" src="media/images/catlog/category_6fbad370.webp" alt="" itemscope="" itemprop="image"></div><span class="Grid__text--otleK">Home Painting</span></a></div>

</div>
    <!--/ selection02-->
    <!--section01-->
    <div class="BasePreviewComponent__container--UEpbd BaseTemplate__removePadding--sD6Ng">
      <div class="Header__container--k8uSz">
        <h1 class="Header__heading--as48j">new category launches</h1>
      </div>
      <div class="CategoryCollection__container--rKF7A">
        <div class="CategoryCollection__row--yrL5_">
          <div class="CategoryCollection__item--Vxstg" style="width: 100%;">
          <div class="LazyLoadImage__imageContainer--EQxRu CategoryCollection__imageContainer--wu9Ap">
            <div class="TemplateShimmer__shimmer--beZ1S TemplateShimmer__shimmerWrapper--PL76J TemplateShimmer__hidden--m4HHJ"></div>
            <img class="CategoryCollection__imageClass--G1SzQ" src="./image/" alt="" itemscope="" itemprop="image"></div>
            <p class="CategoryCollection__title--GkQ9u">RO Water Purifier</p>
          </div></div>
          
          <div class="Footer__container--NB_dq"><button onclick="location.href = 'vv.php';" class="Footer__button--GvzsW" style="border: 1px solid rgb(200, 208, 255); color: rgb(48, 79, 254); background-color: rgb(247, 248, 255);">View All Services</button></div></div>
    <!--/ section01-->
    <!--section02-->
    <hr>
    
<div class="css-1dbjc4n">
  <div class="css-1dbjc4n r-3da1kt r-1jg9483"></div>
  <div class="css-1dbjc4n r-1qhn6m8 r-i023vh">
    <div class="css-1dbjc4n r-18u37iz">
      <div tabindex="0" class="css-1dbjc4n r-1loqt21 r-13awgt0 r-eqz5dr r-11wrixw r-1otgn73 r-1i6wzkk r-lrvibr" style="transition-duration:0s;width:112px;-webkit-transition-duration:0s">
      <div class="css-1dbjc4n r-u8s1d r-3mc0re r-ipm5af r-184en5c">
        <div class="css-1dbjc4n r-1awozwy r-ou6ah9 r-t12b5v r-18u37iz r-1777fci r-ilng1c r-m2pi6t r-1hvjb8t r-njp1lv"></div></div>
        <div class="css-1dbjc4n r-1awozwy r-cb25cm r-1xfd6ze r-wy61xf r-5njf8e">
          <div aria-disabled="true" role="img" tabindex="-1" class="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-1mwlp6a r-1udh08x r-1i6wzkk r-lrvibr r-18tzken" style="margin-right:0px;transition-duration:0s;-webkit-transition-duration:0s">
          <div tabindex="-1" class="css-1dbjc4n r-1xfd6ze r-1pi2tsx r-1udh08x r-13qz1uu">
            <img srcset="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_1,fl_progressive:steep,q_auto,c_limit/images/supply/customer-app-supply/1678864013225-bfc1de.jpeg 1x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/supply/customer-app-supply/1678864013225-bfc1de.jpeg 2x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_3,fl_progressive:steep,q_auto,c_limit/images/supply/customer-app-supply/1678864013225-bfc1de.jpeg 3x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_4,fl_progressive:steep,q_auto,c_limit/images/supply/customer-app-supply/1678864013225-bfc1de.jpeg 4x" src="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/supply/customer-app-supply/1678864013225-bfc1de.jpeg" style="object-fit:contain;height:100%;width:100%;background-color:rgb(245,245,245)" loading="eager" fetchpriority="high"></div></div></div><div class="css-1dbjc4n r-1awozwy r-6koalj r-tskmnb"><div class="css-1dbjc4n r-13awgt0 r-1777fci" style="width:104px"><div class="css-1dbjc4n r-1awozwy r-13awgt0 r-eqz5dr r-1777fci r-13qz1uu"><div dir="auto" class="css-901oao r-1qimiim r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-13wfysu r-3twk1y" style="text-align: center;">Women's Salon &amp; Spa</div></div></div></div></div><div tabindex="0" class="css-1dbjc4n r-1loqt21 r-13awgt0 r-eqz5dr r-1ow6zhx r-1otgn73 r-1i6wzkk r-lrvibr" style="width: 112px; transition-duration: 0.25s;"><div class="css-1dbjc4n r-u8s1d r-3mc0re r-ipm5af r-184en5c"><div class="css-1dbjc4n r-1awozwy r-ou6ah9 r-t12b5v r-18u37iz r-1777fci r-ilng1c r-m2pi6t r-1hvjb8t r-njp1lv"></div></div><div class="css-1dbjc4n r-1awozwy r-cb25cm r-1xfd6ze r-wy61xf r-5njf8e"><div aria-disabled="true" role="img" tabindex="-1" class="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-1mwlp6a r-1udh08x r-1i6wzkk r-lrvibr r-18tzken" style="margin-right:0px;transition-duration:0s;-webkit-transition-duration:0s"><div tabindex="-1" class="css-1dbjc4n r-1xfd6ze r-1pi2tsx r-1udh08x r-13qz1uu"><img srcset="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_1,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402788588-fe1681.png 1x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402788588-fe1681.png 2x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_3,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402788588-fe1681.png 3x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_4,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402788588-fe1681.png 4x" src="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402788588-fe1681.png" style="object-fit:contain;height:100%;width:100%;background-color:rgb(245,245,245)" loading="eager" fetchpriority="high"></div></div></div><div class="css-1dbjc4n r-1awozwy r-6koalj r-tskmnb"><div class="css-1dbjc4n r-13awgt0 r-1777fci" style="width:104px"><div class="css-1dbjc4n r-1awozwy r-13awgt0 r-eqz5dr r-1777fci r-13qz1uu"><div dir="auto" class="css-901oao r-1qimiim r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-13wfysu r-3twk1y" style="text-align: center;">Men's Salon &amp; Massage</div></div></div></div></div><div tabindex="0" class="css-1dbjc4n r-1loqt21 r-13awgt0 r-eqz5dr r-1ow6zhx r-1otgn73 r-1i6wzkk r-lrvibr" style="transition-duration:0s;width:112px;-webkit-transition-duration:0s"><div class="css-1dbjc4n r-u8s1d r-3mc0re r-ipm5af r-184en5c"><div class="css-1dbjc4n r-1awozwy r-ou6ah9 r-t12b5v r-18u37iz r-1777fci r-ilng1c r-m2pi6t r-1hvjb8t r-njp1lv"></div></div><div class="css-1dbjc4n r-1awozwy r-cb25cm r-1xfd6ze r-wy61xf r-5njf8e"><div aria-disabled="true" role="img" tabindex="-1" class="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-1mwlp6a r-1udh08x r-1i6wzkk r-lrvibr r-18tzken" style="margin-right:0px;transition-duration:0s;-webkit-transition-duration:0s"><div tabindex="-1" class="css-1dbjc4n r-1xfd6ze r-1pi2tsx r-1udh08x r-13qz1uu"><img srcset="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_1,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1679292077307-6143d7.jpeg 1x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1679292077307-6143d7.jpeg 2x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_3,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1679292077307-6143d7.jpeg 3x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_4,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1679292077307-6143d7.jpeg 4x" src="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1679292077307-6143d7.jpeg" style="object-fit:contain;height:100%;width:100%;background-color:rgb(245,245,245)" loading="eager" fetchpriority="high"></div></div></div><div class="css-1dbjc4n r-1awozwy r-6koalj r-tskmnb"><div class="css-1dbjc4n r-13awgt0 r-1777fci" style="width:104px"><div class="css-1dbjc4n r-1awozwy r-13awgt0 r-eqz5dr r-1777fci r-13qz1uu"><div dir="auto" class="css-901oao r-1qimiim r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-13wfysu r-3twk1y" style="text-align: center;">AC &amp; Appliance Repair</div></div></div></div></div></div><div class="css-1dbjc4n r-10ptun7 r-1janqcz"></div><div class="css-1dbjc4n r-18u37iz"><div tabindex="0" class="css-1dbjc4n r-1loqt21 r-13awgt0 r-eqz5dr r-11wrixw r-1otgn73 r-1i6wzkk r-lrvibr" style="transition-duration:0s;width:112px;-webkit-transition-duration:0s"><div class="css-1dbjc4n r-u8s1d r-3mc0re r-ipm5af r-184en5c"><div class="css-1dbjc4n r-1awozwy r-ou6ah9 r-t12b5v r-18u37iz r-1777fci r-ilng1c r-m2pi6t r-1hvjb8t r-njp1lv"></div></div><div class="css-1dbjc4n r-1awozwy r-cb25cm r-1xfd6ze r-wy61xf r-5njf8e"><div aria-disabled="true" role="img" tabindex="-1" class="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-1mwlp6a r-1udh08x r-1i6wzkk r-lrvibr r-18tzken" style="margin-right:0px;transition-duration:0s;-webkit-transition-duration:0s"><div tabindex="-1" class="css-1dbjc4n r-1xfd6ze r-1pi2tsx r-1udh08x r-13qz1uu"><img srcset="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_1,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1681711961404-75dfec.jpeg 1x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1681711961404-75dfec.jpeg 2x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_3,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1681711961404-75dfec.jpeg 3x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_4,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1681711961404-75dfec.jpeg 4x" src="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1681711961404-75dfec.jpeg" style="object-fit:contain;height:100%;width:100%;background-color:rgb(245,245,245)" loading="eager" fetchpriority="high"></div></div></div><div class="css-1dbjc4n r-1awozwy r-6koalj r-tskmnb"><div class="css-1dbjc4n r-13awgt0 r-1777fci" style="width:104px"><div class="css-1dbjc4n r-1awozwy r-13awgt0 r-eqz5dr r-1777fci r-13qz1uu"><div dir="auto" class="css-901oao r-1qimiim r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-13wfysu r-3twk1y" style="text-align: center;">Cleaning &amp; Pest Control</div></div></div></div></div><div tabindex="0" class="css-1dbjc4n r-1loqt21 r-13awgt0 r-eqz5dr r-1ow6zhx r-1otgn73 r-1i6wzkk r-lrvibr" style="transition-duration:0s;width:112px;-webkit-transition-duration:0s"><div class="css-1dbjc4n r-u8s1d r-3mc0re r-ipm5af r-184en5c"><div class="css-1dbjc4n r-1awozwy r-ou6ah9 r-t12b5v r-18u37iz r-1777fci r-ilng1c r-m2pi6t r-1hvjb8t r-njp1lv"></div></div><div class="css-1dbjc4n r-1awozwy r-cb25cm r-1xfd6ze r-wy61xf r-5njf8e"><div aria-disabled="true" role="img" tabindex="-1" class="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-1mwlp6a r-1udh08x r-1i6wzkk r-lrvibr r-18tzken" style="margin-right:0px;transition-duration:0s;-webkit-transition-duration:0s"><div tabindex="-1" class="css-1dbjc4n r-1xfd6ze r-1pi2tsx r-1udh08x r-13qz1uu">
  <img srcset="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_1,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402794135-faf080.png 1x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402794135-faf080.png 2x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_3,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402794135-faf080.png 3x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_4,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402794135-faf080.png 4x" src="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/luminosity/1658402794135-faf080.png" style="object-fit:contain;height:100%;width:100%;background-color:rgb(245,245,245)" loading="eager" fetchpriority="high"></div></div></div><div class="css-1dbjc4n r-1awozwy r-6koalj r-tskmnb"><div class="css-1dbjc4n r-13awgt0 r-1777fci" style="width:104px"><div class="css-1dbjc4n r-1awozwy r-13awgt0 r-eqz5dr r-1777fci r-13qz1uu"><div dir="auto" class="css-901oao r-1qimiim r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-13wfysu r-3twk1y" style="text-align: center;">Electrician, Plumber &amp; Carpenters</div></div></div></div></div><div tabindex="0" class="css-1dbjc4n r-1loqt21 r-13awgt0 r-eqz5dr r-1ow6zhx r-1otgn73 r-1i6wzkk r-lrvibr" style="transition-duration:0s;width:112px;-webkit-transition-duration:0s"><div class="css-1dbjc4n r-u8s1d r-3mc0re r-ipm5af r-184en5c"><div class="css-1dbjc4n r-1awozwy r-ou6ah9 r-t12b5v r-18u37iz r-1777fci r-ilng1c r-m2pi6t r-1hvjb8t r-njp1lv"></div></div><div class="css-1dbjc4n r-1awozwy r-cb25cm r-1xfd6ze r-wy61xf r-5njf8e"><div aria-disabled="true" role="img" tabindex="-1" class="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-1mwlp6a r-1udh08x r-1i6wzkk r-lrvibr r-18tzken" style="margin-right:0px;transition-duration:0s;-webkit-transition-duration:0s"><div tabindex="-1" class="css-1dbjc4n r-1xfd6ze r-1pi2tsx r-1udh08x r-13qz1uu"><img srcset="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_1,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1674120935535-f8d5c8.jpeg 1x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1674120935535-f8d5c8.jpeg 2x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_3,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1674120935535-f8d5c8.jpeg 3x, https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_4,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1674120935535-f8d5c8.jpeg 4x" src="https://res.cloudinary.com/urbanclap/image/upload/t_high_res_category/w_56,dpr_2,fl_progressive:steep,q_auto,c_limit/images/growth/home-screen/1674120935535-f8d5c8.jpeg" style="object-fit:contain;height:100%;width:100%;background-color:rgb(245,245,245)" loading="eager" fetchpriority="high"></div></div></div><div class="css-1dbjc4n r-1awozwy r-6koalj r-tskmnb"><div class="css-1dbjc4n r-13awgt0 r-1777fci" style="width:104px"><div class="css-1dbjc4n r-1awozwy r-13awgt0 r-eqz5dr r-1777fci r-13qz1uu"><div dir="auto" class="css-901oao r-1qimiim r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-13wfysu r-3twk1y" style="text-align: center;">Painting, Waterproofing &amp; Wallpapers</div></div></div></div></div></div><div class="css-1dbjc4n r-10ptun7 r-1janqcz"></div></div><div class="css-1dbjc4n r-tbmifm r-16eto9q"></div></div>
  <style>
    img {
        opacity: 1;
        transition: opacity 1s ease;
    }

    img[src=""] {
        opacity: 0;
        background: #eee;
        will-change: opacity
    }

    #SUBSCRIPTION_COLUMN > #rowsContainer > #HEADER {
        z-index: 1;
    }

    * {
        font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, "Helvetica Neue", Oxygen-Sans, Ubuntu, Cantarell, Helvetica, Arial, sans-serif !important;
    }

    #fabMenu {
        transform: translateY(0)!important;
        transition: transform 1s ease;
    }

    .slide-in {
        will-change: left;
        animation: slide-in 0.3s forwards;
        -webkit-animation: slide-in 0.3s forwards;
        animation-timing-function: ease-out;
    }

    .slide-out {
        will-change: left;
        animation: slide-out 0.3s forwards;
        -webkit-animation: slide-out 0.3s forwards;
        animation-timing-function: ease-out;
    }

    @keyframes slide-in {
        from {
            left: 10%;
        }

        to {
            left: 0;
        }
    }

    @-webkit-keyframes slide-in {
        from {
            left: 10%;
        }

        to {
            left: 0;
        }
    }

    @keyframes slide-out {
        from {
            left: -10%;
        }

        to {
            left: 0;
        }
    }

    @-webkit-keyframes slide-out {
        from {
            left: -10%;
        }

        to {
            left: 0;
        }
    }

    .contain-scroll, #contain-scroll {
        -ms-scroll-chaining: none;
        overscroll-behavior: none;
        overflow-y: scroll;
    }

    #contain-scroll {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }

    #contain-scroll::-webkit-scrollbar {
        display: none;
    }

    .orion-screen {
        position: relative
    }

    main {
        min-height: inherit;
        min-height: var(--app-height);
    }

    #partnerStories, #partnerStories > div:first-child {
        height: 100vh
    }

    main:has(#bottomBarNavbarContainer:first-child) {
        padding-top: calc(var(--app-height) - 55px);
    }

    main:has(#bottomBarNavbarContainer) {
        min-height: calc(var(--app-height) - 55px);
    }

    html {
        -ms-scroll-chaining: none;
        overscroll-behavior: none;
        overflow-x: hidden;
        overflow-y: scroll;
        margin: 0
    }

    body {
        min-height: 100%;
        min-height: 100vh;
        min-height: -webkit-fill-available;
        min-height: var(--app-height);
        margin: 0;
        margin-top: 1px
    }

    html,body {
        width: 100%;
        background-color: #fff;
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -webkit-font-smoothing: antialiased;
        text-rendering: optimizeLegibility;
        font-family: -apple-system,BlinkMacSystemFont,Segoe UI,'Roboto',Roboto,'Helvetica',Helvetica,'Arial',Arial,sans-serif
    }

    #carn, #carn-root, #carn-other-screens, .orion-screen {
        min-height: inherit;
    }

    .orion-screen {
        background: #fff
    }

    .hidden {
        display: none !important
    }

    ol,ul {
        padding: 0;
        margin: 0;
        list-style-type: none
    }

    h1,h2,h3,h4,h5,p {
        margin: 0
    }

    input {
        border: 0;
        outline: 0
    }

    a {
        text-decoration: none
    }

    button {
        border: 0;
        outline: 0
    }

    ::placeholder {
        color: #9e9e9e;
        opacity: 1
    }

    :-ms-input-placeholder {
        color: #9e9e9e
    }

    ::-ms-input-placeholder {
        color: #9e9e9e
    }

    #content {
        height: 100%;
        -webkit-touch-callout: none
    }

    .container,.container-fluid {
        margin-right: auto;
        margin-left: auto;
        padding-left: 15px;
        padding-right: 15px
    }

    @-ms-viewport {
        width: device-width
    }

    .hidden-lg {
        display: none !important
    }

    @media(max-width: 767px) {
        .hidden-xs {
            display:none !important
        }
    }

    @media(min-width: 768px) and (max-width:991px) {
        .hidden-sm {
            display:none !important
        }
    }

    @media(min-width: 992px) and (max-width:1199px) {
        .hidden-md {
            display:none !important
        }
    }

    .clearfix,.clearfix:after,.clearfix:before,.container-fluid:after,.container-fluid:before,.container:after,.row:after {
        clear: both;
        content: ' ';
        display: table
    }

    .center-block {
        display: block;
        margin-left: auto;
        margin-right: auto
    }

    .pull-right {
        float: right !important
    }

    html[dir=rtl] .pull-right {
        float: left !important
    }

    .pull-left {
        float: left !important
    }

    html[dir=rtl] .pull-left {
        float: right !important
    }

    *,:after,:before {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box
    }

    // @keyframes delayHide {
        0% {
            background: transparent;
        }

        50% {
            background: rgba(255, 255, 255, 0.2);
        }

        100% {
            rgba(255, 255, 255, 0.5);}
    }

    @-webkit-keyframes delayHide {
        0% {
            background: transparent;
        }

        50% {
            background: rgba(255, 255, 255, 0.2);
        }

        100% {
            rgba(255, 255, 255, 0.5);}
    }

    #uc-loader-minimal.interactive {
        display: flex;
        opacity: 1;
    }

    #uc-loader,#uc-loader-minimal {
        display: none;
        position: fixed;
        overflow: auto;
        z-index: 999999999999;
        background-color: rgba(255,255,255,.8);
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        opacity: 0;
        transition: .3s ease-out
    }

    #uc-loader-minimal {
        align-items: center;
        justify-content: center
    }

    html[dir=rtl] #uc-loader,html[dir=rtl] #uc-loader-minimal {
        left: initial;
        right: 0
    }

    .uc-image-container {
        width: 40px;
        height: 40px;
        background-color: #252525;
        z-index: 99999;
        margin: 0 auto;
        top: 50%;
        left: 50%;
        margin-left: -20px;
        margin-top: -20px;
        position: fixed
    }

    html[dir=rtl] .uc-image-container {
        left: initial;
        right: 50%;
        margin-left: initial;
        margin-right: -20px
    }

    .uc-spinner-real {
        position: relative !important;
        width: 48px;
        height: 48px;
        z-index: 99999;
        margin: 0 auto;
        top: 50%;
        left: 50%;
        margin-left: -24px;
        margin-top: -24px;
        position: fixed;
        -webkit-animation-name: sk-rotateplane;
        -webkit-animation-duration: 1.2s;
        -webkit-animation-iteration-count: infinite;
        -webkit-animation-timing-function: ease-in-out;
        animation-name: sk-rotateplane;
        animation-duration: 1.2s;
        animation-iteration-count: infinite;
        animation-timing-function: ease-in-out
    }

    html[dir=rtl] .uc-spinner-real {
        left: initial;
        right: 50%;
        margin-left: initial;
        margin-right: -24px
    }

    @keyframes sk-rotateplane {
        0 {
            -webkit-transform: perspective(120px) rotateY(0);
            transform: perspective(120px) rotateY(0)
        }

        100% {
            -webkit-transform: perspective(120px) rotateY(360deg);
            transform: perspective(120px) rotateY(360deg)
        }
    }

    @-webkit-keyframes sk-rotateplane {
        0 {
            -webkit-transform: rotateY(0);
            transform: rotateY(0)
        }

        100% {
            -webkit-transform: rotateY(360deg);
            transform: rotateY(360deg)
        }
    }

    .opaqueClass {
        background-color: rgba(255,255,255,.8) !important;
        opacity: 1 !important
    }

    @media only screen and (max-width: 768px) {
        .opaqueClass {
            background-color:rgba(255,255,255,.8) !important;
            opacity: 1 !important
        }
    }

    .forceShow {
        display: block !important
    }

    .ellipsis {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis
    }

    .hidden {
        display: none
    }

    table {
        border-collapse: collapse;
        border-spacing: 0
    }

    .dotsContainer {
        display: flex;
    }

    .dotOne,.dotTwo,.dotThree {
        position: relative;
        width: 7px;
        height: 7px;
        border-radius: 3.5px;
        background-color: rgb(84,84,84);
        margin: 0 2.5px;
        animation: dotRising 1.1s infinite;
    }

    .dotTwo {
        animation-delay: 0.113636s;
    }

    .dotThree {
        animation-delay: 0.227272s;
    }

    @keyframes dotRising {
        0% {
            top: 0;
            animation-timing: cubic-bezier(0.60, 0.0, 0.7, 1.000);
        }

        27.2727% {
            top: -8px;
            animation-timing: cubic-bezier(0.30, 1.0, 0.40, 0.000);
        }

        50%, 100% {
            top: 0px;
        }
    }

    [data-key='breadcrumbsSeo'] a {
        display: inline-block;
        font-family: os_regular;
        font-size: 10px;
        font-weight: 400;
        line-height: 14px;
        color: #545454;
        -webkit-text-decoration-line: none;
        text-decoration-line: none;
        text-transform: none;
    }
</style>
<style type="text/css" data-href="https://static.urbanclap.com/dist-product-webhttps://static.urbanclap.com/dist-product-web/client/main-79e12ca554870334dad2.css" id="https://static.urbanclap.com/dist-product-web/client/main-79e12ca554870334dad2.css">
    .b_e08b {
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        opacity: 0;
        background-color: rgba(0,0,0,0.7);
        transition-property: opacity;
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-name: b_g08b;
        z-index: 10;
        animation-duration: 0.25s;
        transition-duration: 0.25s
    }

    .b_i08b {
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88);
        will-change: transform;
        background-color: #f0f0f0;
        border-radius: 2px;
        position: absolute;
        overflow: hidden
    }

    .b_k08b {
        animation-name: b_m08b;
        left: 0;
        transform: translateX(-100%)
    }

    .b_o08b {
        animation-name: b_q08b
    }

    .b_s08b {
        animation-name: b_u08b;
        right: 0;
        transform: translateX(100%)
    }

    .b_w08b {
        animation-name: b_y08b;
        animation-fill-mode: forwards;
        animation-direction: normal;
        transform: translateX(0)
    }

    @keyframes b_y08b {
        from {
            transform: translateX(0)
        }

        to {
            transform: translateX(100%)
        }
    }

    .b_008b {
        animation-name: b_ab08b;
        top: 0;
        transform: translateY(-100%)
    }

    .b_ae08b {
        animation-name: b_ag08b
    }

    .b_ai08b {
        transform: translateY(100%);
        bottom: 0;
        animation-name: b_ak08b
    }

    .b_am08b {
        animation-name: b_ao08b;
        animation-fill-mode: forwards;
        animation-direction: normal;
        transform: translateY(0)
    }

    @keyframes b_ao08b {
        from {
            transform: translateY(0)
        }

        to {
            transform: translateY(100%)
        }
    }

    .b_aq08b {
        transform: translate(-50%, 0%);
        left: 50%;
        top: 50%;
        animation-name: b_as08b
    }

    .b_au08b {
        animation-name: b_aw08b
    }

    .b_ay08b {
        transform: translate(-50%, -50%);
        left: 50%;
        top: 50%;
        -webkit-transform: translate(-50%, -50%) scale(1.05);
        transform: translate(-50%, -50%) scale(1.05);
        opacity: 0;
        animation-name: b_a008b
    }

    .b_a208b {
        animation-name: b_a408b
    }

    @keyframes b_a008b {
        from {
            -webkit-transform: translate(-50%, -50%) scale(1.05);
            transform: translate(-50%, -50%) scale(1.05);
            opacity: 0
        }

        to {
            -webkit-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
            opacity: 1
        }
    }

    @keyframes b_a408b {
        from {
            -webkit-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
            opacity: 1
        }

        to {
            -webkit-transform: translate(-50%, -50%) scale(0.95);
            transform: translate(-50%, -50%) scale(0.95);
            opacity: 0
        }
    }

    @keyframes b_as08b {
        from {
            transform: translate(-50%, 0%)
        }

        to {
            opacity: 1;
            transform: translate(-50%, -50%)
        }
    }

    @keyframes b_aw08b {
        from {
            transform: translate(-50%, -50%)
        }

        to {
            opacity: 0;
            transform: translate(-50%, 0%)
        }
    }

    @keyframes b_ab08b {
        from {
            transform: translateY(-100%)
        }

        to {
            transform: translateY(0)
        }
    }

    @keyframes b_ag08b {
        from {
            transform: translateY(0)
        }

        to {
            transform: translateY(-100%)
        }
    }

    @keyframes b_ak08b {
        from {
            transform: translateY(100%)
        }

        to {
            transform: translateY(0)
        }
    }

    @keyframes b_m08b {
        from {
            transform: translateX(-100%)
        }

        to {
            transform: translateX(0)
        }
    }

    @keyframes b_q08b {
        from {
            transform: translateX(0)
        }

        to {
            transform: translateX(-100%)
        }
    }

    @keyframes b_u08b {
        from {
            transform: translateX(100%)
        }

        to {
            transform: translateX(0)
        }
    }

    .b_a608b {
        opacity: 1;
        transition-property: opacity;
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-name: b_a808b;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88)
    }

    @keyframes b_a808b {
        from {
            opacity: 1
        }

        to {
            opacity: 0
        }
    }

    @keyframes b_g08b {
        from {
            opacity: 0
        }

        to {
            opacity: 1
        }
    }

    .DSU60OHd {
        position: relative;
        height: 100%;
        width: 100%
    }

    .DSU60OHd .mrRRYFWR {
        z-index: 6;
        position: absolute;
        top: 16px;
        right: 16px;
        color: #fff;
        cursor: pointer
    }

    [dir="rtl"] .DSU60OHd .mrRRYFWR {
        right: initial;
        left: 16px
    }

    @media only screen and (min-width: 769px) {
        .DSU60OHd .mrRRYFWR {
            top:22px;
            right: 22px
        }

        [dir="rtl"] .DSU60OHd .mrRRYFWR {
            right: initial;
            left: 22px
        }
    }

    @use "sass:map";@use "sass:list";.lZMbfqVi {
        overflow: auto;
        display: none;
        z-index: 7;
        background-color: rgba(255,255,255,0.8);
        transition: all 0.3s ease-in-out;
        opacity: 0;
        width: 100% !important;
        height: 100% !important;
        position: absolute !important;
        top: 0 !important;
        left: 0 !important
    }

    .ivAPp9Xz {
        position: relative;
        height: 100%;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch
    }

    .ivAPp9Xz .dBPXpZgW {
        padding-bottom: 215px
    }

    .ivAPp9Xz .pVKkAg4_ {
        overflow-x: hidden
    }

    .ivAPp9Xz .X54EbYum {
        position: absolute;
        top: 16px;
        left: 16px;
        color: #fff;
        cursor: pointer;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: rgba(0,0,0,0.3);
        text-align: center;
        z-index: 11
    }

    .ivAPp9Xz .X54EbYum .OJau890I {
        font-size: 14px;
        position: relative;
        top: 5px
    }

    @media only screen and (min-width: 769px) {
        .ivAPp9Xz .X54EbYum .OJau890I {
            top:7px
        }
    }

    .ivAPp9Xz .r0Sllz2o {
        padding: 64px 16px;
        background: linear-gradient(#03627e, #2ea88f);
        text-align: center
    }

    .ivAPp9Xz .r0Sllz2o .uC51yhyp {
        display: inline-block;
        width: 80%
    }

    .ivAPp9Xz .r0Sllz2o .o_eAPpos {
        line-height: 28px;
        font-size: 18px;
        margin: 0 0 0 10px;
        color: #fff;
        text-align: center;
        font-weight: bold
    }

    .ivAPp9Xz .r0Sllz2o .hDoWIt9d {
        line-height: 16px;
        font-size: 14px;
        font-weight: normal;
        margin: 8px 0 0 0;
        color: #fff;
        text-align: left;
        padding-left: 16px
    }

    .ivAPp9Xz .r0Sllz2o .hDoWIt9d span.ncmTC59h {
        font-size: 8px;
        position: relative;
        margin-right: 12px;
        top: -1px
    }

    .ivAPp9Xz .r0Sllz2o .hDoWIt9d span.yAAwQF7n {
        display: inline-block
    }

    .ivAPp9Xz .r0Sllz2o .hDoWIt9d span.yAAwQF7n:first-letter {
        text-transform: uppercase
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj {
        height: 200px;
        background: transparent;
        border: 0;
        width: 100%;
        text-align: left;
        margin-top: 16px
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh {
        background-color: #fff;
        border-radius: 4px;
        padding: 26px 8px 8px 8px;
        margin: 0 4px;
        text-align: center;
        width: 160px;
        display: inline-block;
        position: relative;
        margin-top: 10px
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh:first-child {
        margin-left: 8px
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh:last-child {
        margin-right: 8px
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh .jsxSvddG {
        line-height: 32px;
        font-size: 22px;
        color: #000;
        font-weight: bold;
        white-space: normal;
        margin: 0
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh .TzW1COpu {
        line-height: 22px;
        font-size: 18px;
        color: #000;
        font-weight: 500;
        white-space: normal;
        margin: 0
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh .f0dp1xou {
        line-height: 20px;
        font-size: 14px;
        color: #000;
        font-weight: normal;
        margin: 16px 0 0 0;
        white-space: normal
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh .f0dp1xou strike {
        color: #bdbdbd;
        margin-left: 8px
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh .UejIq71u {
        line-height: 40px;
        font-size: 14px;
        background-color: #000;
        color: #fff;
        border-radius: 4px;
        margin: 24px 0 0 0;
        border: 1px solid #000
    }

    .ivAPp9Xz .r0Sllz2o .mLIalItj .BIKEHJOh .Dewsh4LF {
        line-height: 40px;
        font-size: 14px;
        background-color: #fff;
        color: #000;
        border: 1px solid #000;
        border-radius: 4px;
        margin: 24px 0 0 0
    }

    .ivAPp9Xz .r0Sllz2o .sG6TuqFX {
        margin-left: -8px;
        margin-right: -8px;
        width: auto
    }

    .ivAPp9Xz .r0Sllz2o .UimLdnev {
        width: auto;
        margin-left: -16px;
        margin-right: -16px
    }

    .ivAPp9Xz .r0Sllz2o .PoOChfeR {
        line-height: 24px;
        font-size: 14px;
        color: #fff;
        font-weight: 500;
        text-align: center;
        margin: 16px 0 0 0
    }

    .ivAPp9Xz .fShjoryS {
        padding: 8px;
        background: #f5f5f5
    }

    .ivAPp9Xz .w1kwS1AI {
        width: auto;
        box-shadow: 0 2px 4px 0px rgba(0,0,0,0.28);
        border-radius: 4px;
        background: #fff;
        padding-bottom: 50px;
        padding-top: 16px
    }

    .ivAPp9Xz .w1kwS1AI .o_eAPpos {
        line-height: 28px;
        font-size: 20px;
        color: #212121;
        font-weight: bold;
        text-align: center;
        padding: 24px 8px;
        margin: 0;
        padding-bottom: 0;
        border-top: 1px solid #e2e2e2;
        margin-top: 16px
    }

    .ivAPp9Xz .w1kwS1AI .srQRAl78 {
        margin: 0 !important;
        border: 0 !important
    }

    .ivAPp9Xz .w1kwS1AI .p96hRCGP .S9KgZHDN {
        width: 100%;
        padding: 0 16px;
        text-align: center;
        position: relative;
        display: inline-block
    }

    .ivAPp9Xz .w1kwS1AI .p96hRCGP .S9KgZHDN .aR72eVqf {
        line-height: 24px;
        font-size: 14px;
        font-weight: 500;
        color: #212121;
        margin: 0
    }

    .ivAPp9Xz .w1kwS1AI .p96hRCGP .S9KgZHDN .aR72eVqf .uC51yhyp {
        height: 24px;
        width: auto
    }

    .ivAPp9Xz .w1kwS1AI .p96hRCGP .S9KgZHDN .aR72eVqf span {
        display: inline-block;
        line-height: 24px;
        font-size: 16px;
        margin-left: 8px;
        position: relative;
        top: 2px
    }

    .ivAPp9Xz .w1kwS1AI .p96hRCGP .S9KgZHDN .WYSOmYkt {
        line-height: 44px;
        font-size: 30px;
        font-weight: bold;
        color: #000000;
        margin: 8px 0 0 0
    }

    .ivAPp9Xz .w1kwS1AI .p96hRCGP .S9KgZHDN .EdwInwdg {
        line-height: 18px;
        font-size: 12px;
        font-weight: normal;
        color: #757575;
        margin: 4px 0 0 0
    }

    .ivAPp9Xz .w1kwS1AI .p96hRCGP .S9KgZHDN .vv59mkcJ {
        display: inline-block;
        line-height: 24px;
        font-size: 12px;
        background-color: #f0f0f0;
        width: 24px;
        text-align: center;
        border-radius: 12px;
        margin: 0;
        position: absolute;
        right: -12px;
        top: calc(50% - 12px)
    }

    .ivAPp9Xz .w1kwS1AI .p96hRCGP .m2ObRSlq .aR72eVqf,.ivAPp9Xz .w1kwS1AI .p96hRCGP .m2ObRSlq .WYSOmYkt {
        color: #117883
    }

    .ivAPp9Xz .w1kwS1AI .ujI_5uoc {
        line-height: 24px;
        font-size: 16px;
        color: #212121;
        font-weight: 500;
        text-align: center;
        margin: 16px 0 0 0;
        padding: 0 32px
    }

    .ivAPp9Xz .C_7qKvNF {
        background: #fff;
        padding: 24px 16px 0 16px
    }

    .ivAPp9Xz .C_7qKvNF .TuyWogmh {
        line-height: 28px;
        font-size: 20px;
        color: #212121;
        font-weight: bold;
        text-align: center;
        margin: 0
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY {
        margin-top: 24px
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY:last-child {
        margin-bottom: 24px
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .rYKElfns {
        width: 20px;
        display: inline-block;
        vertical-align: top
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .rYKElfns img {
        width: 100%
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .l1CMcOXF {
        width: calc(100% - 20px);
        display: inline-block;
        padding-left: 12px
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .l1CMcOXF .PoOChfeR {
        margin: 0;
        line-height: 22px;
        font-size: 16px;
        color: #424242;
        font-weight: normal
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .l1CMcOXF .yWqQ6RSZ {
        margin-top: 16px
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .l1CMcOXF .yWqQ6RSZ .R1Wt7mrC {
        width: 40px;
        display: inline-block
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .l1CMcOXF .yWqQ6RSZ .R1Wt7mrC img {
        width: 100%;
        border-radius: 50%
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .l1CMcOXF .yWqQ6RSZ .dGr3Kal7 {
        width: calc(100% - 40px);
        display: inline-block;
        vertical-align: top;
        padding-left: 12px
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .l1CMcOXF .yWqQ6RSZ .dGr3Kal7 .To64rpQp {
        line-height: 20px;
        font-size: 14px;
        color: #424242;
        font-weight: 500;
        margin: 0
    }

    .ivAPp9Xz .C_7qKvNF .KuzWY60i .qYvGhsfY .l1CMcOXF .yWqQ6RSZ .dGr3Kal7 .teo5R_Zu {
        line-height: 18px;
        font-size: 12px;
        color: #9e9e9e;
        font-weight: normal;
        margin: 2px 0 0 0
    }

    .ivAPp9Xz .C_7qKvNF .F9tc9eXd {
        line-height: 56px;
        text-align: center;
        font-weight: 500;
        font-size: 16px;
        color: #0a6c81;
        margin: 0 -16px 0 -16px;
        border-top: 1px solid #f0f0f0
    }

    .ivAPp9Xz .C_7qKvNF .X1a0ys6k {
        border-bottom: 1px solid #f0f0f0
    }

    .ivAPp9Xz .gHtHU552 {
        padding: 24px 16px 24px 16px
    }

    .ivAPp9Xz .gHtHU552 .d6lRKzng {
        line-height: 28px;
        font-size: 20px;
        color: #ffffff;
        font-weight: bold;
        text-align: center;
        margin: 0
    }

    .ivAPp9Xz .gHtHU552 .HJ8NGHkn {
        margin-top: 24px
    }

    .ivAPp9Xz .WP_pF0Oj {
        padding: 24px 16px
    }

    .ivAPp9Xz .WP_pF0Oj .o_eAPpos {
        line-height: 28px;
        font-size: 20px;
        color: #212121;
        font-weight: bold;
        text-align: center;
        margin: 0 0 24px 0
    }

    .ivAPp9Xz .WP_pF0Oj ul {
        list-style-type: disc;
        padding-left: 16px;
        margin: 0
    }

    .ivAPp9Xz .WP_pF0Oj ul li {
        line-height: 24px;
        font-size: 14px;
        color: #212121;
        font-weight: normal;
        margin: 8px 0 0 0;
        padding-left: 16px
    }

    .ivAPp9Xz .WP_pF0Oj ul li:first-child {
        margin-top: 0
    }

    .ivAPp9Xz .ocZpeSEA {
        height: 8px;
        background-color: #f5f5f5
    }

    .ivAPp9Xz .wVSQwm2e {
        padding: 24px 16px
    }

    .ivAPp9Xz .wVSQwm2e .o_eAPpos {
        line-height: 28px;
        font-size: 20px;
        color: #212121;
        background-color: #ffffff;
        font-weight: bold;
        text-align: center;
        margin: 0 0 24px 0
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU {
        margin-left: -16px;
        margin-right: -16px;
        width: auto
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM {
        border-top: 1px solid #f0f0f0
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM:last-child {
        border-bottom: 1px solid #f0f0f0
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .SiMPsPCK {
        display: table;
        width: 100%
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .SiMPsPCK .qhsEDVEi,.ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .SiMPsPCK .mfsocuSX {
        padding: 12px 16px;
        display: table-cell;
        vertical-align: top
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .SiMPsPCK .qhsEDVEi {
        line-height: 24px;
        font-size: 14px;
        color: #616161
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .SiMPsPCK .iT5Fjqrd {
        font-weight: 500;
        color: #212121
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .SiMPsPCK .mfsocuSX {
        width: 20px;
        font-size: 12px;
        color: #bdbdbd
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .SiMPsPCK .mfsocuSX:before {
        float: left;
        position: relative;
        top: 6px
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .lxpSnwTQ p {
        margin: 16px 0 0 0;
        line-height: 24px;
        font-size: 14px;
        color: #212121;
        padding: 0 16px
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .lxpSnwTQ p:first-child {
        margin-top: 4px
    }

    .ivAPp9Xz .wVSQwm2e .vL1hkwUU .DOrsfGgM .lxpSnwTQ p:last-child {
        margin-bottom: 16px
    }

    .HSlqYb3l {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0,0,0,0.7);
        z-index: 99
    }

    .Bye1GVD9 {
        background-color: #fff;
        text-align: center;
        padding: 24px 8px 8px 8px;
        width: 100%;
        box-shadow: 0 -2px 6px 0 rgba(0,0,0,0.1);
        position: relative;
        z-index: 100;
        cursor: pointer
    }

    .Bye1GVD9.GTMVuvpz {
        padding-top: 40px
    }

    .Bye1GVD9.GTMVuvpz .yZOrvpoC {
        color: #212121
    }

    .Bye1GVD9.GTMVuvpz .JRs3YlQw {
        position: absolute;
        top: -20px;
        left: 50%;
        transform: translateX(-20px);
        width: 40px;
        min-height: 40px
    }

    .Bye1GVD9 .mDnNWRql {
        width: 56px;
        min-height: 56px;
        border-radius: 50%;
        margin: 0 auto
    }

    .Bye1GVD9 .yZOrvpoC {
        line-height: 28px;
        font-size: 18px;
        font-weight: bold;
        margin: 0;
        color: #137b84;
        padding: 0 16px
    }

    .Bye1GVD9 .cQcgJm6s {
        line-height: 20px;
        font-size: 14px;
        color: #212121;
        margin: 8px 0 0 0
    }

    .Bye1GVD9 .xFq29Fk_ {
        background: #e3f3f0;
        color: #0d4c51;
        font-size: 12px;
        position: relative;
        height: 80px;
        display: flex;
        align-items: center;
        margin-top: 50px;
        padding: 0px 4px;
        flex-direction: column;
        justify-content: center
    }

    .Bye1GVD9 .xFq29Fk_ .amN_FyTk {
        position: absolute;
        left: 50%;
        transform: translate(-50%, -50%);
        top: 0
    }

    .Bye1GVD9 .xFq29Fk_ .KIvNQejb {
        width: 30px;
        height: 30px
    }

    .Bye1GVD9 .UKCuy8mu {
        background-color: #000;
        color: #fff;
        text-align: center;
        width: 100%;
        line-height: 48px;
        margin: 0;
        margin-top: 24px;
        border-radius: 4px;
        cursor: pointer
    }

    .Bye1GVD9 .UKCuy8mu span.yAAwQF7n {
        display: inline-block;
        font-weight: 500;
        line-height: 48px;
        font-size: 16px
    }

    .Bye1GVD9 .UKCuy8mu span.UMkOwBK7 {
        font-size: 24px;
        margin-left: 16px;
        display: inline-block;
        line-height: 48px;
        vertical-align: top;
        position: relative;
        top: 4px
    }

    .Bye1GVD9 .UKCuy8mu span.XbiUD4h4 {
        font-size: 7px;
        margin-left: 7px;
        margin-right: 4px;
        position: relative;
        top: -2px
    }

    .sNeYUH5g {
        position: fixed !important;
        bottom: 0;
        height: 300px !important;
        z-index: 100
    }

    .LSlUOJo6 {
        bottom: 0;
        position: fixed;
        transform: translateY(100%);
        transition: transform 0.3s, opacity 0.3s;
        opacity: 0;
        z-index: 99999;
        width: 100%
    }

    .F91jxjvH {
        transform: translateY(0);
        opacity: 1
    }

    .SqK2Px_9 {
        padding: 16px 24px;
        background: linear-gradient(#303aee, #5387ee)
    }

    .SqK2Px_9 .yZOrvpoC {
        line-height: 24px;
        font-size: 16px;
        font-weight: 500;
        color: #ffffff
    }

    .SqK2Px_9 .UKCuy8mu {
        background-color: #ffffff;
        color: #212121;
        margin: 16px 0 0 0;
        font-weight: 500
    }

    .SqK2Px_9 .UKCuy8mu span.yAAwQF7n {
        font-size: 14px
    }

    .KaGUk8qZ {
        height: 650px;
        max-height: 650px;
        border: none;
        width: 800px
    }

    @media (max-width: 480px) {
        .KaGUk8qZ {
            height:100%;
            max-height: 100%;
            width: 100%
        }
    }

    .zSa0oZie {
        height: auto;
        width: 95% !important;
        border: 0 !important;
        display: block;
        margin: auto;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%) !important;
        border-radius: 4px !important
    }

    .GXszA5qe {
        padding-bottom: 0 !important;
        overflow-y: auto !important;
        height: 100% !important;
        background-color: #ffffff !important
    }

    .k9AqDayk {
        padding: 0 24px;
        width: 100%
    }

    .Y4QK8Rx6 {
        background: linear-gradient(#03627e, #2ea88f) !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.24) !important;
        border: 2px solid #fff !important;
        height: 32px !important;
        width: 32px !important
    }

    .Y4QK8Rx6:after {
        content: none !important
    }

    .dr708xFQ {
        height: 8px !important;
        box-shadow: none !important;
        background-color: #a1cbce !important;
        top: 40px
    }

    .WOdDnAbi {
        background-color: #137b84 !important
    }

    .oVMm2Mdp {
        line-height: 18px !important;
        font-size: 11px !important;
        top: -60px !important;
        color: #757575 !important;
        white-space: nowrap
    }

    .LuphqiHI {
        font-weight: 500 !important;
        color: #212121 !important
    }

    ._hxwuxQx {
        text-align: center
    }

    .WOOPZNoC {
        position: absolute;
        top: -10px;
        left: 0;
        right: 0;
        color: #fff;
        width: 115px;
        margin: 0 auto;
        font-size: 12px;
        padding: 0 12px;
        line-height: 20px;
        display: inline-block;
        border-radius: 10px;
        background: #8bc34a;
        text-transform: uppercase
    }

    .ceHEV8VE {
        background: rgba(255,255,255,0.16);
        margin-top: 24px;
        border-radius: 4px;
        padding: 8px;
        margin-left: -8px;
        margin-right: -8px;
        padding-top: 16px
    }

    .fUKvdc8m {
        position: relative;
        top: -45px
    }

    .RC4UKy5V {
        margin-top: 24px;
        margin-left: -8px;
        margin-right: -8px
    }

    .DuBc6fPO {
        padding-bottom: 8px !important
    }

    .trjS0R06 {
        padding-bottom: 0px !important
    }

    .exz_1rPy {
        padding-bottom: 46px !important
    }

    .n_AToiEA,.laDiLxTU {
        margin-left: -16px;
        margin-right: -16px;
        border-radius: 0 !important;
        box-shadow: none !important;
        margin-top: 0 !important
    }

    .laDiLxTU {
        margin-top: 24px !important;
        padding-bottom: 16px;
        padding-top: 12px;
        margin-left: -8px;
        margin-right: -8px;
        border-top-left-radius: 4px !important;
        border-top-right-radius: 4px !important
    }

    .FnyMTZPU {
        margin-top: 8px !important;
        padding: 12px 8px !important
    }

    .fN2Lf8Ce {
        padding-top: 0px !important;
        padding-bottom: 1px !important;
        background: transparent !important
    }

    .fN2Lf8Ce .aR72eVqf,.fN2Lf8Ce .WYSOmYkt {
        color: #fff !important
    }

    .fN2Lf8Ce .m2ObRSlq {
        padding: 0 8px !important;
        background: rgba(255,255,255,0.16) !important;
        margin: 8px;
        width: auto !important;
        display: block !important;
        margin-top: 0;
        border-top: 1px solid rgba(255,255,255,0.2);
        padding-top: 16px !important;
        padding-bottom: 16px !important;
        border-bottom-left-radius: 4px !important;
        border-bottom-right-radius: 4px !important
    }

    .ZDLMuz7D {
        background: #fff;
        border-radius: 4px;
        box-shadow: 0 2px 4px 0px rgba(0,0,0,0.28);
        padding: 16px;
        margin: 8px;
        margin-top: 10px
    }

    .ZDLMuz7D .o_eAPpos {
        padding: 0 !important
    }

    .L0vMziyN {
        text-align: left;
        color: #424242
    }

    .L0vMziyN span {
        line-height: 28px;
        font-size: 16px;
        display: inline-block
    }

    .fDf62z8A {
        border: 0 !important
    }

    .fDf62z8A label {
        padding: 8px 0 8px 16px !important
    }

    .qxTgMlZc {
        margin-top: 16px !important
    }

    .JY9ie8p5 {
        position: relative;
        top: 1px;
        float: left
    }

    .JY9ie8p5:before {
        color: #e2e2e2;
        font-weight: bolder;
        height: 20px;
        width: 22px;
        font-size: 20px;
        float: left
    }

    .c_3WfyC1 {
        background: #dc6711 !important;
        padding: 24px 16px 16px 16px !important
    }

    .CZvMg2pk {
        padding-bottom: 0 !important
    }

    .srEp5GKv {
        background: #f7f8fa !important
    }

    .w2LSeBFL {
        width: 18px;
        margin-right: 8px;
        position: relative;
        top: -1px
    }

    .WRJB8yJE {
        height: 218px !important
    }

    .w4fDMRWC {
        line-height: 20px !important;
        font-size: 14px !important;
        font-weight: normal !important
    }

    .qvmZrtJG {
        padding-bottom: 16px !important
    }

    .DBWBrNs4 {
        text-decoration: line-through !important
    }

    .qaZjgfvY {
        display: block
    }

    .mShc7GkC {
        position: relative;
        float: left;
        height: 100%;
        width: 100%
    }

    .mShc7GkC .ddtxtdx9 {
        line-height: 24px;
        font-size: 16px;
        color: #212121;
        margin: 48px 0 32px 0;
        padding: 0 16px;
        text-align: center
    }

    .mShc7GkC .Ys5eAlrd {
        border-top: 1px solid #f0f0f0;
        line-height: 48px;
        font-size: 16px;
        color: #304ffe;
        font-weight: 500;
        margin: 0;
        text-align: center;
        cursor: pointer
    }

    .mShc7GkC .F0Wbtc4U {
        position: absolute;
        top: 16px;
        right: 16px;
        font-size: 12px
    }

    .b0DFQgY2 {
        margin: 20px 0;
        position: relative;
        background: #e6e6e6;
        -ms-touch-action: none;
        touch-action: none
    }

    .b0DFQgY2,.b0DFQgY2 .Rnvm6i8C {
        display: block;
        box-shadow: inset 0 1px 3px rgba(0,0,0,0.4)
    }

    .b0DFQgY2 .XBQu0bmo {
        background: #fff;
        border: 1px solid #ccc;
        cursor: pointer;
        display: inline-block;
        position: absolute;
        box-shadow: 0 1px 3px rgba(0,0,0,0.4),0 -1px 3px rgba(0,0,0,0.4)
    }

    .b0DFQgY2 .XBQu0bmo .t36s3BNH {
        opacity: 1
    }

    .b0DFQgY2 .fLXwCirm {
        width: 40px;
        height: 40px;
        text-align: center;
        position: absolute;
        background-color: rgba(0,0,0,0.8);
        font-weight: normal;
        font-size: 14px;
        transition: all 100ms ease-in;
        border-radius: 4px;
        display: inline-block;
        color: white;
        left: 50%;
        transform: translate3d(-50%, 0, 0)
    }

    .b0DFQgY2 .fLXwCirm span {
        margin-top: 12px;
        display: inline-block;
        line-height: 100%
    }

    .b0DFQgY2 .fLXwCirm:after {
        content: " ";
        position: absolute;
        width: 0;
        height: 0
    }

    .AGQO5qVl {
        height: 12px;
        border-radius: 10px
    }

    .AGQO5qVl .Rnvm6i8C {
        height: 100%;
        background-color: #7cb342;
        border-radius: 10px;
        top: 0
    }

    .AGQO5qVl .XBQu0bmo {
        width: 30px;
        height: 30px;
        border-radius: 30px;
        top: 50%;
        transform: translate3d(-50%, -50%, 0)
    }

    .AGQO5qVl .XBQu0bmo:after {
        content: " ";
        position: absolute;
        width: 16px;
        height: 16px;
        top: 6px;
        left: 6px;
        border-radius: 50%;
        background-color: #dadada;
        box-shadow: 0 1px 3px rgba(0,0,0,0.4) inset,0 -1px 3px rgba(0,0,0,0.4) inset
    }

    .AGQO5qVl .fLXwCirm {
        top: -55px
    }

    .AGQO5qVl .fLXwCirm:after {
        border-left: 8px solid transparent;
        border-right: 8px solid transparent;
        border-top: 8px solid rgba(0,0,0,0.8);
        left: 50%;
        bottom: -8px;
        transform: translate3d(-50%, 0, 0)
    }

    .sVDydaXz {
        margin: 20px auto;
        height: 150px;
        max-width: 10px;
        background-color: transparent
    }

    .sVDydaXz .Rnvm6i8C,.sVDydaXz .XBQu0bmo {
        position: absolute
    }

    .sVDydaXz .Rnvm6i8C {
        width: 100%;
        background-color: #7cb342;
        box-shadow: none;
        bottom: 0
    }

    .sVDydaXz .XBQu0bmo {
        width: 30px;
        height: 10px;
        left: -10px;
        box-shadow: none
    }

    .sVDydaXz .fLXwCirm {
        left: -100%;
        top: 50%;
        transform: translate3d(-50%, -50%, 0)
    }

    .sVDydaXz .fLXwCirm:after {
        border-top: 8px solid transparent;
        border-bottom: 8px solid transparent;
        border-left: 8px solid rgba(0,0,0,0.8);
        left: 100%;
        top: 12px
    }

    .BOHJIhNf.AGQO5qVl .Rnvm6i8C {
        right: 0
    }

    .BOHJIhNf.sVDydaXz .Rnvm6i8C {
        top: 0;
        bottom: inherit
    }

    .ow6Lj0Vo {
        position: relative
    }

    .sVDydaXz .ow6Lj0Vo {
        position: relative;
        list-style-type: none;
        margin: 0 0 0 24px;
        padding: 0;
        text-align: left;
        width: 250px;
        height: 100%;
        left: 10px
    }

    .sVDydaXz .ow6Lj0Vo .yWjYnsQd {
        position: absolute;
        transform: translate3d(0, -50%, 0)
    }

    .sVDydaXz .ow6Lj0Vo .yWjYnsQd:before {
        content: "";
        width: 10px;
        height: 2px;
        background: black;
        position: absolute;
        left: -14px;
        top: 50%;
        transform: translateY(-50%);
        z-index: -1
    }

    .ow6Lj0Vo .yWjYnsQd {
        position: absolute;
        font-size: 14px;
        cursor: pointer;
        display: inline-block;
        top: 10px;
        transform: translate3d(-50%, 0, 0)
    }

    .b_e8ed {
        width: 100%
    }

    .b_e8ed .b_g8ed {
        display: none
    }

    .b_e271 {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        background-position: center;
        transition: background 0.3s;
        outline: none
    }

    .b_e271 .b_g271 {
        position: absolute;
        display: inline-block;
        will-change: auto;
        top: 0;
        left: 0;
        opacity: 0;
        z-index: -1;
        width: 100%;
        height: 100%;
        background-image: repeating-linear-gradient(45deg, rgba(0,0,0,0.2), rgba(0,0,0,0.2) 20px, transparent 21px, transparent 40px);
        background-size: 56px 100%
    }

    .b_e271 .b_i271 {
        animation: b_g271 .5s linear infinite
    }

    @keyframes b_g271 {
        0% {
            background-position: 0 0;
            z-index: 1;
            opacity: 1
        }

        100% {
            background-position: 56px 0;
            z-index: 1;
            opacity: 1
        }
    }

    .b_e271 .b_k271 {
        font-size: 10px;
        position: relative;
        border: 4px solid rgba(255,255,255,0.2);
        border-left: 4px solid #ffffff;
        transform: translateZ(0);
        border-radius: 50%;
        width: 20px;
        height: 20px;
        position: absolute;
        top: 50%;
        transform: translate(-50%, -50%);
        left: 50%;
        animation: b_m271 1.1s infinite linear
    }

    .b_e271 .b_k271 :after {
        border-radius: 50%;
        width: 10em;
        height: 10em
    }

    @keyframes b_m271 {
        0% {
            transform: translate(-50%, -50%) rotate(0deg)
        }

        100% {
            transform: translate(-50%, -50%) rotate(360deg)
        }
    }

    .b_o271 {
        color: #fff !important;
        pointer-events: none !important;
        background-color: #bbb !important;
        border: 1px solid #bbb !important;
        cursor: not-allowed !important
    }

    .b_q271 {
        background-color: #212121;
        border: 1px solid #212121;
        color: #fff
    }

    .b_q271:hover {
        background: rgba(0,0,0,0.8) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.8) 1%) center/15000%
    }

    @media only screen and (max-width: 768px) {
        .b_q271:hover {
            background:rgba(0,0,0,0.8) radial-gradient(circle, transparent 1%, rgba(155,155,155,0.2) 1%) center/15000%
        }
    }

    .b_q271:active {
        background-color: #212121;
        background-size: 100%;
        transition: background 0s
    }

    .b_s271 {
        background-color: #fff;
        border: 1px solid #212121;
        color: #212121
    }

    .b_s271:hover {
        background: rgba(0,0,0,0.05) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.05) 1%) center/15000%
    }

    .b_s271:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .b_u271 {
        background-color: #fff;
        border: 1px solid #dd0017;
        color: #dd0017
    }

    .b_u271:hover {
        background: rgba(221,0,23,0.1) radial-gradient(circle, transparent 1%, rgba(221,0,23,0.05) 1%) center/15000%
    }

    .b_u271:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .b_w271 {
        background-color: #fafafa !important;
        border: 1px solid #fafafa !important;
        color: #212121 !important;
        border-radius: 30px !important;
        width: 100%
    }

    .b_w271:hover {
        background: #f4f4f4 radial-gradient(circle, transparent 1%, #f4f4f4 1%) center/15000%
    }

    .b_w271:active {
        background-color: #fafafa;
        background-size: 100%;
        transition: background 0s
    }

    .b_y271 {
        background-color: #fff;
        border: none;
        color: #212121
    }

    .b_y271:hover {
        background: rgba(0,0,0,0.05) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.05) 1%) center/15000%
    }

    .b_y271:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .b_y271:after {
        background-color: rgba(255,255,255,0.2);
        box-shadow: 0px 0px 24px 2px rgba(255,255,255,0.2);
        content: '';
        width: 48px;
        height: 100%;
        transform-origin: bottom left;
        position: absolute;
        transform: skew(-27deg);
        top: 0;
        left: 0;
        animation: b_y271 3s ease-in 0.5s infinite normal forwards
    }

    @keyframes b_y271 {
        0% {
            transform: translateX(-48px) skew(-27deg)
        }

        33% {
            transform: translateX(1000%) skew(-27deg)
        }

        100% {
            transform: translateX(1000%) skew(-27deg)
        }
    }

    .pmL015aj {
        padding: 64px 8px 8px 8px;
        background: linear-gradient(#03627e, #2ea88f);
        text-align: center
    }

    .pmL015aj .OAOKg4J2 {
        display: inline-block;
        width: 64px
    }

    .pmL015aj .eGZJ57Ws {
        margin: 24px 0 0 0;
        font-size: 17px;
        line-height: 24px;
        color: #fff
    }

    .pmL015aj .SvV7Sgwq {
        line-height: 24px;
        font-size: 16px;
        font-weight: 500;
        margin: 4px 0 0 0;
        color: #fff
    }

    .pmL015aj .aNDtfFRx {
        background: rgba(255,255,255,0.16);
        margin-top: 24px;
        border-radius: 4px;
        padding: 24px 8px 8px 8px
    }

    .pmL015aj .aNDtfFRx .qLSdhtP5 {
        line-height: 28px;
        font-size: 18px;
        margin: 0 0 0 10px;
        color: #fff;
        text-align: center;
        font-weight: bold
    }

    .pmL015aj .aNDtfFRx .qLSdhtP5 .w2jlVEhB {
        width: 18px;
        margin-right: 8px;
        position: relative;
        top: -1px
    }

    .pmL015aj .aNDtfFRx .CoPV1Tmz {
        line-height: 16px;
        font-size: 14px;
        font-weight: normal;
        margin: 8px 0 0 0;
        color: #fff;
        text-align: left;
        padding-left: 16px
    }

    .pmL015aj .aNDtfFRx .CoPV1Tmz span.xlkPImrs {
        font-size: 8px;
        position: relative;
        margin-right: 12px;
        top: 1px;
        vertical-align: top;
        display: inline-block
    }

    .pmL015aj .aNDtfFRx .CoPV1Tmz span.DaHKmk2y {
        display: inline-block;
        width: calc(100% - 50px)
    }

    .pmL015aj .aNDtfFRx .CoPV1Tmz span.DaHKmk2y:first-letter {
        text-transform: uppercase
    }

    .RIsGx0qT {
        padding: 64px 8px 8px 8px;
        background-color: #e4ebf8;
        text-align: center
    }

    .RIsGx0qT .OAOKg4J2 {
        display: inline-block;
        width: 167px
    }

    .RIsGx0qT .eGZJ57Ws {
        margin: 24px 0 0 0;
        font-size: 17px;
        line-height: 24px;
        color: #fff
    }

    .RIsGx0qT .SvV7Sgwq {
        line-height: 24px;
        font-size: 16px;
        font-weight: 500;
        margin: 4px 0 0 0;
        color: #fff
    }

    .RIsGx0qT .aNDtfFRx {
        padding: 24px 0px 8px 0px
    }

    .RIsGx0qT .aNDtfFRx .qLSdhtP5 {
        line-height: 32px;
        font-size: 22px;
        margin: 0 0 0 10px;
        color: #fff;
        text-align: center;
        font-weight: bold
    }

    .RIsGx0qT .aNDtfFRx .qLSdhtP5 .w2jlVEhB {
        width: 18px;
        margin-right: 8px;
        position: relative;
        top: 4px;
        font-size: 24px
    }

    .RIsGx0qT .aNDtfFRx .CoPV1Tmz {
        line-height: 24px;
        font-size: 16px;
        font-weight: normal;
        margin: 8px 0 0 0;
        color: #000;
        text-align: center;
        padding: 0 24px
    }

    .qdusWkLJ {
        text-align: center;
        width: 100%
    }

    .qdusWkLJ .eoxvV46F {
        display: inline-block;
        border-radius: 4px;
        margin-top: 24px;
        vertical-align: top;
        padding: 0 8px;
        width: 50%
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F {
        background-color: #fff;
        border-radius: 4px;
        padding: 32px 8px 8px 8px;
        box-shadow: 0 2px 12px 0 rgba(0,0,0,0.08);
        position: relative
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .zB7hBsLZ {
        font-size: 11px;
        margin-top: 8px;
        line-height: 18px;
        color: #757575
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .JfokrOOq {
        position: absolute;
        top: -13px;
        left: 0;
        right: 0;
        width: 100%;
        text-align: center
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .JfokrOOq .CR1a5cEb {
        color: #fff;
        margin: 0 auto;
        font-size: 12px;
        padding: 0 12px;
        line-height: 20px;
        display: inline-block;
        border-radius: 10px;
        background: #8bc34a;
        max-width: 85%
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .GHXXIsXC,.qdusWkLJ .eoxvV46F .nKn5ZX9F .o1AhIRs5,.qdusWkLJ .eoxvV46F .nKn5ZX9F .K2FRjrBi {
        margin: 0
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .GHXXIsXC {
        line-height: 26px;
        font-size: 18px;
        color: #000;
        font-weight: bold;
        white-space: nowrap;
        margin: 0
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .o1AhIRs5 {
        line-height: 22px;
        font-size: 18px;
        margin: 0;
        color: #000000
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .NUwttmGK {
        margin: 12px auto;
        width: 40px;
        height: 1px;
        background-color: #e2e2e2
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .K2FRjrBi {
        line-height: 24px;
        font-size: 16px;
        color: #212121;
        font-weight: 500;
        margin: 16px 0 0 0
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .K2FRjrBi strike {
        color: #bdbdbd;
        margin-left: 8px
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .T4RmCfA_ {
        line-height: 40px;
        font-size: 14px;
        background-color: #000;
        color: #fff;
        border-radius: 4px;
        margin: 20px 0 0 0;
        border: 1px solid #000;
        width: 100%;
        font-weight: 500
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .nT2WgTNP {
        line-height: 40px;
        font-size: 14px;
        background-color: #fff;
        color: #000;
        border: 1px solid #000;
        border-radius: 4px;
        margin: 24px 0 0 0;
        width: 100%;
        font-weight: 500
    }

    .qdusWkLJ .eoxvV46F .nKn5ZX9F .nT2WgTNP .ss3VaFfg {
        color: #000;
        font-size: 18px;
        position: relative;
        top: 4px;
        left: -10px
    }

    .qdusWkLJ .eoxvV46F.SIBQcohS {
        opacity: 1
    }

    .qdusWkLJ .eoxvV46F.SIBQcohS .nKn5ZX9F .JfokrOOq .CR1a5cEb {
        width: 100px;
        height: 20px;
        border-radius: 10px;
        background-image: linear-gradient(97deg, #2872ae, #7ec0f4 164%) !important;
        font-size: 10px;
        line-height: 1.8;
        letter-spacing: 0;
        padding: 1px 0 0
    }

    .qdusWkLJ .eoxvV46F.SIBQcohS .nKn5ZX9F.HzZKDEmb {
        border: 1px solid #e2e2e2;
        height: 169px;
        padding: 8px;
        box-sizing: content-box
    }

    .qdusWkLJ .eoxvV46F.SIBQcohS .nKn5ZX9F.HzZKDEmb .GHXXIsXC {
        font-size: 14px;
        line-height: 20px;
        margin-top: 14px
    }

    .qdusWkLJ .eoxvV46F.SIBQcohS .nKn5ZX9F.HzZKDEmb .NUwttmGK {
        margin: 10px auto
    }

    .qdusWkLJ .eoxvV46F.SIBQcohS .nKn5ZX9F.HzZKDEmb .K2FRjrBi {
        letter-spacing: 0;
        font-size: 14px;
        font-weight: 500;
        line-height: 1.93;
        color: #212121
    }

    .qdusWkLJ .eoxvV46F.SIBQcohS .nKn5ZX9F.HzZKDEmb .T4RmCfA_ {
        margin-top: 16px;
        margin-top: 16px;
        padding: 0 6px;
        border-top: none;
        border-bottom: none
    }

    .ieMYM8L6 {
        padding: 32px 16px 24px;
        background-color: #ffffff
    }

    .ieMYM8L6 .xK3LiCmp {
        display: none
    }

    .ieMYM8L6 .FGfnNUGq {
        padding-top: 24px;
        width: auto;
        border: 1px solid #e2e2e2;
        border-radius: 4px
    }

    .ieMYM8L6 .FGfnNUGq .ZDOEO0TW .xZurD70P {
        width: 100%;
        padding: 0 16px;
        text-align: center;
        position: relative;
        display: inline-block
    }

    .ieMYM8L6 .FGfnNUGq .ZDOEO0TW .xZurD70P .owC_anX4 {
        line-height: 24px;
        font-size: 14px;
        font-weight: 500;
        color: #212121;
        margin: 0
    }

    .ieMYM8L6 .FGfnNUGq .ZDOEO0TW .xZurD70P .owC_anX4 .HseEdQ6O {
        height: 24px;
        width: auto
    }

    .ieMYM8L6 .FGfnNUGq .ZDOEO0TW .xZurD70P .owC_anX4 span {
        display: inline-block;
        line-height: 24px;
        font-size: 16px;
        margin-left: 8px;
        position: relative;
        top: 2px
    }

    .ieMYM8L6 .FGfnNUGq .ZDOEO0TW .xZurD70P .iw9WaPak {
        line-height: 44px;
        font-size: 30px;
        font-weight: bold;
        color: #000000;
        margin: 8px 0 0 0
    }

    .ieMYM8L6 .FGfnNUGq .ZDOEO0TW .xZurD70P .AJD_lknz {
        line-height: 18px;
        font-size: 12px;
        font-weight: normal;
        color: #757575;
        margin: 4px 0 0 0
    }

    .ieMYM8L6 .FGfnNUGq .ZDOEO0TW .xZurD70P .baadzWAQ {
        display: inline-block;
        line-height: 24px;
        font-size: 12px;
        background-color: #f0f0f0;
        width: 24px;
        text-align: center;
        border-radius: 12px;
        margin: 0;
        position: absolute;
        right: -12px;
        top: calc(50% - 12px)
    }

    .ieMYM8L6 .FGfnNUGq .ZDOEO0TW .l1V9NvdX .owC_anX4,.ieMYM8L6 .FGfnNUGq .ZDOEO0TW .l1V9NvdX .iw9WaPak {
        color: #117883
    }

    .ieMYM8L6 .FGfnNUGq .qLSdhtP5 {
        margin: 16px;
        padding-top: 32px;
        border-top: 1px solid #e2e2e2;
        font-size: 18px;
        font-weight: bold;
        line-height: 28px;
        text-align: center;
        color: #042426
    }

    .ieMYM8L6 .FGfnNUGq .IO91jCD_ {
        padding: 0 24px;
        height: 100px
    }

    .ieMYM8L6 .FGfnNUGq .zQ4ZI9rL {
        background: linear-gradient(#03627e, #2ea88f) !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.24) !important;
        border: 2px solid #fff !important;
        height: 32px !important;
        width: 32px !important
    }

    .ieMYM8L6 .FGfnNUGq .zQ4ZI9rL:after {
        content: none !important
    }

    .ieMYM8L6 .FGfnNUGq .vROxmDK9 {
        height: 8px !important;
        box-shadow: none !important;
        background-color: #a1cbce !important;
        top: 40px
    }

    .ieMYM8L6 .FGfnNUGq .Kc3UZkyi {
        background-color: #137b84 !important
    }

    .ieMYM8L6 .FGfnNUGq .Wov7jRlv {
        line-height: 18px !important;
        font-size: 11px !important;
        top: -60px !important;
        color: #757575 !important;
        white-space: nowrap
    }

    .ieMYM8L6 .FGfnNUGq .VtGbbswQ {
        font-weight: 500 !important;
        color: #212121 !important
    }

    .ieMYM8L6 .IEi2heYX {
        padding-bottom: 24px
    }

    .ieMYM8L6.uhGwKMW4 .FGfnNUGq .ZDOEO0TW .xZurD70P .owC_anX4 {
        color: #212121;
        font-size: 16px;
        line-height: 24px;
        font-weight: 500
    }

    .ieMYM8L6.uhGwKMW4 .FGfnNUGq .ZDOEO0TW .xZurD70P .iw9WaPak {
        color: #b59927
    }

    .ieMYM8L6.uhGwKMW4 .FGfnNUGq .qLSdhtP5 {
        color: #042426;
        font-size: 18px;
        line-height: 28px
    }

    .ieMYM8L6.uhGwKMW4 .FGfnNUGq .Kc3UZkyi {
        background: linear-gradient(94deg, #ab9025, #e2be2e 165%) !important
    }

    .ieMYM8L6.uhGwKMW4 .FGfnNUGq .vROxmDK9 {
        background-color: rgba(202,170,43,0.27) !important
    }

    .ieMYM8L6.uhGwKMW4 .FGfnNUGq .zQ4ZI9rL {
        background-image: linear-gradient(121deg, #ab9025, #e2be2e 141%) !important
    }

    .ieMYM8L6.HoFV8SbO {
        padding: 16px 16px 16px
    }

    .ieMYM8L6.HoFV8SbO .xK3LiCmp {
        width: 100%;
        height: 48px;
        background: white;
        padding: 10px;
        display: block;
        margin: 0 auto;
        border-radius: 4px;
        font-size: 14px;
        color: #212121;
        font-weight: 500
    }

    .ieMYM8L6.HoFV8SbO .FGfnNUGq {
        border: none;
        border-radius: 0;
        background: #212121;
        padding: 28px 16px 16px
    }

    .ieMYM8L6.HoFV8SbO .FGfnNUGq .ZDOEO0TW .xZurD70P {
        padding: unset
    }

    .ieMYM8L6.HoFV8SbO .FGfnNUGq .ZDOEO0TW .xZurD70P .owC_anX4 {
        font-size: 16px;
        line-height: 24px;
        font-weight: 500;
        color: #fff
    }

    .ieMYM8L6.HoFV8SbO .FGfnNUGq .ZDOEO0TW .xZurD70P .iw9WaPak {
        color: #cc9614;
        font-size: 26px;
        line-height: 36px
    }

    .ieMYM8L6.HoFV8SbO .FGfnNUGq .qLSdhtP5 {
        color: #f0f0f0;
        font-size: 18px;
        font-weight: bold;
        line-height: 28px;
        border-top: 1px solid rgba(226,226,226,0.1);
        margin: 20px 0 24px 0
    }

    .ieMYM8L6.HoFV8SbO .FGfnNUGq .vROxmDK9 {
        background-color: #f9e3ae !important
    }

    .ieMYM8L6.HoFV8SbO .FGfnNUGq .zQ4ZI9rL {
        background: radial-gradient(circle at 50% 50%, #f3ca67, #e8b029 48%) !important;
        height: 24px !important;
        width: 24px !important
    }

    .ieMYM8L6.HoFV8SbO .FGfnNUGq .Kc3UZkyi {
        background-color: #f0c253 !important
    }

    .bRqVXqPJ {
        background-image: linear-gradient(#03627e, #2ea88f);
        text-align: center;
        padding: 24px 8px
    }

    .bRqVXqPJ .qLSdhtP5 {
        line-height: 28px;
        font-size: 20px;
        color: #fff;
        font-weight: 700;
        text-align: center;
        margin: 0
    }

    .bRqVXqPJ .CoPV1Tmz {
        line-height: 24px;
        font-size: 14px;
        color: #fff;
        margin: 4px 0 0 0;
        text-align: center
    }

    .eH7WtDxt {
        padding: 24px 16px
    }

    .eH7WtDxt .qLSdhtP5 {
        line-height: 28px;
        font-size: 18px;
        color: #212121;
        font-weight: bold;
        text-align: left;
        margin: 0 0 24px 0
    }

    .eH7WtDxt ul {
        list-style: none;
        padding-left: 16px;
        margin: 0
    }

    .eH7WtDxt ul li {
        line-height: 24px;
        font-size: 14px;
        color: #212121;
        font-weight: normal;
        margin: 8px 0 0 0;
        padding-left: 4px
    }

    .eH7WtDxt ul li:before {
        content: "\2022";
        color: #999;
        font-weight: bold;
        display: inline-block;
        width: 1em;
        margin-left: -1em
    }

    .eH7WtDxt ul li:first-child {
        margin-top: 0
    }

    .RTnavDAA {
        height: 16px;
        background-color: #f5f5f5;
        border-bottom: 1px solid #e2e2e2;
        border-top: 1px solid #e2e2e2
    }

    .L2XQVLjz {
        padding: 64px 16px 16px 16px;
        text-align: center
    }

    .L2XQVLjz .OAOKg4J2 {
        height: 64px;
        display: inline-block
    }

    .L2XQVLjz .qLSdhtP5 {
        line-height: 28px;
        font-size: 18px;
        color: #212121;
        margin: 8px 0 0 0
    }

    .L2XQVLjz .JCAcBwvQ {
        background-image: url(https://static.urbanclap.com/dist-product-web/client/0d81d915827ab3b0f9cf.png);
        background-size: contain;
        background-repeat: no-repeat;
        background-position: bottom;
        background-position-y: 30px;
        overflow: visible;
        line-height: 36px;
        display: inline-block
    }

    .L2XQVLjz .gOW5d7qp {
        margin: 34px 0 0 0;
        border-radius: 4px;
        background-color: #137b84;
        text-align: center;
        padding: 24px 0;
        background-image: url(https://static.urbanclap.com/dist-product-web/client/22edb9f0e396fca6ede0.png);
        background-size: contain;
        background-repeat: no-repeat
    }

    .L2XQVLjz .gOW5d7qp .sibjxGPa {
        line-height: 20px;
        font-size: 16px;
        margin: 0;
        color: #fff
    }

    .L2XQVLjz .gOW5d7qp .o1AhIRs5 {
        line-height: 32px;
        font-size: 24px;
        color: #fff;
        font-weight: bold;
        margin: 8px 0 0 0
    }

    .L2XQVLjz .gOW5d7qp .Uual4EgB {
        line-height: 32px;
        font-size: 16px;
        color: #fff;
        margin: 0;
        font-weight: 400
    }

    .Pee2f6Oz {
        background-color: #e7f1f2;
        padding: 0 16px 16px 16px;
        border-bottom: 8px solid #f0f0f0;
        text-align: center
    }

    .Pee2f6Oz .qLSdhtP5 {
        line-height: 28px;
        font-size: 18px;
        color: #000;
        margin: 0
    }

    .Pee2f6Oz .CoPV1Tmz {
        line-height: 24px;
        font-size: 14px;
        color: #000;
        margin: 4px 0 0 0
    }

    .Pee2f6Oz .T4RmCfA_ {
        line-height: 48px;
        font-size: 14px;
        color: #fff;
        font-weight: 500;
        border-radius: 4px;
        width: 100%;
        background-color: #000;
        overflow: hidden;
        position: relative
    }

    .Pee2f6Oz .T4RmCfA_ .H5xSHEay {
        background-color: #228d27;
        color: #fff;
        position: absolute;
        display: inline;
        left: -20px;
        font-size: 12px;
        line-height: 16px;
        padding: 0 22px;
        transform: rotateZ(-45deg);
        top: 9px;
        font-weight: bold
    }

    .Hz7cSnlC {
        background-color: #f5f5f5;
        padding: 24px 16px 8px 16px
    }

    .Hz7cSnlC .qLSdhtP5 {
        line-height: 24px;
        font-size: 16px;
        color: #212121;
        font-weight: 500;
        margin: 0;
        text-align: center
    }

    .Hz7cSnlC .CoPV1Tmz {
        line-height: 24px;
        font-size: 14px;
        color: #757575;
        margin: 4px 0 0 0;
        font-weight: normal;
        text-align: center
    }

    .Hz7cSnlC .sZ8UBZSA {
        background-color: #fff;
        border: 1px solid #e2e2e2;
        border-radius: 4px;
        padding: 0 16px 24px 16px;
        width: 100%;
        margin-top: 24px
    }

    .Hz7cSnlC .sZ8UBZSA .nzRCIa5o {
        width: 100%;
        margin-top: 24px
    }

    .Hz7cSnlC .sZ8UBZSA .nzRCIa5o .xN3PfIBb {
        height: 56px;
        width: 56px;
        display: inline-block;
        float: left;
        vertical-align: top;
        object-fit: cover;
        border-radius: 4px
    }

    .Hz7cSnlC .sZ8UBZSA .nzRCIa5o .sPiFl9II {
        width: calc(100% - 56px);
        padding-left: 16px;
        display: inline-block;
        float: left;
        vertical-align: top
    }

    .Hz7cSnlC .sZ8UBZSA .nzRCIa5o .sPiFl9II .MFwvivML {
        line-height: 28px;
        font-size: 14px;
        color: #212121;
        font-weight: 600;
        margin: 0;
        margin-top: 4px
    }

    .Hz7cSnlC .sZ8UBZSA .nzRCIa5o .sPiFl9II .Yj5LE7r2 {
        line-height: 16px;
        font-size: 14px;
        color: #137b84;
        margin: 0
    }

    .e2x6oB8L {
        background-color: #f5f5f5;
        padding: 16px
    }

    .e2x6oB8L .B1s23Spl {
        text-align: center;
        padding: 24px 16px 0 16px;
        border: 1px solid #e2e2e2;
        border-radius: 4px;
        background-color: #fff
    }

    .e2x6oB8L .B1s23Spl .qLSdhtP5 {
        line-height: 28px;
        font-size: 18px;
        font-weight: bold;
        margin: 0;
        color: #212121
    }

    .e2x6oB8L .B1s23Spl .eIu2EpRS {
        line-height: 24px;
        font-size: 16px;
        color: #228d27;
        margin: 8px 0 0 0
    }

    .e2x6oB8L .B1s23Spl .etIkKgp_ {
        width: 100%;
        margin-top: 24px
    }

    .EJEZRDDM {
        padding: 88px 16px 16px 16px;
        text-align: center
    }

    .EJEZRDDM .qLSdhtP5 {
        line-height: 32px;
        font-size: 24px;
        margin: 0 0 0 10px;
        color: #000;
        text-align: center;
        font-weight: bold
    }

    .EJEZRDDM .qLSdhtP5 .w2jlVEhB {
        width: 32px;
        height: 32px;
        margin-right: 8px;
        position: relative;
        top: 3px;
        display: inline-block
    }

    .EJEZRDDM .CoPV1Tmz {
        line-height: 24px;
        font-size: 16px;
        color: #000;
        margin: 12px 0 0 0;
        padding: 0 8px
    }

    .EJEZRDDM .jLyMUlsX {
        margin: 32px 0 0 0;
        padding: 24px 8px 8px 8px;
        background: rgba(36,108,243,0.1);
        border-radius: 4px
    }

    .EJEZRDDM .jLyMUlsX .T6pUFzLG {
        font-size: 32px;
        margin: 0;
        -webkit-text-fill-color: transparent;
        background: linear-gradient(to right, #0046c1 0%, #0099de 100%);
        -webkit-background-clip: text;
        font-weight: 800
    }

    .EJEZRDDM .jLyMUlsX .V2I_SdUn {
        margin: 5px 0 0 0;
        font-size: 12px;
        line-height: 12px;
        color: #212121;
        font-weight: bold;
        text-transform: uppercase
    }

    .EJEZRDDM .jLyMUlsX .V2I_SdUn .hRKA6rQH,.EJEZRDDM .jLyMUlsX .V2I_SdUn .dRRnAyv8 {
        height: 3px;
        width: 26px;
        display: inline-block;
        position: relative;
        top: -2px
    }

    .EJEZRDDM .jLyMUlsX .V2I_SdUn .hRKA6rQH {
        background: linear-gradient(to right, #0099de 0%, #0046c1 100%);
        left: -8px
    }

    .EJEZRDDM .jLyMUlsX .V2I_SdUn .dRRnAyv8 {
        background: linear-gradient(to right, #0046c1 0%, #0099de 100%);
        left: 8px
    }

    .EJEZRDDM .jLyMUlsX .C9eClBrj {
        width: 168px;
        display: inline-block;
        margin-top: 24px
    }

    .EJEZRDDM .jLyMUlsX .qK3x54EF {
        width: 224px;
        display: inline-block;
        margin: 24px 0 0 0
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ {
        background-color: #000;
        color: #fff;
        line-height: 56px;
        text-align: center;
        font-size: 16px;
        font-weight: 500;
        border-radius: 4px;
        width: 100%;
        height: 56px;
        overflow: hidden
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ .QWopDQ7f {
        transition: transform 0s;
        transform: translateY(0)
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ .QWopDQ7f strike {
        font-weight: 500;
        color: rgba(255,255,255,0.6);
        margin-left: 8px
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ .QWopDQ7f .ss3VaFfg {
        position: relative;
        top: 2px;
        left: -10px
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ .QWopDQ7f .RjBnYqYO {
        opacity: 1;
        border: 1px solid #212121;
        border-radius: 4px;
        height: 56px;
        background: #fff;
        color: #212121
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ .QWopDQ7f .LgO9oA4X {
        transition: opacity 0.3s;
        opacity: 1
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ .LAiWN0gb {
        transform: translateY(-56px)
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ .LAiWN0gb .RjBnYqYO {
        opacity: 1
    }

    .EJEZRDDM .jLyMUlsX .T4RmCfA_ .LAiWN0gb .LgO9oA4X {
        opacity: 0
    }

    .LVEDrRSd {
        padding: 24px;
        border-bottom: 16px solid #f0f0f0;
        text-align: center
    }

    .LVEDrRSd .qLSdhtP5 {
        line-height: 30px;
        font-size: 22px;
        color: #000;
        font-weight: bold
    }

    .LVEDrRSd .q2o9RU7j {
        display: inline-block;
        height: 1px;
        width: 100px;
        background-color: #e2e2e2;
        margin-top: 24px
    }

    .LVEDrRSd .apNGR2Zt {
        margin: 24px 0 0 0
    }

    .LVEDrRSd .apNGR2Zt .B5phTWRv {
        line-height: 30px;
        font-size: 18px;
        font-weight: bold;
        color: #000;
        margin: 0
    }

    .LVEDrRSd .apNGR2Zt .VnYieOmp {
        line-height: 16px;
        font-size: 16px;
        font-weight: bold;
        margin: 8px 0 0 0;
        color: #246cf3
    }

    .LVEDrRSd .apNGR2Zt .VnYieOmp .w2jlVEhB {
        width: 20px;
        height: 20px;
        margin-right: 4px;
        position: relative;
        top: 5px;
        display: inline-block;
        font-size: 20px
    }

    .Z5HoeMv3 {
        background: linear-gradient(#303aee, #5387ee);
        padding: 24px 16px 16px 16px;
        text-align: center;
        color: #fff
    }

    .Z5HoeMv3 .qK3x54EF {
        width: 140px;
        display: inline-block
    }

    .Z5HoeMv3 .wtMBLjz4 {
        line-height: 24px;
        font-size: 18px;
        font-weight: 500;
        margin: 16px 0 0 0
    }

    .Z5HoeMv3 .T4RmCfA_ {
        width: 100%;
        line-height: 48px;
        text-align: center;
        color: #22262d;
        font-size: 16px;
        margin: 24px 0 0 0;
        background-color: #fff;
        border-radius: 4px;
        font-weight: 500
    }

    .Z5HoeMv3 .T4RmCfA_ .CbKv1ePh {
        font-size: 7px;
        margin-left: 7px;
        margin-right: 4px;
        position: relative;
        top: -2px
    }

    .Z5HoeMv3 .LAiWN0gb {
        border: 1px solid #22262d
    }

    .H1IYzUSb {
        padding: 32px 16px
    }

    .H1IYzUSb .qLSdhtP5 {
        line-height: 32px;
        font-size: 22px;
        color: #212121;
        margin: 0;
        text-align: center
    }

    .H1IYzUSb .SzOkiQWa {
        width: 100%;
        display: table
    }

    .H1IYzUSb .SzOkiQWa .bmFWUyRK {
        display: table-row;
        width: 100%;
        text-align: left
    }

    .H1IYzUSb .SzOkiQWa .bmFWUyRK .qK3x54EF,.H1IYzUSb .SzOkiQWa .bmFWUyRK .DaHKmk2y {
        display: table-cell;
        vertical-align: middle;
        padding-top: 24px
    }

    .H1IYzUSb .SzOkiQWa .bmFWUyRK .qK3x54EF {
        width: 64px
    }

    .H1IYzUSb .SzOkiQWa .bmFWUyRK .qK3x54EF img {
        height: 64px;
        width: 64px;
        display: inline-block
    }

    .H1IYzUSb .SzOkiQWa .bmFWUyRK .DaHKmk2y {
        width: calc(100% - 64px);
        text-align: left;
        padding-left: 16px
    }

    .H1IYzUSb .SzOkiQWa .bmFWUyRK .DaHKmk2y p.JX6ObHSh {
        line-height: 20px;
        font-size: 16px;
        color: #212121;
        font-weight: bold;
        margin: 0
    }

    .H1IYzUSb .SzOkiQWa .bmFWUyRK .DaHKmk2y p.CoPV1Tmz {
        line-height: 20px;
        font-size: 14px;
        color: #757575;
        font-weight: normal;
        margin: 8px 0 0 0
    }

    .jSDonkb8 {
        background-color: #ffffff;
        text-align: center;
        padding-top: 40px
    }

    .jSDonkb8 .qK3x54EF {
        width: 100%
    }

    .jSDonkb8 .qLSdhtP5 {
        line-height: 28px;
        font-size: 18px;
        color: #212121;
        font-weight: bold;
        margin: 16px 16px 0 16px
    }

    .jSDonkb8 .RVU6fQwF {
        height: 0;
        width: 240px;
        display: block;
        margin: 16px auto 0 auto;
        border: 0;
        background: transparent;
        border-top: 1px dashed #d4d4d4
    }

    .jSDonkb8 .g5YRSDka {
        margin: 16px 0 0 0;
        display: block
    }

    .jSDonkb8 .g5YRSDka .K2FRjrBi {
        line-height: 30px;
        font-size: 18px;
        color: #212121;
        font-weight: normal;
        display: inline-block
    }

    .jSDonkb8 .g5YRSDka .K2FRjrBi strike {
        margin-left: 4px
    }

    .jSDonkb8 .g5YRSDka .adzpfvhH {
        line-height: 20px;
        font-size: 12px;
        background-color: #1a8e1e;
        border-radius: 4px;
        padding: 0 8px;
        margin: 12px 0 0 8px;
        display: inline-block;
        color: #fff;
        position: relative;
        top: -2px
    }

    .jSDonkb8 .T4RmCfA_ {
        line-height: 48px;
        font-size: 16px;
        color: #fff;
        background-color: #212121;
        margin: 16px 16px 0 16px;
        font-weight: 500;
        border-radius: 4px
    }

    .jSDonkb8 .LAiWN0gb {
        border: 1px solid #212121;
        background-color: #ffffff;
        color: #212121
    }

    .jSDonkb8 .RdJ8gRuh {
        line-height: 18px;
        font-size: 12px;
        color: #212121;
        margin: 12px 0 16px 0
    }

    .iaqT_r__ {
        padding-top: 28px;
        padding-left: 16px;
        padding-right: 16px;
        text-align: center;
        justify-content: center
    }

    .iaqT_r__.uC9ZJRYE .qLSdhtP5 {
        text-align: left
    }

    .iaqT_r__ .qLSdhtP5 {
        margin: 0;
        font-size: 18px;
        font-weight: bold;
        line-height: 24px;
        color: #212121
    }

    .iaqT_r__ .HzZKDEmb {
        box-shadow: none !important;
        border: solid 2px rgba(10,67,71,0.16)
    }

    .iaqT_r__ .AGIjKagd {
        font-size: 10px !important;
        font-weight: bold;
        line-height: 18px !important;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: #ffffff;
        border: 1px solid #ffffff
    }

    @media screen and (max-width: 320px) {
        .iaqT_r__ .AGIjKagd {
            letter-spacing:0 !important
        }
    }

    .iaqT_r__ .xafMpRjQ {
        background-image: linear-gradient(97deg, #03627e, #2fa88f) !important;
        border: 1px solid #ffffff
    }

    .iaqT_r__ .zNNDEA_R {
        background-image: linear-gradient(97deg, #4179ea, #3045ee) !important;
        border: 1px solid #ffffff
    }

    .iaqT_r__ .XkzljmoQ {
        background-image: linear-gradient(97deg, #ab9025, #e2be2e) !important
    }

    .iaqT_r__ .a_WdIKMs {
        height: 28px;
        border-bottom: 1px solid #eaeaea;
        margin-left: -16px;
        margin-right: -16px
    }

    .iaqT_r__ .ahpzkDFx {
        border-bottom: 16px solid #f0f0f0;
        margin-left: -16px;
        margin-right: -16px;
        padding-left: 16px;
        padding-right: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        vertical-align: middle
    }

    .iaqT_r__ .ahpzkDFx .ACHZSxgW {
        width: 12px;
        height: 12px;
        margin-right: 4px
    }

    .iaqT_r__ .ahpzkDFx .vPamiA_p {
        font-size: 12px;
        color: #757575;
        margin-top: 10px;
        margin-bottom: 10px
    }

    .oRF5_fn8 {
        height: 16px;
        background-color: #f0f0f0
    }

    .MprKegPo {
        text-decoration: line-through !important
    }

    .DDhcnlcM {
        padding: 32px 16px 24px 16px;
        border-top: 8px solid #f0f0f0
    }

    .DDhcnlcM ._rQM1TDd {
        border: 1px solid #e2e2e2;
        border-radius: 4px;
        overflow: hidden
    }

    .DDhcnlcM ._rQM1TDd .y38iznDg {
        padding: 24px 16px;
        background-color: #1d5053;
        display: flex;
        flex-direction: column;
        text-align: left
    }

    .DDhcnlcM ._rQM1TDd .y38iznDg .G6SzG0JM .XqjWt1vk {
        height: 40px
    }

    .DDhcnlcM ._rQM1TDd .y38iznDg .qLSdhtP5 {
        line-height: 24px;
        font-size: 16px;
        color: #f0f0f0;
        margin: 12px 0 0 0
    }

    .DDhcnlcM ._rQM1TDd .y38iznDg .P11BJ5UJ {
        line-height: 32px;
        font-size: 22px;
        color: #fff;
        font-weight: bold;
        margin: 0
    }

    .DDhcnlcM ._rQM1TDd .fOGXJEFa {
        padding: 24px 16px
    }

    .DDhcnlcM ._rQM1TDd .fOGXJEFa .JX6ObHSh {
        line-height: 24px;
        font-size: 16px;
        color: #212121;
        font-weight: bold;
        margin: 0
    }

    .DDhcnlcM ._rQM1TDd .fOGXJEFa .chNcHxzv .JITRX9Oj {
        display: flex;
        flex-direction: row;
        margin-top: 24px;
        align-items: center
    }

    .DDhcnlcM ._rQM1TDd .fOGXJEFa .chNcHxzv .JITRX9Oj .qK3x54EF .XqjWt1vk {
        width: 40px
    }

    .DDhcnlcM ._rQM1TDd .fOGXJEFa .chNcHxzv .JITRX9Oj .jzD9sK90 {
        display: flex;
        flex-direction: column;
        padding-left: 20px
    }

    .DDhcnlcM ._rQM1TDd .fOGXJEFa .chNcHxzv .JITRX9Oj .jzD9sK90 .qLSdhtP5 {
        line-height: 24px;
        font-size: 14px;
        color: #666666;
        margin: 0
    }

    .DDhcnlcM ._rQM1TDd .fOGXJEFa .chNcHxzv .JITRX9Oj .jzD9sK90 .P11BJ5UJ {
        line-height: 24px;
        font-size: 16px;
        color: #212121;
        margin: 0;
        font-weight: bold
    }

    .DDhcnlcM .gNVP2h6S {
        background-color: #212121;
        border-radius: 4px;
        outline: none;
        border: 0;
        height: 56px;
        display: flex;
        width: 100%;
        margin-top: 20px;
        color: #fff;
        line-height: 16px;
        font-size: 14px;
        font-weight: 500;
        justify-content: center;
        cursor: pointer
    }

    @keyframes ans9ddKk {
        0% {
            left: -100px
        }

        50% {
            left: 300px
        }

        100% {
            left: 500px
        }
    }

    .Yx7OKkRi {
        padding: 28px 16px 0px;
        margin-bottom: 28px
    }

    .Yx7OKkRi .nNXt3_dY {
        border: solid 1px #e2e2e2;
        border-radius: 4px;
        padding: 24px 0px 0px
    }

    .Yx7OKkRi .nNXt3_dY .PZHz6eIs {
        display: flex;
        align-items: center;
        flex-direction: column
    }

    .Yx7OKkRi .nNXt3_dY .PZHz6eIs .kso5w8ol {
        width: 32px;
        height: 32px
    }

    .Yx7OKkRi .nNXt3_dY .CDFMYCLv {
        text-align: center;
        margin: 12px 0 32px;
        font-size: 18px;
        line-height: 26px;
        font-weight: 600;
        color: #cc9614
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY {
        padding: 0 8px
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy {
        display: flex;
        justify-content: center;
        margin-bottom: 40px
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy:nth-of-type(2n+1) {
        flex-direction: row-reverse
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy .pbQahOQn {
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        position: relative;
        margin-bottom: 8px
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy .pbQahOQn:before {
        content: " ";
        position: absolute;
        bottom: -2px;
        width: 48px;
        height: 1px;
        border: solid 1px #cc9614
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy .oF1WSXZZ {
        width: 132px;
        height: 132px;
        border-radius: 4px;
        object-fit: cover;
        margin: 0 8px
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy .ZSoNsv6z {
        width: 132px;
        margin: 0 8px;
        flex-basis: 50%
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy .ZSoNsv6z .ZKQp2Cwb {
        font-size: 11px;
        color: #ff8c00;
        font-weight: 600;
        line-height: 18px;
        margin-top: 8px
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy .ZSoNsv6z .XFR8LYr8 .IVSUYQ4Z {
        font-size: 12px;
        line-height: 20px;
        color: #757575;
        margin-left: 15px
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .vvJGcUhy .ZSoNsv6z .XFR8LYr8 .IVSUYQ4Z:before {
        content: "[";
        font-family: ucglyphs !important;
        font-size: 9px;
        color: #999999;
        margin-left: -15px;
        position: absolute
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS {
        position: relative
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS .vvJGcUhy {
        opacity: 0.3
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS.QpWuyhMm .vvJGcUhy {
        flex-direction: row-reverse
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS.QpWuyhMm .vvJGcUhy:nth-of-type(2n+1) {
        flex-direction: row
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS.iXdCnssl .vvJGcUhy {
        flex-direction: row
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS.iXdCnssl .vvJGcUhy:nth-of-type(2n+1) {
        flex-direction: row-reverse
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS .tZX0sWxZ {
        position: absolute;
        top: 0;
        width: 100%;
        height: 100%;
        display: flex;
        background: rgba(0,0,0,0.1);
        align-items: center;
        justify-content: center
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS .tZX0sWxZ .W5vmDleI {
        width: 206px;
        height: 52px;
        border-radius: 4px;
        background-image: radial-gradient(circle at 11% 50%, #dfa928, #d39707 52%);
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS .tZX0sWxZ .W5vmDleI .BHulhMwi {
        position: absolute;
        width: 50px;
        height: 100px;
        background: rgba(26,255,255,0.1);
        transform: skew(-35deg, 0deg);
        left: 60px;
        animation: ans9ddKk linear 2.5s infinite
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS .tZX0sWxZ .W5vmDleI .e1InraVM:before {
        content: "\E050";
        font-size: 18px;
        position: relative;
        font-family: ucglyphs !important;
        left: -7px;
        color: white
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS .tZX0sWxZ .W5vmDleI .o3qUFfaZ .S2p13L5h {
        font-size: 12px;
        font-weight: bold;
        color: white;
        line-height: 18px
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS .tZX0sWxZ .W5vmDleI .o3qUFfaZ .RKdeuXkC {
        font-size: 10px;
        color: white;
        line-height: 16px
    }

    .Yx7OKkRi .nNXt3_dY .xqM4aelY .XucrvTdS.RmkyWpCR {
        display: none
    }

    .Mji6OENC {
        position: relative;
        height: 246px
    }

    .J1BhWTvv {
        position: absolute;
        opacity: 0;
        background-size: cover;
        background-position: center;
        transition: opacity 1s;
        width: 100%;
        height: 246px
    }

    .qZzn8Jkl {
        opacity: 1
    }

    .phgyv2sk {
        margin: 16px 0 0;
        font-size: 22px;
        font-weight: bold;
        line-height: 30px
    }

    .N6Qj3tgF {
        margin: 4px 0 0;
        font-size: 14px;
        line-height: 20px
    }

    .yvXzkzVv .N6Qj3tgF {
        font-size: 12px
    }

    .VueJzteK {
        position: absolute;
        top: 56%;
        width: 220px;
        left: 50%;
        transform: translateX(-50%);
        text-align: center
    }

    .VueJzteK .phgyv2sk {
        font-size: 18px;
        line-height: 26px
    }

    .VueJzteK .N6Qj3tgF {
        font-size: 11px;
        line-height: 16px
    }

    .r8dOjx1r {
        position: relative
    }

    .r8dOjx1r.a7eOhUpP {
        display: flex;
        flex-direction: column-reverse;
        width: 328px;
        margin-left: calc((100% - (328px + 32px)) / 2);
        height: 96px;
        border-radius: 8px;
        justify-content: center;
        overflow: hidden;
        position: absolute;
        bottom: -48px
    }

    .r8dOjx1r.a7eOhUpP .CTz83r21 {
        margin-top: 2px;
        font-size: 13px;
        line-height: 20px
    }

    .r8dOjx1r.a7eOhUpP .yKQoYcAl {
        margin-top: 0;
        font-size: 18px;
        line-height: 28px
    }

    .r8dOjx1r.a7eOhUpP .eI9p_iAK {
        width: 40px;
        height: 40px;
        bottom: -1px
    }

    .r8dOjx1r.a7eOhUpP .uXfekt60 {
        left: -1px
    }

    .r8dOjx1r.a7eOhUpP .AKMD5ia7 {
        right: -1px
    }

    .r8dOjx1r .yKQoYcAl {
        margin: 8px 0 0;
        font-size: 22px;
        font-weight: bold;
        line-height: 30px
    }

    .r8dOjx1r .CTz83r21 {
        margin: 24px 0 0;
        font-size: 14px;
        line-height: 20px
    }

    .r8dOjx1r .eI9p_iAK {
        width: 80px;
        height: 80px;
        position: absolute;
        bottom: -24px
    }

    .r8dOjx1r .uXfekt60 {
        left: -8px
    }

    .r8dOjx1r .AKMD5ia7 {
        right: -8px
    }

    .YgbL7dtu {
        padding: 136px 16px 28px;
        position: relative;
        text-align: center;
        color: #ffffff
    }

    .YgbL7dtu.u7hbBKve {
        padding-top: 84px;
        margin-bottom: 66px
    }

    .YgbL7dtu.Ob2q26AU {
        background: linear-gradient(54deg, #0f0c29 0%, #262058 21.56%, #2a2461 50.52%, #29245d 69.4%, #24243e 100%);
        padding: 34px 16px 28px
    }

    .YgbL7dtu .PFRNtzW8 {
        flex: 1;
        margin-top: 16px;
        border-radius: 8px;
        padding: 12px 6px;
        margin-left: 8px;
        margin-right: 8px;
        background: rgba(255,255,255,0.1)
    }

    .YgbL7dtu .PFRNtzW8.gpHRxJFr {
        background: none;
        padding: 12px
    }

    .YgbL7dtu .PFRNtzW8.gpHRxJFr .wSYcCdST {
        font-size: 15px;
        line-height: 24px
    }

    .YgbL7dtu .PFRNtzW8 .wSYcCdST {
        font-size: 18px;
        font-weight: bold;
        color: #e1a127
    }

    .YgbL7dtu .PFRNtzW8 .s7_iVNbn {
        color: #ffffff;
        font-style: normal;
        font-weight: normal;
        margin-top: 4px;
        font-size: 12px;
        line-height: 18px;
        text-align: center
    }

    .YgbL7dtu .PFRNtzW8 .a77cDsMB {
        font-style: normal;
        font-weight: normal;
        font-size: 10px;
        line-height: 14px;
        text-align: center;
        color: #f5f5f5
    }

    .YgbL7dtu .nU4mcYBc {
        width: 100%;
        grid-auto-rows: 1fr;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(100px, 1fr))
    }

    .YgbL7dtu .GpRb2Vnq {
        position: absolute;
        bottom: -64px;
        width: 328px;
        height: 1px;
        margin-left: calc((100% - (328px + 32px)) / 2);
        background-image: linear-gradient(to right, #e2e2e2 33%, rgba(255,255,255,0) 0%);
        background-position: bottom;
        background-size: 4px 1px;
        background-repeat: repeat-x
    }

    .YgbL7dtu .tx9m_BLw {
        position: absolute !important;
        top: 0;
        left: 0;
        width: 100%;
        height: 100% !important;
        z-index: -1
    }

    .YgbL7dtu .tx9m_BLw .sohQE5SN {
        height: 100% !important;
        background-size: 100% !important;
        background-position: center top !important
    }

    .YgbL7dtu .zO7crsMp {
        width: 56px;
        min-height: 56px
    }

    .YgbL7dtu .I4DQNxtP {
        margin: 12px 0 0;
        font-size: 12px;
        font-weight: 500;
        letter-spacing: 4px;
        text-align: center;
        text-transform: uppercase
    }

    .YgbL7dtu .qB4GqQRI {
        margin: 4px auto 0;
        max-width: 280px;
        font-size: 15px;
        font-weight: bold;
        line-height: 24px
    }

    .YgbL7dtu .N4XOqrFC {
        font-weight: lighter;
        font-size: 12px;
        line-height: 1.5;
        margin-bottom: 28px
    }

    .YgbL7dtu .R93XcHii {
        font-weight: bold;
        max-width: fit-content
    }

    .YgbL7dtu .eaJnldeK {
        margin-top: 8px;
        font-size: 20px;
        line-height: 30px
    }

    .YgbL7dtu .eaJnldeK.Vkq0gPeM {
        position: relative
    }

    .YgbL7dtu .eaJnldeK.Vkq0gPeM:before {
        content: "+";
        position: absolute;
        bottom: -80px;
        left: 50%;
        transform: translateX(-50%);
        color: #ccc;
        font-weight: 500
    }

    .YgbL7dtu .eaJnldeK.Vkq0gPeM:after {
        height: 17px;
        content: " ";
        position: absolute;
        color: #514a93;
        width: 100%;
        transform: translateX(-50%);
        background-image: linear-gradient(to right, #514a93 33%, rgba(255,255,255,0) 0%);
        background-position: bottom;
        background-size: 7px 1px;
        background-repeat: repeat-x
    }

    .YgbL7dtu .i5FiISru {
        width: 144px;
        min-height: 2px;
        border-bottom: 1px solid white;
        margin: 16px auto 0;
        position: relative
    }

    .YgbL7dtu .i5FiISru:after {
        content: " ";
        width: 80%;
        position: absolute;
        right: -1px;
        border-bottom: 1px solid white;
        transform-origin: right;
        transform: rotate(-1deg);
        top: 2px
    }

    .U2L84Vns {
        background-image: linear-gradient(to top, #094347, #094347 33%, rgba(0,0,0,0.04) 93%, rgba(0,0,0,0.04)) !important
    }

    .edzvPOrJ {
        background-image: linear-gradient(to top, #2976b4 35%, rgba(0,0,0,0.04) 103%, rgba(0,0,0,0.04) 108%) !important
    }

    .rEBKGdW3 {
        background-image: linear-gradient(to top, #ab9025, #ab9025 33%, rgba(0,0,0,0.04) 93%, rgba(0,0,0,0.04)) !important
    }

    .M7148J9G {
        position: relative
    }

    .M7148J9G.YgbL7dtu {
        padding: 175px 16px 28px;
        background-image: linear-gradient(to top, #212121 24%, rgba(0,0,0,0.04) 124%, rgba(0,0,0,0.04) 131%)
    }

    .M7148J9G .i5FiISru {
        display: none
    }

    .M7148J9G .qB4GqQRI {
        display: block
    }

    .M7148J9G .zO7crsMp {
        width: 180px;
        height: auto;
        position: absolute;
        left: 50%;
        margin-left: -90px;
        top: 122px
    }

    .M7148J9G.U2L84Vns {
        background-image: linear-gradient(to top, #212121, #212121 18%, rgba(0,0,0,0.04) 93%, rgba(0,0,0,0.04)) !important
    }

    .M7148J9G .I4DQNxtP {
        margin-bottom: 75px
    }

    .jIdtJQJN.YgbL7dtu {
        padding-top: 80px;
        min-height: 360px;
        padding-top: 100%;
        padding-bottom: 0;
        height: 0;
        background-image: none !important
    }

    .jIdtJQJN.YgbL7dtu .ImhnoGyM {
        position: absolute;
        top: 24%;
        left: 50%;
        transform: translateX(-50%);
        z-index: 10
    }

    .jIdtJQJN.YgbL7dtu .tx9m_BLw {
        z-index: unset;
        display: flex;
        justify-content: flex-end;
        flex-direction: column
    }

    .jIdtJQJN.YgbL7dtu .qB4GqQRI {
        font-size: 18px;
        line-height: 26px;
        width: 225px
    }

    .jIdtJQJN.YgbL7dtu .i5FiISru {
        margin: 10px auto 30px
    }

    .jIdtJQJN.YgbL7dtu .w_IPSoOw {
        flex-basis: 0;
        transition: flex-basis 700ms linear
    }

    @keyframes yetzvKI7 {
        0% {
            flex-basis: 0
        }

        100% {
            flex-basis: 240px
        }
    }

    .gnOlmkD2 {
        width: 72px;
        height: 28px;
        border-radius: 4px;
        border: 1px solid #eaeaea;
        font-weight: 500;
        font-size: 12px;
        line-height: 18px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background: #2a2461;
        z-index: 111
    }

    .hAbcJhc0 .j8tVoPfF {
        position: absolute;
        bottom: 10px;
        width: 100%;
        left: 0;
        display: flex;
        flex-direction: row;
        justify-content: center;
        z-index: 2;
        padding: 0 12.5%;
        z-index: 10
    }

    .hAbcJhc0 .j8tVoPfF .XVpHZflH {
        height: 4px;
        background: #707070;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        flex-basis: 100%
    }

    .hAbcJhc0 .j8tVoPfF .XVpHZflH .zKJl0Xu7 {
        height: 4px;
        border-radius: 30px;
        background: #fff;
        flex-basis: 0;
        transition: flex-basis 700ms linear
    }

    .hAbcJhc0 .t9SpjgnZ {
        position: absolute;
        z-index: 9;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        padding: 16px;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        transition: opacity 0.5s
    }

    .hAbcJhc0 .t9SpjgnZ .cz2mEy3G {
        width: 100%;
        height: 100%;
        position: absolute;
        left: 0;
        top: 0;
        z-index: -1
    }

    .eoJKFXTm {
        display: flex;
        flex-direction: column;
        padding: 0 16px
    }

    .eoJKFXTm.tkNVZCBQ .pHptmkdC {
        background: white
    }

    .eoJKFXTm.SO3v0VkQ {
        padding: 28px 16px 100px
    }

    .eoJKFXTm .pHptmkdC {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding: 16px;
        border: 1px solid #f5f5f5;
        margin-bottom: 8px;
        border-radius: 4px
    }

    .eoJKFXTm .pHptmkdC .NGRVdfEK {
        font-weight: 500;
        font-size: 12px;
        line-height: 18px
    }

    .eoJKFXTm .pHptmkdC .NGRVdfEK .rmtO2pqx {
        display: inline-block;
        width: 16px;
        height: 16px;
        border: 2px solid #dadada;
        border-radius: 50%;
        margin-right: 12px;
        position: relative
    }

    .eoJKFXTm .pHptmkdC .NGRVdfEK .rmtO2pqx:before {
        content: " ";
        position: absolute;
        left: 50%;
        top: 50%;
        width: 8px;
        height: 8px;
        background: #4236be;
        border-radius: 50%;
        transform: scale(0);
        transition: transform 150ms
    }

    .eoJKFXTm .pHptmkdC .NGRVdfEK .rmtO2pqx.EXQitzsw {
        border-color: #4236be
    }

    .eoJKFXTm .pHptmkdC .NGRVdfEK .rmtO2pqx.EXQitzsw:before {
        transform: scale(1) translate(-50%, -50%)
    }

    .eoJKFXTm .pHptmkdC .NGRVdfEK .jyidRvE_ {
        margin-right: 8px
    }

    .eoJKFXTm .pHptmkdC .NGRVdfEK .tFs2b_RY {
        color: #4236be;
        font-size: 9px;
        line-height: 14px;
        font-weight: bold;
        letter-spacing: 0.6px
    }

    .eoJKFXTm .pHptmkdC .NGRVdfEK,.eoJKFXTm .pHptmkdC .PDBX26lP {
        display: flex;
        align-items: center
    }

    .eoJKFXTm .pHptmkdC .PDBX26lP {
        font-size: 12px;
        font-weight: 400;
        line-height: 18px
    }

    .eoJKFXTm .pHptmkdC .PDBX26lP .TOA64YAc {
        font-size: 12px;
        margin-left: 8px
    }

    .eoJKFXTm .pHptmkdC .PDBX26lP .g_n0ea0t {
        color: #9e9e9e;
        text-decoration: line-through
    }

    .eoJKFXTm .GhEAjE9d {
        position: fixed;
        bottom: 0;
        left: 50%;
        width: 100vw;
        transform: translateX(-50%);
        background: white;
        display: block;
        margin: 0 auto;
        border-radius: 4px;
        font-size: 14px;
        font-weight: 500;
        border: 1px solid #f5f5f5;
        z-index: 1000;
        border-radius: 0
    }

    .eoJKFXTm .GhEAjE9d .kgMrKMFd {
        background: #f2effd;
        height: 0;
        overflow: hidden;
        color: #4236be;
        font-size: 12px;
        line-height: 18px;
        text-align: center;
        display: flex;
        align-items: center;
        flex-direction: row;
        justify-content: center;
        transition: height 150ms
    }

    .eoJKFXTm .GhEAjE9d .kgMrKMFd.TE1PHv1G {
        height: 32px
    }

    .eoJKFXTm .GhEAjE9d .IJ9dHABX {
        color: white;
        background: black;
        width: 344px;
        height: 48px;
        margin: 8px auto;
        display: block;
        border-radius: 4px
    }

    .N_AKM8JP {
        background: #fff;
        padding: 24px 16px 0 16px;
        border-bottom: 16px solid #f0f0f0
    }

    .N_AKM8JP .k9ZO6__p {
        line-height: 28px;
        font-size: 18px;
        color: #212121;
        font-weight: bold;
        text-align: left;
        margin: 0
    }

    .N_AKM8JP .a6RpTXuD {
        margin-top: 8px
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa {
        padding: 16px 0;
        background-color: #fff
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .JjnWsUeq {
        width: 100%
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .JjnWsUeq .tFeguW4e {
        width: 56px;
        display: inline-block;
        float: left;
        vertical-align: top
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .JjnWsUeq .tFeguW4e p {
        display: inline-block;
        height: 40px;
        width: 40px;
        color: #fff;
        line-height: 40px;
        font-size: 20px;
        background-color: #c1c2fa;
        margin: 0;
        border-radius: 50%;
        text-align: center;
        text-transform: uppercase
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .JjnWsUeq .GG3Z4Ilo {
        width: calc(100% - 56px);
        display: inline-block;
        float: left;
        text-align: left;
        vertical-align: top
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .JjnWsUeq .GG3Z4Ilo .zYz2XFdT {
        line-height: 18px;
        font-size: 12px;
        font-weight: bold;
        color: #212121;
        margin: 0
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .JjnWsUeq .GG3Z4Ilo .zKmEQIdL {
        line-height: 18px;
        font-size: 12px;
        color: #acacac;
        margin: 2px 0 0 0
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .dQkvocfz {
        padding-left: 56px;
        margin-top: 8px
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .dQkvocfz .JjmDEDvM {
        color: #424242;
        line-height: 18px;
        font-size: 13px;
        margin: 0
    }

    .N_AKM8JP .a6RpTXuD .HYbsWTRa .dQkvocfz .f0TILP8l {
        display: none;
        line-height: 16px;
        font-size: 12px;
        color: #9e9e9e;
        margin: 8px 0 0 0
    }

    .N_AKM8JP .vRuVTjD8 {
        line-height: 56px;
        text-align: center;
        font-weight: 500;
        font-size: 14px;
        color: #455bef;
        margin: 0 -16px 0 -16px;
        border-top: 1px solid #f0f0f0
    }

    .N_AKM8JP .TVdXrg0G {
        border-bottom: 1px solid #f0f0f0
    }

    .N_AKM8JP.HEN5lobe .vRuVTjD8 {
        color: #cc9614
    }

    .Tm9qjY7x {
        padding: 24px 16px;
        border-bottom: 16px solid #f0f0f0
    }

    .Tm9qjY7x .EVJR4Qut {
        line-height: 28px;
        font-size: 18px;
        color: #212121;
        background-color: #ffffff;
        font-weight: bold;
        text-align: left;
        margin: 0 0 24px 0
    }

    .Tm9qjY7x .ARtkjeij {
        margin-left: -16px;
        margin-right: -16px;
        width: auto
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM {
        border-bottom: 1px solid #f0f0f0
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .J2563THO {
        display: flex;
        width: 100%;
        justify-content: space-between
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .J2563THO .pSai_wuJ {
        display: flex
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .J2563THO .pSai_wuJ .Q0De4RbC {
        width: 24px;
        height: 24px;
        margin: 16px
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .J2563THO .pSai_wuJ .eosnqFgy {
        line-height: 24px;
        font-size: 14px;
        color: #212121;
        text-align: left;
        vertical-align: top;
        padding: 12px 16px
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .J2563THO .pSai_wuJ .c38nOJeV {
        font-weight: 500;
        color: #212121
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .J2563THO .sjm5Xlv9 {
        margin-right: 16px;
        width: 20px;
        font-size: 12px;
        color: #757575;
        vertical-align: top;
        padding: 12px 16px
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .J2563THO .sjm5Xlv9:before {
        float: left;
        position: relative;
        top: 6px
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .TTxQfMPm p {
        margin: 16px 0 0 56px;
        line-height: 24px;
        font-size: 14px;
        color: #212121;
        padding: 0 16px
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .TTxQfMPm p:first-child {
        margin-top: 4px
    }

    .Tm9qjY7x .ARtkjeij .wZulxqrM .TTxQfMPm p:last-child {
        margin-bottom: 16px
    }

    .Tm9qjY7x .ARtkjeij .B6owEtCS {
        border-top: 1px solid #f0f0f0
    }

    .Tm9qjY7x .ARtkjeij .B6owEtCS p {
        margin: 16px 0 0 0;
        font-size: 14px;
        color: #304fee;
        text-align: center
    }

    .Kd4_VSwd {
        margin: 28px 16px 0px 16px;
        padding: 8px;
        background: #fcf8f4;
        border-radius: 4px;
        border: 1px solid #eaeaea;
        box-sizing: border-box
    }

    .qz2PYt2y {
        padding: 16px 24px;
        background: #fcf8f4
    }

    .cARfoK5z {
        display: flex;
        align-items: center;
        justify-content: center;
        vertical-align: middle
    }

    .cARfoK5z .TarRXgvG {
        width: 16px;
        height: 16px;
        margin-bottom: 2px;
        margin-right: 5px
    }

    .cARfoK5z .Ztw7It6f {
        font-size: 14px;
        margin: 0px 4px 0px;
        font-weight: 500;
        line-height: 18px;
        color: #8b572a
    }

    .iPe7wr0N {
        font-size: 12px;
        color: #757575;
        line-height: 16px;
        text-align: center;
        margin-top: 4px;
        vertical-align: middle
    }

    .rugYjXXS {
        border-bottom: 16px solid #f0f0f0
    }

    .jLzUk6vD {
        padding-top: 28px;
        padding-bottom: 12px;
        border-bottom: 1px solid #f0f0f0;
        text-align: center
    }

    .bx7K7NlY {
        padding-top: 28px;
        padding-bottom: 24px;
        border-bottom: 16px solid #f0f0f0
    }

    .hAeWBDHk {
        width: 100%;
        padding-left: 16px;
        padding-right: 16px;
        font-style: normal;
        font-weight: bold;
        font-size: 18px;
        line-height: 26px;
        color: #212121
    }

    .NDU7ImgU {
        width: 100%;
        padding-left: 16px;
        padding-right: 16px;
        margin-top: 4px;
        font-style: normal;
        font-weight: 500;
        font-size: 12px;
        line-height: 18px;
        color: #106a75
    }

    .DGkeTqvf {
        display: flex;
        margin-left: 8px;
        margin-right: 8px;
        margin-top: 12px
    }

    .DGkeTqvf .TSpsEg9B {
        width: 33%;
        margin-left: 8px;
        margin-right: 8px
    }

    .DGkeTqvf .TSpsEg9B .O1boEE8Y {
        width: 100%;
        object-fit: cover
    }

    .DGkeTqvf .TSpsEg9B .M36j0b3Q {
        width: 100%;
        text-align: center;
        font-style: normal;
        font-weight: normal;
        font-size: 11px;
        line-height: 16px;
        letter-spacing: 0.2px;
        color: #757575
    }

    .Ey1ukkTR {
        text-align: center;
        padding-top: 24px
    }

    .Ey1ukkTR .V7DdD9tn {
        width: 56px;
        height: 56px
    }

    .Ey1ukkTR .aNtjcRm8 {
        font-style: normal;
        font-weight: bold;
        font-size: 18px;
        margin-left: 30px;
        margin-right: 30px;
        margin-top: 12px;
        line-height: 26px;
        text-align: center;
        color: #ffffff
    }

    .Ey1ukkTR .jnt_iqfy {
        font-size: 12px;
        line-height: 18px;
        margin-left: 20px;
        margin-right: 20px;
        margin-top: 12px;
        text-align: center;
        color: #f7f2ea
    }

    .Ey1ukkTR .ujndNDYd {
        font-size: 12px;
        line-height: 18px;
        margin-left: 16px;
        margin-right: 16px;
        margin-top: 4px;
        text-align: center;
        color: #f7f2ea
    }

    .nXPJkDF1 {
        padding-top: 28px;
        padding-bottom: 28px;
        border-bottom: 16px solid #f0f0f0
    }

    .nXPJkDF1 .n6jFs3Sc {
        width: 100%;
        font-style: normal;
        font-weight: bold;
        font-size: 18px;
        line-height: 26px;
        padding-left: 16px;
        padding-right: 16px;
        color: #212121
    }

    .nXPJkDF1 .pqkuS3c_ {
        display: flex;
        align-items: center;
        justify-content: center;
        vertical-align: middle;
        border-bottom: 1px solid #f0f0f0;
        padding-bottom: 16px;
        padding-left: 16px;
        padding-right: 16px
    }

    .nXPJkDF1 .pqkuS3c_ .Zt5gdVi3 {
        width: 12px;
        height: 12px;
        margin-right: 4px
    }

    .nXPJkDF1 .pqkuS3c_ .ZrLo_17g {
        font-size: 12px;
        color: #757575;
        margin-top: 10px;
        margin-bottom: 10px
    }

    @keyframes inoKm7ob {
        from {
            transform: translateX(1080px)
        }

        to {
            transform: translateX(-64px)
        }
    }

    .nXPJkDF1 .kwCk6rfv {
        margin-top: 24px;
        overflow: auto;
        align-items: start;
        justify-content: start;
        white-space: nowrap
    }

    .nXPJkDF1 .kwCk6rfv .lltXNz3y,.nXPJkDF1 .kwCk6rfv .VsKHJzfC {
        display: flex;
        width: 1080px;
        transform: translateX(-64px);
        align-items: center;
        vertical-align: middle;
        position: relative;
        animation: inoKm7ob 18s linear infinite
    }

    .nXPJkDF1 .kwCk6rfv .VsKHJzfC {
        margin-left: 50px
    }

    .nXPJkDF1 .kwCk6rfv .lltXNz3y {
        margin-top: 16px;
        margin-left: -30px
    }

    .nXPJkDF1 .kwCk6rfv .DcOQxzgN {
        display: flex;
        align-items: center;
        justify-content: center;
        vertical-align: middle;
        margin-left: 16px;
        padding: 10px 12px;
        width: 270px;
        min-width: 270px;
        background: #f7f8fa;
        border-radius: 4px;
        position: relative;
        left: -100%
    }

    .nXPJkDF1 .kwCk6rfv .DcOQxzgN .T265mNFt {
        width: 56px;
        height: 56px;
        border-radius: 28px;
        margin-right: 8px
    }

    .nXPJkDF1 .kwCk6rfv .DcOQxzgN .WGbFsa2A {
        font-style: normal;
        font-weight: 500;
        font-size: 12px;
        line-height: 18px;
        color: #212121
    }

    .nXPJkDF1 .kwCk6rfv .DcOQxzgN .Hi3KM_A0 {
        font-style: normal;
        font-weight: normal;
        font-size: 11px;
        margin-top: 2px;
        line-height: 16px;
        letter-spacing: 0.2px;
        color: #757575
    }

    .nXPJkDF1 .kwCk6rfv .DcOQxzgN .R9ntWNJr {
        margin-top: 2px;
        display: flex;
        align-items: center;
        justify-content: center
    }

    .nXPJkDF1 .kwCk6rfv .DcOQxzgN .R9ntWNJr .ZUMEp1Zi {
        width: 16px;
        height: 16px;
        margin-right: 4px
    }

    .nXPJkDF1 .kwCk6rfv .DcOQxzgN .R9ntWNJr .LIi4vLA_ {
        font-style: normal;
        font-weight: 500;
        font-size: 12px;
        line-height: 18px;
        color: #106a75
    }

    .TlX2buae {
        background: linear-gradient(71.17deg, rgba(112,71,245,0.07) -2.07%, rgba(103,68,238,0) 98.22%);
        border-bottom: 16px solid #f0f0f0
    }

    .TlX2buae .vH5OzxyX {
        padding-right: 28px;
        padding-left: 28px;
        padding-top: 28px;
        font-style: normal;
        font-weight: bold;
        font-size: 18px;
        line-height: 26px;
        text-align: center;
        color: #212121
    }

    .TlX2buae .jB7zj7Lz {
        text-align: center;
        padding-bottom: 28px
    }

    .TlX2buae .jB7zj7Lz .QXlGM1rd {
        margin-left: 16px;
        margin-right: 16px;
        height: 1px;
        border-top: 1px dashed #eaeaea
    }

    .TlX2buae .jB7zj7Lz .Kwu_wdp_ {
        display: inline-block;
        padding-left: 4px;
        padding-right: 4px;
        padding-top: 2px;
        padding-bottom: 2px;
        margin-right: 16px;
        margin-left: 16px;
        margin-top: 28px;
        background: #228d27;
        border-radius: 2px;
        font-style: normal;
        font-weight: bold;
        font-size: 9px;
        line-height: 14px;
        letter-spacing: 0.6px;
        text-transform: uppercase;
        color: #ffffff
    }

    .TlX2buae .jB7zj7Lz .TAVWZAJ4 {
        margin-right: 16px;
        margin-left: 16px;
        margin-top: 6px;
        font-style: normal;
        font-weight: bold;
        font-size: 15px;
        line-height: 24px;
        color: #212121
    }

    .TlX2buae .fkVj4YP8 {
        overflow: auto;
        display: grid;
        height: 100%;
        grid-template-columns: repeat(2, 60%);
        grid-template-rows: repeat(2, 50%);
        grid-auto-columns: 60%;
        grid-auto-flow: column
    }

    .TlX2buae .jHQWfMY_ {
        padding-left: 16px;
        padding-top: 16px;
        display: flex;
        align-items: center
    }

    .TlX2buae .jHQWfMY_ .DLpMXY3C {
        width: 80px;
        height: 80px;
        border-radius: 8px
    }

    .TlX2buae .jHQWfMY_ .Y80Rwo1v {
        font-style: normal;
        font-weight: normal;
        text-align: left;
        font-size: 13px;
        margin-left: 16px;
        line-height: 20px;
        color: #757575
    }

    @use "sass:map";@use "sass:list";.vf0yKDb1 {
        position: relative;
        border: none;
        max-height: 100% !important
    }

    .QL5nrKBh {
        height: 500px;
        width: 600px
    }

    @media only screen and (max-width: 768px) {
        .QL5nrKBh {
            height:100%;
            width: 100%
        }

        .QL5nrKBh * {
            box-sizing: border-box
        }
    }

    .f8pZafeh {
        --bottomsheet-height: 255px
    }

    @media only screen and (max-width: 768px) {
        .f8pZafeh {
            height:var(--bottomsheet-height);
            width: 100%;
            box-shadow: 0 5px 15px 0px #888888
        }

        .f8pZafeh * {
            box-sizing: border-box
        }
    }

    .J8vLvPaZ {
        font-family: "ucglyphs" !important;
        font-size: 24px;
        line-height: 24px;
        position: absolute;
        right: 16px;
        z-index: 1;
        top: 16px;
        cursor: pointer
    }

    .NWAhhUCF {
        padding: 32px 16px !important;
        justify-content: flex-start !important
    }

    .DsbSHWD6 {
        display: flex !important
    }

    .O4PSE_s4 {
        position: relative;
        height: 100%;
        min-height: inherit;
        width: 100%;
        overflow: hidden
    }

    .O4PSE_s4 label {
        display: inline-block
    }

    .eWndwMx6 {
        overflow: auto
    }

    .AmuLW8nV {
        position: relative;
        height: 100%;
        min-height: inherit;
        width: 100%
    }

    .AmuLW8nV .ACORbRup {
        z-index: -1;
        animation-name: KG_v4Buo;
        animation-duration: 0.4s;
        animation-fill-mode: forwards;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88)
    }

    @keyframes KG_v4Buo {
        0% {
            transform: translateX(0)
        }

        100% {
            transform: translateX(0%)
        }
    }

    .AmuLW8nV .AdYiPWDj {
        animation: QUJM0Nfz 0.4s cubic-bezier(0.41, 0.45, 0.43, 0.88) forwards;
        z-index: 1
    }

    @keyframes QUJM0Nfz {
        0% {
            transform: translateX(0)
        }

        100% {
            transform: translateX(100%)
        }
    }

    .AmuLW8nV .Er_fR9P1 {
        z-index: 1;
        animation: ZJDSsUB7 0.4s cubic-bezier(0.41, 0.45, 0.43, 0.88);
        animation-delay: 0s
    }

    @keyframes ZJDSsUB7 {
        0% {
            transform: translateX(100%)
        }

        50% {
            transform: translateX(0)
        }

        100% {
            transform: translateX(0)
        }
    }

    .AmuLW8nV .t0jSudDI {
        animation: epQ4SIDN 0.5s;
        animation-delay: 0s;
        transform: translateX(0%)
    }

    @keyframes epQ4SIDN {
        0% {
            z-index: -1
        }

        99% {
            z-index: -1
        }

        100% {
            z-index: 1
        }
    }

    .AmuLW8nV button {
        position: relative
    }

    .OypTUYQu {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        transition: all 0.1s;
        flex: 1;
    }

    .UChGJqiv {
        background-color: #f3f3f3 !important;
        pointer-events: none !important;
    }

    .ogRnoRUY {
        display: none;
    }

    .QaS1QlIe {
        font-size: 18px;
        padding: 13px 10px 10px 5px;
        display: block;
        width: 100%;
        border: none;
        border-bottom: 1px solid #757575;
    }

    .QaS1QlIe:focus {
        outline: none;
    }

    .JiRGAaql {
        color: #999;
        font-size: 18px;
        font-weight: normal;
        position: absolute;
        pointer-events: none;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        transition: 0.2s ease all;
    }

    .QaS1QlIe:focus ~ .JiRGAaql, .QaS1QlIe:valid ~ .JiRGAaql {
        top: 4px;
        transform: none;
        font-size: 12px;
        color: #999;
    }

    .KnfzI9MC {
        position: relative;
        display: block;
        width: 100%;
    }

    .KnfzI9MC:before, .KnfzI9MC:after {
        content: '';
        height: 2px;
        width: 0;
        bottom: 1px;
        position: absolute;
        background: #212121;
        transition: 0.2s ease all;
    }

    .KnfzI9MC:before {
        left: 50%;
    }

    .KnfzI9MC:after {
        right: 50%;
    }

    .QaS1QlIe:focus ~ .KnfzI9MC:before, .QaS1QlIe:focus ~ .KnfzI9MC:after {
        width: 50%;
    }

    .J3oZWDP2 {
        position: absolute;
        height: 60%;
        width: 100px;
        top: 25%;
        left: 0;
        pointer-events: none;
        opacity: 0.5;
    }

    .QaS1QlIe:focus ~ .J3oZWDP2 {
        -webkit-animation: RZJeu9DX 0.3s ease;
        -moz-animation: RZJeu9DX 0.3s ease;
        animation: RZJeu9DX 0.3s ease;
    }

    @-webkit-keyframes RZJeu9DX {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    @-moz-keyframes RZJeu9DX {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    @keyframes RZJeu9DX {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    .bjj4W94k {
        position: relative;
        display: inline-block;
        width: 100px;
    }

    .bjj4W94k .hGVzSJyY {
        cursor: pointer;
        border: 1px solid #eee;
        position: relative;
    }

    .bjj4W94k .hGVzSJyY .IQf6uqIQ span:before {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
    }

    .bjj4W94k .eGhr2LFf {
        position: absolute;
        top: 100%;
        width: 100%;
        list-style-type: none;
        padding: 0;
        margin: 0;
        border: 1px solid #eee;
        overflow: auto;
        transition: 0.15s ease-in;
        opacity: 0;
        visibility: hidden;
        z-index: -1;
        box-sizing: border-box;
    }

    .bjj4W94k .eGhr2LFf .YN6Nf10B {
        padding: 12px 24px;
        cursor: pointer;
    }

    .bjj4W94k .Hx0mN_Zt {
        opacity: 1;
        visibility: visible;
        z-index: 4;
    }

    .NYG5srDq {
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        opacity: 0;
        background-color: rgba(0,0,0,0.7);
        transition-property: opacity;
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-name: TXv2IxVp;
        z-index: 10;
        animation-duration: 0.25s;
        transition-duration: 0.25s
    }

    .FMW0lFzR {
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88);
        will-change: transform;
        background-color: #f0f0f0;
        border-radius: 2px;
        position: absolute;
        overflow: hidden
    }

    .VNQspTUm {
        animation-name: wIBACPeW;
        left: 0;
        transform: translateX(-100%)
    }

    .Sa8ZZPa0 {
        animation-name: VSZ83ASd
    }

    .l6cxHkN3 {
        animation-name: Im99alVc;
        right: 0;
        transform: translateX(100%)
    }

    .Ft_dkFst {
        animation-name: tvgat7Bo;
        animation-fill-mode: forwards;
        animation-direction: normal;
        transform: translateX(0)
    }

    @keyframes tvgat7Bo {
        from {
            transform: translateX(0)
        }

        to {
            transform: translateX(100%)
        }
    }

    .V3evI4zu {
        animation-name: GSlUxLpv;
        top: 0;
        transform: translateY(-100%)
    }

    .QIscmpt7 {
        animation-name: gbRrXrfM
    }

    .Zr0LjaQs {
        transform: translateY(100%);
        bottom: 0;
        animation-name: fxXP5AsJ
    }

    .JeUbMxDn {
        animation-name: _EPMHDAL;
        animation-fill-mode: forwards;
        animation-direction: normal;
        transform: translateY(0)
    }

    @keyframes _EPMHDAL {
        from {
            transform: translateY(0)
        }

        to {
            transform: translateY(100%)
        }
    }

    .rDwJZ9d9 {
        transform: translate(-50%, 0%);
        left: 50%;
        top: 50%;
        animation-name: Er5Yrakm
    }

    .yVEX1XTF {
        animation-name: XEVEN0ja
    }

    .e9aW9i2m {
        transform: translate(-50%, -50%);
        left: 50%;
        top: 50%;
        -webkit-transform: translate(-50%, -50%) scale(1.05);
        transform: translate(-50%, -50%) scale(1.05);
        opacity: 0;
        animation-name: R7_jQ6mh
    }

    .Hu4uZA7F {
        animation-name: pQyx5dGR
    }

    @keyframes R7_jQ6mh {
        from {
            -webkit-transform: translate(-50%, -50%) scale(1.05);
            transform: translate(-50%, -50%) scale(1.05);
            opacity: 0
        }

        to {
            -webkit-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
            opacity: 1
        }
    }

    @keyframes pQyx5dGR {
        from {
            -webkit-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
            opacity: 1
        }

        to {
            -webkit-transform: translate(-50%, -50%) scale(0.95);
            transform: translate(-50%, -50%) scale(0.95);
            opacity: 0
        }
    }

    @keyframes Er5Yrakm {
        from {
            transform: translate(-50%, 0%)
        }

        to {
            opacity: 1;
            transform: translate(-50%, -50%)
        }
    }

    @keyframes XEVEN0ja {
        from {
            transform: translate(-50%, -50%)
        }

        to {
            opacity: 0;
            transform: translate(-50%, 0%)
        }
    }

    @keyframes GSlUxLpv {
        from {
            transform: translateY(-100%)
        }

        to {
            transform: translateY(0)
        }
    }

    @keyframes gbRrXrfM {
        from {
            transform: translateY(0)
        }

        to {
            transform: translateY(-100%)
        }
    }

    @keyframes fxXP5AsJ {
        from {
            transform: translateY(100%)
        }

        to {
            transform: translateY(0)
        }
    }

    @keyframes wIBACPeW {
        from {
            transform: translateX(-100%)
        }

        to {
            transform: translateX(0)
        }
    }

    @keyframes VSZ83ASd {
        from {
            transform: translateX(0)
        }

        to {
            transform: translateX(-100%)
        }
    }

    @keyframes Im99alVc {
        from {
            transform: translateX(100%)
        }

        to {
            transform: translateX(0)
        }
    }

    .hbTEFZyU {
        opacity: 1;
        transition-property: opacity;
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-name: UShmJzTh;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88)
    }

    @keyframes UShmJzTh {
        from {
            opacity: 1
        }

        to {
            opacity: 0
        }
    }

    @keyframes TXv2IxVp {
        from {
            opacity: 0
        }

        to {
            opacity: 1
        }
    }

    .w1SgcejF {
        display: flex;
        border: 1px solid #e2e2e2;
        height: 56px;
        border-radius: 4px;
        padding: 0;
        box-sizing: border-box
    }

    .w1SgcejF .ecV75F3F {
        display: inline-block
    }

    .w1SgcejF .ecV75F3F>img {
        width: 20px;
        margin-right: 6px
    }

    .w1SgcejF .ecV75F3F>span {
        font-size: 16px
    }

    .w1SgcejF .ecV75F3F>p {
        display: none
    }

    .w1SgcejF .g7lGqhI2 {
        width: 110px;
        display: inline-block
    }

    .w1SgcejF .fVjQg4Ty {
        height: 100%;
        box-sizing: border-box;
        border: none;
        border-right: 1px solid #e2e2e2;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center
    }

    .w1SgcejF .GdXzY_R4 {
        background-color: #fff;
        border-radius: 4px
    }

    .w1SgcejF .R6AgVr3r {
        padding: 12px 0 !important;
        text-align: center;
        border-bottom: 1px solid #e2e2e2;
        transition: all 0.15s ease-out
    }

    .w1SgcejF .R6AgVr3r:hover {
        background-color: #f6f7f8
    }

    .w1SgcejF .R6AgVr3r:last-child {
        border-bottom: none
    }

    .w1SgcejF .bF5Kkm2F {
        top: 60px !important
    }

    .w1SgcejF .O4ZSxRjl {
        border: none;
        display: inline-block;
        vertical-align: top;
        margin-top: 5px;
        flex: 1
    }

    .w1SgcejF .jcLeNnKA {
        border: none;
        color: #212121;
        padding-left: 12px;
        font-size: 16px
    }

    .w1SgcejF .XskTucUv {
        left: 12px
    }

    .w1SgcejF .TAKFjafD {
        width: 110px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
        border-right: 1px solid #e2e2e2
    }

    .w1SgcejF .TAKFjafD .dt5CXky1 span {
        display: flex;
        padding-left: 10px
    }

    .C3BFMPXZ {
        width: 100%;
        text-align: left;
        padding: 16px;
        box-sizing: border-box
    }

    .rHotfzaj {
        margin: 0;
        font-size: 22px;
        color: #212121;
        border-bottom: 1px solid #eee;
        padding-bottom: 16px
    }

    .nkhUQaCE {
        padding: 8px 0 0 0;
        list-style-type: none;
        margin: 0
    }

    .nkhUQaCE>li {
        padding: 12px 0
    }

    .nkhUQaCE>li .ecV75F3F>img {
        width: 20px;
        margin-right: 24px
    }

    .nkhUQaCE>li .ecV75F3F>p {
        font-size: 16px;
        font-weight: 600;
        display: inline-block;
        margin: 0 8px 0 0;
        color: #212121
    }

    .nkhUQaCE>li .ecV75F3F>span {
        font-size: 16px;
        font-weight: 600;
        color: #999
    }

    .caMjJpBX {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        transition: all 0.1s;
        flex: 1;
    }

    .NzLcr7zG {
        background-color: #f3f3f3 !important;
        pointer-events: none !important;
    }

    .N7DmlPX9 {
        display: none;
    }

    .oEZ1rU7r {
        font-size: 18px;
        padding: 13px 10px 10px 5px;
        display: block;
        width: 100%;
        border: none;
        border-bottom: 1px solid #757575;
    }

    .oEZ1rU7r:focus {
        outline: none;
    }

    .S89PzQpA {
        color: #999;
        font-size: 18px;
        font-weight: normal;
        position: absolute;
        pointer-events: none;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        transition: 0.2s ease all;
    }

    .oEZ1rU7r:focus ~ .S89PzQpA, .oEZ1rU7r:valid ~ .S89PzQpA {
        top: 4px;
        transform: none;
        font-size: 12px;
        color: #999;
    }

    .lDlqt5CE {
        position: relative;
        display: block;
        width: 100%;
    }

    .lDlqt5CE:before, .lDlqt5CE:after {
        content: '';
        height: 2px;
        width: 0;
        bottom: 1px;
        position: absolute;
        background: #212121;
        transition: 0.2s ease all;
    }

    .lDlqt5CE:before {
        left: 50%;
    }

    .lDlqt5CE:after {
        right: 50%;
    }

    .oEZ1rU7r:focus ~ .lDlqt5CE:before, .oEZ1rU7r:focus ~ .lDlqt5CE:after {
        width: 50%;
    }

    .usJxRtuN {
        position: absolute;
        height: 60%;
        width: 100px;
        top: 25%;
        left: 0;
        pointer-events: none;
        opacity: 0.5;
    }

    .oEZ1rU7r:focus ~ .usJxRtuN {
        -webkit-animation: b7UREgWe 0.3s ease;
        -moz-animation: b7UREgWe 0.3s ease;
        animation: b7UREgWe 0.3s ease;
    }

    @-webkit-keyframes b7UREgWe {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    @-moz-keyframes b7UREgWe {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    @keyframes b7UREgWe {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    .gXjlVnNi {
        position: relative;
        display: inline-block;
        width: 100px;
    }

    .gXjlVnNi .iGldVTlV {
        cursor: pointer;
        border: 1px solid #eee;
        position: relative;
    }

    .gXjlVnNi .iGldVTlV .G5lX8O8E span:before {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
    }

    .gXjlVnNi .vjf8ru6S {
        position: absolute;
        top: 100%;
        width: 100%;
        list-style-type: none;
        padding: 0;
        margin: 0;
        border: 1px solid #eee;
        overflow: auto;
        transition: 0.15s ease-in;
        opacity: 0;
        visibility: hidden;
        z-index: -1;
        box-sizing: border-box;
    }

    .gXjlVnNi .vjf8ru6S .PpH9Zkco {
        padding: 12px 24px;
        cursor: pointer;
    }

    .gXjlVnNi .ZVec6fI5 {
        opacity: 1;
        visibility: visible;
        z-index: 4;
    }

    .EI5Dg24M {
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        opacity: 0;
        background-color: rgba(0, 0, 0, 0.7);
        transition-property: opacity;
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-name: DbfpMb59;
        z-index: 10;
    }

    .SfW2Mzwu {
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88);
        will-change: transform;
        background-color: #fff;
        border-radius: 2px;
        position: absolute;
        overflow: hidden;
    }

    .cnJZ8h9K {
        animation-name: yCM3g_Ie;
        left: 0;
        transform: translateX(-100%);
    }

    .FetweweG {
        animation-name: quBlq2j2;
    }

    .E4zaH3y5 {
        animation-name: lm9f1rZA;
        right: 0;
        transform: translateX(100%);
    }

    .mB2apJBC {
        animation-name: jaG4Q6P_;
        animation-fill-mode: forwards;
        animation-direction: normal;
        transform: translateX(0);
    }

    @keyframes jaG4Q6P_ {
        from {
            transform: translateX(0);
        }

        to {
            transform: translateX(100%);
        }
    }

    .THQ5JKYk {
        animation-name: MOxs9sxb;
        top: 0;
        transform: translateY(-100%);
    }

    .DfsESupn {
        animation-name: WHC404z3;
    }

    .tzQTV22g {
        transform: translateY(100%);
        bottom: 0;
        animation-name: IlaiUuOc;
    }

    .GXTZRm6K {
        animation-name: axAcZ1YV;
        animation-fill-mode: forwards;
        animation-direction: normal;
        transform: translateY(0);
    }

    @keyframes axAcZ1YV {
        from {
            transform: translateY(0);
        }

        to {
            transform: translateY(100%);
        }
    }

    .tL2lqKfA {
        transform: translate(-50%, 0%);
        left: 50%;
        top: 50%;
        animation-name: LjoJHNw1;
    }

    .FXGaEUut {
        animation-name: jl6M6tSL;
    }

    .T5GhsDtv {
        transform: translate(-50%, -50%);
        left: 50%;
        top: 50%;
        -webkit-transform: translate(-50%, -50%) scale(1.05);
        transform: translate(-50%, -50%) scale(1.05);
        opacity: 0;
        animation-name: tDBoCdQm;
    }

    .eIGeulUl {
        animation-name: OTPQtobt;
    }

    @keyframes tDBoCdQm {
        from {
            -webkit-transform: translate(-50%, -50%) scale(1.05);
            transform: translate(-50%, -50%) scale(1.05);
            opacity: 0;
        }

        to {
            -webkit-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
            opacity: 1;
        }
    }

    @keyframes OTPQtobt {
        from {
            -webkit-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
            opacity: 1;
        }

        to {
            -webkit-transform: translate(-50%, -50%) scale(0.95);
            transform: translate(-50%, -50%) scale(0.95);
            opacity: 0;
        }
    }

    @keyframes LjoJHNw1 {
        from {
            transform: translate(-50%, 0%);
        }

        to {
            opacity: 1;
            transform: translate(-50%, -50%);
        }
    }

    @keyframes jl6M6tSL {
        from {
            transform: translate(-50%, -50%);
        }

        to {
            opacity: 0;
            transform: translate(-50%, 0%);
        }
    }

    @keyframes MOxs9sxb {
        from {
            transform: translateY(-100%);
        }

        to {
            transform: translateY(0);
        }
    }

    @keyframes WHC404z3 {
        from {
            transform: translateY(0);
        }

        to {
            transform: translateY(-100%);
        }
    }

    @keyframes IlaiUuOc {
        from {
            transform: translateY(100%);
        }

        to {
            transform: translateY(0);
        }
    }

    @keyframes yCM3g_Ie {
        from {
            transform: translateX(-100%);
        }

        to {
            transform: translateX(0);
        }
    }

    @keyframes quBlq2j2 {
        from {
            transform: translateX(0);
        }

        to {
            transform: translateX(-100%);
        }
    }

    @keyframes lm9f1rZA {
        from {
            transform: translateX(100%);
        }

        to {
            transform: translateX(0);
        }
    }

    .IxEFlAEB {
        opacity: 1;
        transition-property: opacity;
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-name: QCxblPFX;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88);
    }

    @keyframes QCxblPFX {
        from {
            opacity: 1;
        }

        to {
            opacity: 0;
        }
    }

    @keyframes DbfpMb59 {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

    .vs2HK88d {
        display: flex;
        border: 1px solid #e2e2e2;
        height: 56px;
        border-radius: 4px;
        padding: 0;
        box-sizing: border-box
    }

    .vs2HK88d .TML83Dki {
        display: inline-block
    }

    .vs2HK88d .TML83Dki>img {
        width: 20px;
        margin-right: 6px
    }

    .vs2HK88d .TML83Dki>span {
        font-size: 16px
    }

    .vs2HK88d .TML83Dki>p {
        display: none
    }

    .vs2HK88d .ZGjBoObB {
        width: 110px;
        display: inline-block
    }

    .vs2HK88d .cdij0Guh {
        height: 100%;
        box-sizing: border-box;
        border: none;
        border-right: 1px solid #e2e2e2;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center
    }

    .vs2HK88d .i3iISdjd {
        background-color: #fff;
        border-radius: 4px
    }

    .vs2HK88d .UyIwMF4l {
        padding: 12px 0 !important;
        text-align: center;
        border-bottom: 1px solid #e2e2e2;
        transition: all 0.15s ease-out
    }

    .vs2HK88d .UyIwMF4l:hover {
        background-color: #f6f7f8
    }

    .vs2HK88d .UyIwMF4l:last-child {
        border-bottom: none
    }

    .vs2HK88d .sTpqI2OL {
        top: 60px !important
    }

    .vs2HK88d .v1IYOtFl {
        border: none;
        display: inline-block;
        vertical-align: top;
        margin-top: 5px;
        flex: 1
    }

    .vs2HK88d .Wv8qYi6c {
        border: none;
        color: #212121;
        padding-left: 12px;
        font-size: 16px
    }

    .vs2HK88d .rXjNQfeD {
        left: 12px
    }

    .vs2HK88d .skKKh2Gb {
        width: 110px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
        border-right: 1px solid #e2e2e2
    }

    .vs2HK88d .skKKh2Gb .BWwNAdEY span {
        display: flex;
        padding-left: 10px
    }

    .l2sdLrHr {
        width: 100%;
        text-align: left;
        padding: 16px;
        box-sizing: border-box
    }

    .v5FcyAzk {
        margin: 0;
        font-size: 22px;
        color: #212121;
        border-bottom: 1px solid #eee;
        padding-bottom: 16px
    }

    .NJSr8DzX {
        padding: 8px 0 0 0;
        list-style-type: none;
        margin: 0
    }

    .NJSr8DzX>li {
        padding: 12px 0
    }

    .NJSr8DzX>li .TML83Dki>img {
        width: 20px;
        margin-right: 24px
    }

    .NJSr8DzX>li .TML83Dki>p {
        font-size: 16px;
        font-weight: 600;
        display: inline-block;
        margin: 0 8px 0 0;
        color: #212121
    }

    .NJSr8DzX>li .TML83Dki>span {
        font-size: 16px;
        font-weight: 600;
        color: #999
    }

    .ZVyvN2da {
        position: relative;
        display: inline-block;
        width: 100px;
        height: 40px;
        border: 1px solid #212121;
        border-radius: 20px;
        overflow: hidden;
        z-index: 2
    }

    .S2rbR1je {
        position: relative;
        font-size: 15px;
        text-align: center;
        cursor: pointer;
        display: inline-block;
        width: 50%;
        height: 100%;
        line-height: 40px
    }

    .YwkqjCvk {
        display: none
    }

    .XchA7Ruk {
        font-weight: bold;
        color: #fff;
        -webkit-transition: 0.15s ease-out;
        -moz-transition: 0.15s ease-out;
        -ms-transition: 0.15s ease-out;
        -o-transition: 0.15s ease-out;
        transition: 0.15s ease-out
    }

    .YwkqjCvk:checked+.Gt0caJfS ~ .JPyW3iI6 {
        transform: translateX(100%)
    }

    .JPyW3iI6 {
        position: absolute;
        left: 0;
        top: 0px;
        z-index: -1;
        display: inline-block;
        width: 50%;
        height: 100%;
        background-color: #212121;
        -webkit-transition: transform 0.15s ease-out;
        -moz-transition: transform 0.15s ease-out;
        -ms-transition: transform 0.15s ease-out;
        -o-transition: transform 0.15s ease-out;
        transition: transform 0.15s ease-out
    }

    .FyUI2IRm {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        transition: all 0.1s;
        flex: 1
    }

    ._4_drUc29 {
        background-color: #f3f3f3 !important;
        pointer-events: none !important
    }

    .TbK9paC4 {
        display: none
    }

    .eftNqiV4 {
        font-size: 18px;
        padding: 13px 10px 10px 5px;
        display: block;
        width: 100%;
        border: none;
        border-bottom: 1px solid #757575
    }

    .eftNqiV4:focus {
        outline: none
    }

    .mDa_k2tG {
        color: #999;
        font-size: 18px;
        font-weight: normal;
        position: absolute;
        pointer-events: none;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        transition: 0.2s ease all
    }

    .eftNqiV4:focus ~ .mDa_k2tG,.eftNqiV4:valid ~ .mDa_k2tG {
        top: 4px;
        transform: none;
        font-size: 12px;
        color: #999
    }

    .WCQJM9Cp {
        position: relative;
        display: block;
        width: 100%
    }

    .WCQJM9Cp:before,.WCQJM9Cp:after {
        content: '';
        height: 2px;
        width: 0;
        bottom: 1px;
        position: absolute;
        background: #212121;
        transition: 0.2s ease all
    }

    .WCQJM9Cp:before {
        left: 50%
    }

    .WCQJM9Cp:after {
        right: 50%
    }

    .eftNqiV4:focus ~ .WCQJM9Cp:before,.eftNqiV4:focus ~ .WCQJM9Cp:after {
        width: 50%
    }

    .tXUUuosk {
        position: absolute;
        height: 60%;
        width: 100px;
        top: 25%;
        left: 0;
        pointer-events: none;
        opacity: 0.5
    }

    .eftNqiV4:focus ~ .tXUUuosk {
        -webkit-animation: pwiVCsjS 0.3s ease;
        -moz-animation: pwiVCsjS 0.3s ease;
        animation: pwiVCsjS 0.3s ease
    }

    @-webkit-keyframes pwiVCsjS {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    @-moz-keyframes pwiVCsjS {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    @keyframes pwiVCsjS {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    ._fBOLDd6 {
        border: 1px solid #eee;
        border-radius: 4px;
        display: flex;
        padding: 12px 16px;
        align-items: center
    }

    ._fBOLDd6 .ROL4rFfH {
        border: none;
        display: flex;
        vertical-align: top
    }

    ._fBOLDd6 .HDAlB9fj {
        border: none;
        color: #212121;
        padding-left: 12px;
        font-size: 16px
    }

    ._fBOLDd6 .NeOtfZFj {
        left: 12px
    }

    ._fBOLDd6 .iFHtyRQA {
        width: 80px;
        height: 32px;
        border: 1px solid #212121;
        font-size: 14px
    }

    ._fBOLDd6 .KkVUxzeA {
        font-size: 14px;
        line-height: 34px;
        vertical-align: top
    }

    .dE8kbJGi {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        background-position: center;
        transition: background 0.3s;
        outline: none
    }

    .dE8kbJGi .taMtxKam {
        position: absolute;
        display: inline-block;
        will-change: auto;
        top: 0;
        left: 0;
        opacity: 0;
        z-index: -1;
        width: 100%;
        height: 100%;
        background-image: repeating-linear-gradient(45deg, rgba(0,0,0,0.2), rgba(0,0,0,0.2) 20px, transparent 21px, transparent 40px);
        background-size: 56px 100%
    }

    .dE8kbJGi .N2usXy_u {
        animation: taMtxKam .5s linear infinite
    }

    @keyframes taMtxKam {
        0% {
            background-position: 0 0;
            z-index: 1;
            opacity: 1
        }

        100% {
            background-position: 56px 0;
            z-index: 1;
            opacity: 1
        }
    }

    .dE8kbJGi .vX2Bcfyr {
        font-size: 10px;
        position: relative;
        border: 4px solid rgba(255,255,255,0.2);
        border-left: 4px solid #ffffff;
        transform: translateZ(0);
        border-radius: 50%;
        width: 20px;
        height: 20px;
        position: absolute;
        top: 50%;
        transform: translate(-50%, -50%);
        left: 50%;
        animation: fUiMmbTP 1.1s infinite linear
    }

    .dE8kbJGi .vX2Bcfyr :after {
        border-radius: 50%;
        width: 10em;
        height: 10em
    }

    @keyframes fUiMmbTP {
        0% {
            transform: translate(-50%, -50%) rotate(0deg)
        }

        100% {
            transform: translate(-50%, -50%) rotate(360deg)
        }
    }

    .jhFIWxXQ {
        color: #fff !important;
        pointer-events: none !important;
        background-color: #bbb !important;
        border: 1px solid #bbb !important;
        cursor: not-allowed !important
    }

    .WcGDbAFj {
        background-color: #212121;
        border: 1px solid #212121;
        color: #fff
    }

    .WcGDbAFj:hover {
        background: rgba(0,0,0,0.8) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.8) 1%) center/15000%
    }

    @media only screen and (max-width: 768px) {
        .WcGDbAFj:hover {
            background:rgba(0,0,0,0.8) radial-gradient(circle, transparent 1%, rgba(155,155,155,0.2) 1%) center/15000%
        }
    }

    .WcGDbAFj:active {
        background-color: #212121;
        background-size: 100%;
        transition: background 0s
    }

    .pTQsxLLG {
        background-color: #fff;
        border: 1px solid #212121;
        color: #212121
    }

    .pTQsxLLG:hover {
        background: rgba(0,0,0,0.05) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.05) 1%) center/15000%
    }

    .pTQsxLLG:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .spaTzRa5 {
        background-color: #fff;
        border: 1px solid #dd0017;
        color: #dd0017
    }

    .spaTzRa5:hover {
        background: rgba(221,0,23,0.1) radial-gradient(circle, transparent 1%, rgba(221,0,23,0.05) 1%) center/15000%
    }

    .spaTzRa5:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .Z15U0Gn4 {
        background-color: #fafafa !important;
        border: 1px solid #fafafa !important;
        color: #212121 !important;
        border-radius: 30px !important;
        width: 100%
    }

    .Z15U0Gn4:hover {
        background: #f4f4f4 radial-gradient(circle, transparent 1%, #f4f4f4 1%) center/15000%
    }

    .Z15U0Gn4:active {
        background-color: #fafafa;
        background-size: 100%;
        transition: background 0s
    }

    .Pm1M6T7d {
        background-color: #fff;
        border: none;
        color: #212121
    }

    .Pm1M6T7d:hover {
        background: rgba(0,0,0,0.05) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.05) 1%) center/15000%
    }

    .Pm1M6T7d:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .Pm1M6T7d:after {
        background-color: rgba(255,255,255,0.2);
        box-shadow: 0px 0px 24px 2px rgba(255,255,255,0.2);
        content: '';
        width: 48px;
        height: 100%;
        transform-origin: bottom left;
        position: absolute;
        transform: skew(-27deg);
        top: 0;
        left: 0;
        animation: Pm1M6T7d 3s ease-in 0.5s infinite normal forwards
    }

    @keyframes Pm1M6T7d {
        0% {
            transform: translateX(-48px) skew(-27deg)
        }

        33% {
            transform: translateX(1000%) skew(-27deg)
        }

        100% {
            transform: translateX(1000%) skew(-27deg)
        }
    }

    .sO4N7Tfb {
        width: 100%;
        color: #212121;
        display: flex;
        flex-direction: column;
        height: 100%
    }

    .sO4N7Tfb .ObLlUuJw {
        height: 56px;
        display: none;
        justify-content: flex-start;
        align-items: center;
        border-bottom: 1px solid #f0f0f0;
        padding: 0 16px
    }

    .sO4N7Tfb .ObLlUuJw .oBiATjmd {
        z-index: 1;
        cursor: pointer
    }

    .sO4N7Tfb .ObLlUuJw .DHTu4qPm {
        line-height: 24px;
        font-size: 16px;
        color: #212121;
        font-weight: 500;
        margin-left: 16px;
        position: relative;
        top: 1px;
        flex: 1
    }

    [dir="rtl"] .sO4N7Tfb .ObLlUuJw .DHTu4qPm {
        margin-left: initial;
        margin-right: 16px
    }

    @media (max-width: 768px) {
        .sO4N7Tfb .ObLlUuJw .DHTu4qPm {
            text-align:center
        }
    }

    @media (min-width: 768px) {
        .sO4N7Tfb {
            max-width:700px;
            margin: 0 auto
        }
    }

    .sO4N7Tfb .g8tHE6vZ {
        text-align: center;
        line-height: 26px;
        font-size: 18px;
        color: #212121;
        margin: 0
    }

    .sO4N7Tfb .OlJ4ru_l {
        text-align: center;
        line-height: 26px;
        font-size: 18px;
        color: #212121;
        margin: 0 0 16px 0
    }

    .sO4N7Tfb .HDpa7IAM {
        margin-top: 10px;
        margin-bottom: 40px;
        display: flex;
        flex-direction: column;
        align-items: center
    }

    .sO4N7Tfb .HDpa7IAM img {
        height: 100px
    }

    .sO4N7Tfb .HDpa7IAM h2 {
        margin: 0;
        margin-top: 16px;
        font-size: 32px;
        line-height: 32px
    }

    .sO4N7Tfb .HDpa7IAM p {
        margin: 0;
        margin-top: 24px;
        font-size: 16px;
        font-weight: 600
    }

    .sO4N7Tfb .HDpa7IAM ul {
        margin: 0;
        padding: 0;
        list-style-type: none;
        color: #757575;
        font-size: 12px;
        margin-top: 8px;
        display: flex
    }

    .sO4N7Tfb .HDpa7IAM ul li {
        display: inline-flex;
        align-items: center;
        margin-left: 8px
    }

    [dir="rtl"] .sO4N7Tfb .HDpa7IAM ul li {
        margin-left: initial;
        margin-right: 8px
    }

    .sO4N7Tfb .HDpa7IAM ul li:before {
        content: "";
        height: 4px;
        width: 4px;
        background-color: #757575;
        display: block;
        border-radius: 4px;
        margin-right: 8px
    }

    [dir="rtl"] .sO4N7Tfb .HDpa7IAM ul li:before {
        margin-right: initial;
        margin-left: 8px
    }

    .sO4N7Tfb .HDpa7IAM ul li:first-child:before {
        display: none
    }

    .sO4N7Tfb .a2DXM3Za .OPkmPF9o {
        color: #dd0017;
        font-size: 12px
    }

    .sO4N7Tfb .a2DXM3Za .dGCroYch {
        position: relative
    }

    .sO4N7Tfb .a2DXM3Za .dGCroYch .QPNhlAKr {
        color: #dd0017;
        font-size: 11px
    }

    .sO4N7Tfb .a2DXM3Za .kXX0iq42 {
        width: 100%
    }

    .sO4N7Tfb .a2DXM3Za .kXX0iq42>div:nth-child(2) {
        height: 100%;
        margin: 0 !important;
        border-radius: 4px
    }

    .sO4N7Tfb .a2DXM3Za .kXX0iq42>div:nth-child(2) input {
        height: 100%
    }

    .sO4N7Tfb .a2DXM3Za .kXX0iq42>div:first-child {
        width: 92px !important
    }

    .sO4N7Tfb .a2DXM3Za .kXX0iq42>div:first-child>div {
        border: 0 !important;
        border-right: 1px solid #e2e2e2 !important
    }

    .sO4N7Tfb .a2DXM3Za .kXX0iq42>div:first-child>div>div:first-child {
        margin-right: 16px !important
    }

    [dir="rtl"] .sO4N7Tfb .a2DXM3Za .kXX0iq42>div:first-child>div>div:first-child {
        margin-right: initial !important;
        margin-left: 16px !important
    }

    .sO4N7Tfb .a2DXM3Za .kXX0iq42>div:first-child>div img {
        margin-right: 8px !important
    }

    .sO4N7Tfb .a2DXM3Za .fVdufUkp {
        position: relative;
        margin-bottom: 20px
    }

    .sO4N7Tfb .a2DXM3Za .fVdufUkp .Nszu4hW4 {
        height: 100%;
        width: 100%;
        position: absolute;
        top: 0;
        left: 0;
        background-color: rgba(226,226,226,0.8);
        display: flex;
        justify-content: flex-end;
        align-items: center;
        padding-right: 20px;
        box-sizing: border-box;
        color: #304ffe;
        font-size: 14px
    }

    [dir="rtl"] .sO4N7Tfb .a2DXM3Za .fVdufUkp .Nszu4hW4 {
        padding-right: initial;
        padding-left: 20px
    }

    .sO4N7Tfb .a2DXM3Za .fVdufUkp .Nszu4hW4 span:hover {
        cursor: pointer
    }

    .sO4N7Tfb .VOp8Hbvs {
        border: 1px solid #e2e2e2;
        border-radius: 4px;
        height: 56px;
        margin-bottom: 20px
    }

    .sO4N7Tfb .VOp8Hbvs .mRA6jnXE {
        border-bottom: none;
        height: 100%;
        padding: 0;
        box-sizing: border-box;
        padding-left: 16px
    }

    .sO4N7Tfb .coU07vnK {
        border-color: #dd0017
    }

    .sO4N7Tfb .EV2N3l1j {
        height: 48px;
        width: 100%;
        background-color: #212121;
        color: #fff;
        font-size: 16px;
        border-radius: 4px;
        margin-top: 24px;
        min-height: 48px
    }

    .sO4N7Tfb .F0kB8yOZ {
        padding: 32px 120px;
        display: flex;
        flex-direction: column;
        flex: 1;
        justify-content: center;
        overflow: auto
    }

    @media screen and (max-width: 768px) {
        .sO4N7Tfb .F0kB8yOZ {
            padding:32px 16px
        }
    }

    .sO4N7Tfb .IELvhLnH {
        padding: 32px 120px;
        display: flex;
        flex-direction: column;
        flex: 1;
        overflow: auto
    }

    @media screen and (max-width: 768px) {
        .sO4N7Tfb .IELvhLnH {
            padding:32px 16px
        }
    }

    .sO4N7Tfb .IELvhLnH .kXX0iq42 {
        border-radius: 0px
    }

    .sO4N7Tfb .IELvhLnH .EV2N3l1j {
        height: 48px;
        width: 100%;
        background-color: #212121;
        color: #fff;
        font-size: 16px;
        border-radius: 4px;
        margin-top: 16px;
        min-height: 48px
    }

    .sO4N7Tfb .IELvhLnH .fVdufUkp {
        margin-bottom: 0px
    }

    .sO4N7Tfb .IELvhLnH .VOp8Hbvs {
        margin-bottom: 0px;
        border-radius: 0px
    }

    .QcTiLGKY .uZeptX8N {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 27px
    }

    .QcTiLGKY .uZeptX8N .teX1qrmx {
        padding: 0 6px
    }

    .QcTiLGKY .uZeptX8N .teX1qrmx .i9m5Hoy8 {
        width: 48px;
        height: 48px;
        border-radius: 4px;
        border: solid 1px #eaeaea;
        background-color: #ffffff;
        line-height: 24px;
        font-size: 18px;
        color: #212121;
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        -moz-appearance: textfield
    }

    .QcTiLGKY .uZeptX8N .teX1qrmx .i9m5Hoy8::-webkit-inner-spin-button,.QcTiLGKY .uZeptX8N .teX1qrmx .i9m5Hoy8::-webkit-outer-spin-button {
        -webkit-appearance: none;
        appearance: none;
        margin: 0
    }

    .QcTiLGKY .uZeptX8N .teX1qrmx .i9m5Hoy8:focus,.QcTiLGKY .uZeptX8N .teX1qrmx .i9m5Hoy8:active {
        border-color: #212121
    }

    .QcTiLGKY .P0AG26eb {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 40px;
        font-size: 14px;
        flex-direction: column
    }

    .QcTiLGKY .P0AG26eb .VD5dvFPB {
        line-height: 20px;
        font-size: 12px;
        color: #757575;
        margin: 9px 0 0 0
    }

    .QcTiLGKY .P0AG26eb .VD5dvFPB .mNB06n5h {
        margin-left: 10px;
        color: #304ffe;
        cursor: pointer
    }

    [dir="rtl"] .QcTiLGKY .P0AG26eb .VD5dvFPB .mNB06n5h {
        margin-left: initial;
        margin-right: 10px
    }

    .r44vxuqj {
        padding: 18px 24px 0 24px;
        text-align: center;
        color: #49ad49
    }

    .r44vxuqj .dEjV6xKD {
        cursor: pointer;
        color: #304ffe
    }

    .j8DAI57v {
        color: #dd0017;
        text-align: center;
        margin-top: 5px;
        font-size: 14px
    }

    .b_ebea {
        position: relative;
        display: inline-block;
        width: 100px;
        height: 40px;
        border: 1px solid #212121;
        border-radius: 20px;
        overflow: hidden;
        z-index: 2
    }

    .b_gbea {
        position: relative;
        font-size: 15px;
        text-align: center;
        cursor: pointer;
        display: inline-block;
        width: 50%;
        height: 100%;
        line-height: 40px
    }

    .b_ibea {
        display: none
    }

    .b_kbea {
        font-weight: bold;
        color: #fff;
        -webkit-transition: 0.15s ease-out;
        -moz-transition: 0.15s ease-out;
        -ms-transition: 0.15s ease-out;
        -o-transition: 0.15s ease-out;
        transition: 0.15s ease-out
    }

    .b_ibea:checked+.b_mbea ~ .b_obea {
        transform: translateX(100%)
    }

    .b_obea {
        position: absolute;
        left: 0;
        top: 0px;
        z-index: -1;
        display: inline-block;
        width: 50%;
        height: 100%;
        background-color: #212121;
        -webkit-transition: transform 0.15s ease-out;
        -moz-transition: transform 0.15s ease-out;
        -ms-transition: transform 0.15s ease-out;
        -o-transition: transform 0.15s ease-out;
        transition: transform 0.15s ease-out
    }

    .b_e8d2 {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        transition: all 0.1s;
        flex: 1
    }

    .b_g8d2 {
        background-color: #f3f3f3 !important;
        pointer-events: none !important
    }

    .b_i8d2 {
        display: none
    }

    .b_k8d2 {
        font-size: 18px;
        padding: 13px 10px 10px 5px;
        display: block;
        width: 100%;
        border: none;
        border-bottom: 1px solid #757575
    }

    .b_k8d2:focus {
        outline: none
    }

    .b_m8d2 {
        color: #999;
        font-size: 18px;
        font-weight: normal;
        position: absolute;
        pointer-events: none;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        transition: 0.2s ease all
    }

    .b_k8d2:focus ~ .b_m8d2,.b_k8d2:valid ~ .b_m8d2 {
        top: 4px;
        transform: none;
        font-size: 12px;
        color: #999
    }

    .b_o8d2 {
        position: relative;
        display: block;
        width: 100%
    }

    .b_o8d2:before,.b_o8d2:after {
        content: '';
        height: 2px;
        width: 0;
        bottom: 1px;
        position: absolute;
        background: #212121;
        transition: 0.2s ease all
    }

    .b_o8d2:before {
        left: 50%
    }

    .b_o8d2:after {
        right: 50%
    }

    .b_k8d2:focus ~ .b_o8d2:before,.b_k8d2:focus ~ .b_o8d2:after {
        width: 50%
    }

    .b_q8d2 {
        position: absolute;
        height: 60%;
        width: 100px;
        top: 25%;
        left: 0;
        pointer-events: none;
        opacity: 0.5
    }

    .b_k8d2:focus ~ .b_q8d2 {
        -webkit-animation: b_s8d2 0.3s ease;
        -moz-animation: b_s8d2 0.3s ease;
        animation: b_s8d2 0.3s ease
    }

    @-webkit-keyframes b_s8d2 {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    @-moz-keyframes b_s8d2 {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    @keyframes b_s8d2 {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    .b_e277 {
        border: 1px solid #eee;
        border-radius: 4px;
        display: flex;
        padding: 12px 16px;
        align-items: center
    }

    .b_e277 .b_g277 {
        border: none;
        display: flex;
        vertical-align: top
    }

    .b_e277 .b_i277 {
        border: none;
        color: #212121;
        padding-left: 12px;
        font-size: 16px
    }

    .b_e277 .b_k277 {
        left: 12px
    }

    .b_e277 .b_m277 {
        width: 80px;
        height: 32px;
        border: 1px solid #212121;
        font-size: 14px
    }

    .b_e277 .b_o277 {
        font-size: 14px;
        line-height: 34px;
        vertical-align: top
    }

    .FXCfdqs_ {
        font-family: "ucglyphs" !important
    }

    .gsE5lXiN {
        width: 100%;
        height: 100%;
        position: absolute;
        background-color: #fff;
        top: 0;
        left: 0;
        transform: translateX(100%);
        transition: transform 0.3s
    }

    .zVCFzNqH {
        transform: translateX(0)
    }

    .i_k636 {
        position: relative;
        height: 100%;
        width: 100%
    }

    .i_k636 .i_m636 {
        z-index: -1;
        animation-name: i_o636;
        animation-duration: 0.4s;
        animation-fill-mode: forwards;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88)
    }

    @keyframes i_o636 {
        0% {
            transform: translateX(0)
        }

        100% {
            transform: translateX(0%)
        }
    }

    .i_k636 .i_q636 {
        animation: i_s636 0.4s cubic-bezier(0.41, 0.45, 0.43, 0.88) forwards;
        z-index: 1
    }

    @keyframes i_s636 {
        0% {
            transform: translateX(0)
        }

        100% {
            transform: translateX(100%)
        }
    }

    .i_k636 .i_u636 {
        z-index: 1;
        animation: i_w636 0.4s cubic-bezier(0.41, 0.45, 0.43, 0.88);
        animation-delay: 0s
    }

    @keyframes i_w636 {
        0% {
            transform: translateX(100%)
        }

        50% {
            transform: translateX(0)
        }

        100% {
            transform: translateX(0)
        }
    }

    .i_k636 .i_y636 {
        animation: i_0636 0.5s;
        animation-delay: 0s;
        transform: translateX(0%)
    }

    @keyframes i_0636 {
        0% {
            z-index: -1
        }

        99% {
            z-index: -1
        }

        100% {
            z-index: 1
        }
    }

    .i_k636 button {
        position: relative
    }

    .b_e8d2 {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        transition: all 0.1s;
        flex: 1
    }

    .b_g8d2 {
        background-color: #f3f3f3 !important;
        pointer-events: none !important
    }

    .b_i8d2 {
        display: none
    }

    .b_k8d2 {
        font-size: 18px;
        padding: 13px 10px 10px 5px;
        display: block;
        width: 100%;
        border: none;
        border-bottom: 1px solid #757575
    }

    .b_k8d2:focus {
        outline: none
    }

    .b_m8d2 {
        color: #999;
        font-size: 18px;
        font-weight: normal;
        position: absolute;
        pointer-events: none;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        transition: 0.2s ease all
    }

    .b_k8d2:focus ~ .b_m8d2,.b_k8d2:valid ~ .b_m8d2 {
        top: 4px;
        transform: none;
        font-size: 12px;
        color: #999
    }

    .b_o8d2 {
        position: relative;
        display: block;
        width: 100%
    }

    .b_o8d2:before,.b_o8d2:after {
        content: '';
        height: 2px;
        width: 0;
        bottom: 1px;
        position: absolute;
        background: #212121;
        transition: 0.2s ease all
    }

    .b_o8d2:before {
        left: 50%
    }

    .b_o8d2:after {
        right: 50%
    }

    .b_k8d2:focus ~ .b_o8d2:before,.b_k8d2:focus ~ .b_o8d2:after {
        width: 50%
    }

    .b_q8d2 {
        position: absolute;
        height: 60%;
        width: 100px;
        top: 25%;
        left: 0;
        pointer-events: none;
        opacity: 0.5
    }

    .b_k8d2:focus ~ .b_q8d2 {
        -webkit-animation: b_s8d2 0.3s ease;
        -moz-animation: b_s8d2 0.3s ease;
        animation: b_s8d2 0.3s ease
    }

    @-webkit-keyframes b_s8d2 {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    @-moz-keyframes b_s8d2 {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    @keyframes b_s8d2 {
        from {
            background: #212121
        }

        to {
            width: 0;
            background: transparent
        }
    }

    .b_e978 {
        position: relative;
        display: inline-block;
        width: 100px;
    }

    .b_e978 .b_g978 {
        cursor: pointer;
        border: 1px solid #eee;
        position: relative;
    }

    .b_e978 .b_g978 .b_i978 span:before {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
    }

    .b_e978 .b_k978 {
        position: absolute;
        top: 100%;
        width: 100%;
        list-style-type: none;
        padding: 0;
        margin: 0;
        border: 1px solid #eee;
        overflow: auto;
        transition: 0.15s ease-in;
        opacity: 0;
        visibility: hidden;
        z-index: -1;
        box-sizing: border-box;
    }

    .b_e978 .b_k978 .b_m978 {
        padding: 12px 24px;
        cursor: pointer;
    }

    .b_e978 .b_o978 {
        opacity: 1;
        visibility: visible;
        z-index: 4;
    }

    .b_e519 {
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        opacity: 0;
        background-color: rgba(0, 0, 0, 0.7);
        transition-property: opacity;
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-name: b_g519;
        z-index: 10;
    }

    .b_i519 {
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88);
        will-change: transform;
        background-color: #fff;
        border-radius: 2px;
        position: absolute;
        overflow: hidden;
    }

    .b_k519 {
        animation-name: b_m519;
        left: 0;
        transform: translateX(-100%);
    }

    .b_o519 {
        animation-name: b_q519;
    }

    .b_s519 {
        animation-name: b_u519;
        right: 0;
        transform: translateX(100%);
    }

    .b_w519 {
        animation-name: b_y519;
        animation-fill-mode: forwards;
        animation-direction: normal;
        transform: translateX(0);
    }

    @keyframes b_y519 {
        from {
            transform: translateX(0);
        }

        to {
            transform: translateX(100%);
        }
    }

    .b_0519 {
        animation-name: b_ab519;
        top: 0;
        transform: translateY(-100%);
    }

    .b_ae519 {
        animation-name: b_ag519;
    }

    .b_ai519 {
        transform: translateY(100%);
        bottom: 0;
        animation-name: b_ak519;
    }

    .b_am519 {
        animation-name: b_ao519;
        animation-fill-mode: forwards;
        animation-direction: normal;
        transform: translateY(0);
    }

    @keyframes b_ao519 {
        from {
            transform: translateY(0);
        }

        to {
            transform: translateY(100%);
        }
    }

    .b_aq519 {
        transform: translate(-50%, 0%);
        left: 50%;
        top: 50%;
        animation-name: b_as519;
    }

    .b_au519 {
        animation-name: b_aw519;
    }

    .b_ay519 {
        transform: translate(-50%, -50%);
        left: 50%;
        top: 50%;
        -webkit-transform: translate(-50%, -50%) scale(1.05);
        transform: translate(-50%, -50%) scale(1.05);
        opacity: 0;
        animation-name: b_a0519;
    }

    .b_a2519 {
        animation-name: b_a4519;
    }

    @keyframes b_a0519 {
        from {
            -webkit-transform: translate(-50%, -50%) scale(1.05);
            transform: translate(-50%, -50%) scale(1.05);
            opacity: 0;
        }

        to {
            -webkit-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
            opacity: 1;
        }
    }

    @keyframes b_a4519 {
        from {
            -webkit-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
            opacity: 1;
        }

        to {
            -webkit-transform: translate(-50%, -50%) scale(0.95);
            transform: translate(-50%, -50%) scale(0.95);
            opacity: 0;
        }
    }

    @keyframes b_as519 {
        from {
            transform: translate(-50%, 0%);
        }

        to {
            opacity: 1;
            transform: translate(-50%, -50%);
        }
    }

    @keyframes b_aw519 {
        from {
            transform: translate(-50%, -50%);
        }

        to {
            opacity: 0;
            transform: translate(-50%, 0%);
        }
    }

    @keyframes b_ab519 {
        from {
            transform: translateY(-100%);
        }

        to {
            transform: translateY(0);
        }
    }

    @keyframes b_ag519 {
        from {
            transform: translateY(0);
        }

        to {
            transform: translateY(-100%);
        }
    }

    @keyframes b_ak519 {
        from {
            transform: translateY(100%);
        }

        to {
            transform: translateY(0);
        }
    }

    @keyframes b_m519 {
        from {
            transform: translateX(-100%);
        }

        to {
            transform: translateX(0);
        }
    }

    @keyframes b_q519 {
        from {
            transform: translateX(0);
        }

        to {
            transform: translateX(-100%);
        }
    }

    @keyframes b_u519 {
        from {
            transform: translateX(100%);
        }

        to {
            transform: translateX(0);
        }
    }

    .b_a6519 {
        opacity: 1;
        transition-property: opacity;
        animation-iteration-count: 1;
        animation-fill-mode: forwards;
        animation-name: b_a8519;
        animation-timing-function: cubic-bezier(0.41, 0.45, 0.43, 0.88);
    }

    @keyframes b_a8519 {
        from {
            opacity: 1;
        }

        to {
            opacity: 0;
        }
    }

    @keyframes b_g519 {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

    .b_e582 {
        display: flex;
        border: 1px solid #e2e2e2;
        height: 56px;
        border-radius: 4px;
        padding: 0;
        box-sizing: border-box
    }

    .b_e582 .b_g582 {
        display: inline-block
    }

    .b_e582 .b_g582>img {
        width: 20px;
        margin-right: 6px
    }

    .b_e582 .b_g582>span {
        font-size: 16px
    }

    .b_e582 .b_g582>p {
        display: none
    }

    .b_e582 .b_i582 {
        width: 110px;
        display: inline-block
    }

    .b_e582 .b_k582 {
        height: 100%;
        box-sizing: border-box;
        border: none;
        border-right: 1px solid #e2e2e2;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center
    }

    .b_e582 .b_m582 {
        background-color: #fff;
        border-radius: 4px
    }

    .b_e582 .b_o582 {
        padding: 12px 0 !important;
        text-align: center;
        border-bottom: 1px solid #e2e2e2;
        transition: all 0.15s ease-out
    }

    .b_e582 .b_o582:hover {
        background-color: #f6f7f8
    }

    .b_e582 .b_o582:last-child {
        border-bottom: none
    }

    .b_e582 .b_q582 {
        top: 60px !important
    }

    .b_e582 .b_s582 {
        border: none;
        display: inline-block;
        vertical-align: top;
        margin-top: 5px;
        flex: 1
    }

    .b_e582 .b_u582 {
        border: none;
        color: #212121;
        padding-left: 12px;
        font-size: 16px
    }

    .b_e582 .b_w582 {
        left: 12px
    }

    .b_e582 .b_y582 {
        width: 110px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
        border-right: 1px solid #e2e2e2
    }

    .b_e582 .b_y582 .b_0582 span {
        display: flex;
        padding-left: 10px
    }

    .b_ab582 {
        width: 100%;
        text-align: left;
        padding: 16px;
        box-sizing: border-box
    }

    .b_ae582 {
        margin: 0;
        font-size: 22px;
        color: #212121;
        border-bottom: 1px solid #eee;
        padding-bottom: 16px
    }

    .b_ag582 {
        padding: 8px 0 0 0;
        list-style-type: none;
        margin: 0
    }

    .b_ag582>li {
        padding: 12px 0
    }

    .b_ag582>li .b_g582>img {
        width: 20px;
        margin-right: 24px
    }

    .b_ag582>li .b_g582>p {
        font-size: 16px;
        font-weight: 600;
        display: inline-block;
        margin: 0 8px 0 0;
        color: #212121
    }

    .b_ag582>li .b_g582>span {
        font-size: 16px;
        font-weight: 600;
        color: #999
    }

    .ToggleButton__root--1oni1 {
        position: relative;
        display: inline-block;
        width: 100px;
        height: 40px;
        border: 1px solid #212121;
        border-radius: 20px;
        overflow: hidden;
        z-index: 2;
    }

    .ToggleButton__toggleLabel--1HDPP {
        position: relative;
        font-size: 15px;
        text-align: center;
        cursor: pointer;
        display: inline-block;
        width: 50%;
        height: 100%;
        line-height: 40px;
    }

    .ToggleButton__toggleInput--1duGC {
        display: none;
    }

    .ToggleButton__toggleInputChecked--1xWZ- {
        font-weight: bold;
        color: #fff;
        -webkit-transition: 0.15s ease-out;
        -moz-transition: 0.15s ease-out;
        -ms-transition: 0.15s ease-out;
        -o-transition: 0.15s ease-out;
        transition: 0.15s ease-out;
    }

    .ToggleButton__toggleInput--1duGC:checked + .ToggleButton__toggleLabelOn--3mLVW ~ .ToggleButton__toggle-selection--IAe3Y {
        transform: translateX(100%);
    }

    .ToggleButton__toggle-selection--IAe3Y {
        position: absolute;
        left: 0;
        top: 0px;
        z-index: -1;
        display: inline-block;
        width: 50%;
        height: 100%;
        background-color: #212121;
        -webkit-transition: transform 0.15s ease-out;
        -moz-transition: transform 0.15s ease-out;
        -ms-transition: transform 0.15s ease-out;
        -o-transition: transform 0.15s ease-out;
        transition: transform 0.15s ease-out;
    }

    .InputField__root--31oom {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        transition: all 0.1s;
        flex: 1;
    }

    .InputField__disabledRoot--3Jx29 {
        background-color: #f3f3f3 !important;
        pointer-events: none !important;
    }

    .InputField__fieldIcon--164xP {
        display: none;
    }

    .InputField__inputField--nsohG {
        font-size: 18px;
        padding: 13px 10px 10px 5px;
        display: block;
        width: 100%;
        border: none;
        border-bottom: 1px solid #757575;
    }

    .InputField__inputField--nsohG:focus {
        outline: none;
    }

    .InputField__labelField--2U2a9 {
        color: #999;
        font-size: 18px;
        font-weight: normal;
        position: absolute;
        pointer-events: none;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        transition: 0.2s ease all;
    }

    .InputField__inputField--nsohG:focus ~ .InputField__labelField--2U2a9, .InputField__inputField--nsohG:valid ~ .InputField__labelField--2U2a9 {
        top: 4px;
        transform: none;
        font-size: 12px;
        color: #999;
    }

    .InputField__bar--2Xl8P {
        position: relative;
        display: block;
        width: 100%;
    }

    .InputField__bar--2Xl8P:before, .InputField__bar--2Xl8P:after {
        content: '';
        height: 2px;
        width: 0;
        bottom: 1px;
        position: absolute;
        background: #212121;
        transition: 0.2s ease all;
    }

    .InputField__bar--2Xl8P:before {
        left: 50%;
    }

    .InputField__bar--2Xl8P:after {
        right: 50%;
    }

    .InputField__inputField--nsohG:focus ~ .InputField__bar--2Xl8P:before, .InputField__inputField--nsohG:focus ~ .InputField__bar--2Xl8P:after {
        width: 50%;
    }

    .InputField__highlight--V_mEe {
        position: absolute;
        height: 60%;
        width: 100px;
        top: 25%;
        left: 0;
        pointer-events: none;
        opacity: 0.5;
    }

    .InputField__inputField--nsohG:focus ~ .InputField__highlight--V_mEe {
        -webkit-animation: InputField__inputHighlighter--1brEe 0.3s ease;
        -moz-animation: InputField__inputHighlighter--1brEe 0.3s ease;
        animation: InputField__inputHighlighter--1brEe 0.3s ease;
    }

    @-webkit-keyframes InputField__inputHighlighter--1brEe {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    @-moz-keyframes InputField__inputHighlighter--1brEe {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    @keyframes InputField__inputHighlighter--1brEe {
        from {
            background: #212121;
        }

        to {
            width: 0;
            background: transparent;
        }
    }

    .InputName__root--3jWJI {
        border: 1px solid #eee;
        border-radius: 4px;
        display: flex;
        padding: 12px 16px;
        align-items: center;
    }

    .InputName__root--3jWJI .InputName__inputRootClass--2ix9c {
        border: none;
        display: flex;
        vertical-align: top;
    }

    .InputName__root--3jWJI .InputName__inputClass--16Eh_ {
        border: none;
        color: #212121;
        padding-left: 12px;
        font-size: 16px;
    }

    .InputName__root--3jWJI .InputName__inputLabelClass--37VEi {
        left: 12px;
    }

    .InputName__root--3jWJI .InputName__toggleRoot--2tknd {
        width: 80px;
        height: 32px;
        border: 1px solid #212121;
        font-size: 14px;
    }

    .InputName__root--3jWJI .InputName__labelClass--3vZCf {
        font-size: 14px;
        line-height: 34px;
        vertical-align: top;
    }

    .b_e271 {
        position: relative;
        cursor: pointer;
        overflow: hidden;
        background-position: center;
        transition: background 0.3s;
        outline: none
    }

    .b_e271 .b_g271 {
        position: absolute;
        display: inline-block;
        will-change: auto;
        top: 0;
        left: 0;
        opacity: 0;
        z-index: -1;
        width: 100%;
        height: 100%;
        background-image: repeating-linear-gradient(45deg, rgba(0,0,0,0.2), rgba(0,0,0,0.2) 20px, transparent 21px, transparent 40px);
        background-size: 56px 100%
    }

    .b_e271 .b_i271 {
        animation: b_g271 .5s linear infinite
    }

    @keyframes b_g271 {
        0% {
            background-position: 0 0;
            z-index: 1;
            opacity: 1
        }

        100% {
            background-position: 56px 0;
            z-index: 1;
            opacity: 1
        }
    }

    .b_e271 .b_k271 {
        font-size: 10px;
        position: relative;
        border: 4px solid rgba(255,255,255,0.2);
        border-left: 4px solid #ffffff;
        transform: translateZ(0);
        border-radius: 50%;
        width: 20px;
        height: 20px;
        position: absolute;
        top: 50%;
        transform: translate(-50%, -50%);
        left: 50%;
        animation: b_m271 1.1s infinite linear
    }

    .b_e271 .b_k271 :after {
        border-radius: 50%;
        width: 10em;
        height: 10em
    }

    @keyframes b_m271 {
        0% {
            transform: translate(-50%, -50%) rotate(0deg)
        }

        100% {
            transform: translate(-50%, -50%) rotate(360deg)
        }
    }

    .b_o271 {
        color: #fff !important;
        pointer-events: none !important;
        background-color: #bbb !important;
        border: 1px solid #bbb !important;
        cursor: not-allowed !important
    }

    .b_q271 {
        background-color: #212121;
        border: 1px solid #212121;
        color: #fff
    }

    .b_q271:hover {
        background: rgba(0,0,0,0.8) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.8) 1%) center/15000%
    }

    @media only screen and (max-width: 768px) {
        .b_q271:hover {
            background:rgba(0,0,0,0.8) radial-gradient(circle, transparent 1%, rgba(155,155,155,0.2) 1%) center/15000%
        }
    }

    .b_q271:active {
        background-color: #212121;
        background-size: 100%;
        transition: background 0s
    }

    .b_s271 {
        background-color: #fff;
        border: 1px solid #212121;
        color: #212121
    }

    .b_s271:hover {
        background: rgba(0,0,0,0.05) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.05) 1%) center/15000%
    }

    .b_s271:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .b_u271 {
        background-color: #fff;
        border: 1px solid #dd0017;
        color: #dd0017
    }

    .b_u271:hover {
        background: rgba(221,0,23,0.1) radial-gradient(circle, transparent 1%, rgba(221,0,23,0.05) 1%) center/15000%
    }

    .b_u271:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .b_w271 {
        background-color: #fafafa !important;
        border: 1px solid #fafafa !important;
        color: #212121 !important;
        border-radius: 30px !important;
        width: 100%
    }

    .b_w271:hover {
        background: #f4f4f4 radial-gradient(circle, transparent 1%, #f4f4f4 1%) center/15000%
    }

    .b_w271:active {
        background-color: #fafafa;
        background-size: 100%;
        transition: background 0s
    }

    .b_y271 {
        background-color: #fff;
        border: none;
        color: #212121
    }

    .b_y271:hover {
        background: rgba(0,0,0,0.05) radial-gradient(circle, transparent 1%, rgba(0,0,0,0.05) 1%) center/15000%
    }

    .b_y271:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .b_y271:after {
        background-color: rgba(255,255,255,0.2);
        box-shadow: 0px 0px 24px 2px rgba(255,255,255,0.2);
        content: '';
        width: 48px;
        height: 100%;
        transform-origin: bottom left;
        position: absolute;
        transform: skew(-27deg);
        top: 0;
        left: 0;
        animation: b_y271 3s ease-in 0.5s infinite normal forwards
    }

    @keyframes b_y271 {
        0% {
            transform: translateX(-48px) skew(-27deg)
        }

        33% {
            transform: translateX(1000%) skew(-27deg)
        }

        100% {
            transform: translateX(1000%) skew(-27deg)
        }
    }

    .ab_aec0f {
        width: 100%;
        padding: 48px 24px;
        color: #212121
    }

    .ab_aec0f .ab_agc0f span:before {
        position: absolute;
        top: 20px;
        left: 24px;
        transform: rotate(180deg);
        font-size: 22px;
        cursor: pointer
    }

    .ab_aec0f .ab_aic0f {
        text-align: center;
        margin: 0
    }

    .ab_aec0f .ab_akc0f {
        margin-top: 10px;
        margin-bottom: 40px;
        display: flex;
        flex-direction: column;
        align-items: center
    }

    .ab_aec0f .ab_akc0f img {
        height: 60px
    }

    .ab_aec0f .ab_akc0f h2 {
        margin: 0;
        margin-top: 16px;
        font-size: 32px;
        line-height: 32px
    }

    .ab_aec0f .ab_akc0f p {
        margin: 0;
        margin-top: 24px;
        font-size: 18px;
        font-weight: 600
    }

    .ab_aec0f .ab_akc0f ul {
        margin: 0;
        padding: 0;
        list-style-type: none;
        color: #757575;
        font-size: 12px;
        margin-top: 8px;
        display: flex
    }

    .ab_aec0f .ab_akc0f ul li {
        display: inline-flex;
        align-items: center;
        margin-left: 8px
    }

    .ab_aec0f .ab_akc0f ul li:before {
        content: '';
        height: 4px;
        width: 4px;
        background-color: #757575;
        display: block;
        border-radius: 4px;
        margin-right: 8px
    }

    .ab_aec0f .ab_akc0f ul li:first-child:before {
        display: none
    }

    .ab_aec0f .ab_amc0f {
        margin-top: 5px;
        padding: 0 120px
    }

    @media screen and (max-width: 768px) {
        .ab_aec0f .ab_amc0f {
            padding:0
        }
    }

    .ab_aec0f .ab_amc0f .ab_aoc0f {
        color: #dd0017;
        font-size: 12px
    }

    .ab_aec0f .ab_amc0f .ab_aqc0f {
        position: relative
    }

    .ab_aec0f .ab_amc0f .ab_aqc0f .ab_asc0f {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #dd0017;
        font-size: 12px;
        width: 50px
    }

    .ab_aec0f .ab_amc0f .ab_auc0f {
        width: 100%
    }

    .ab_aec0f .ab_amc0f .ab_awc0f {
        position: relative;
        margin-bottom: 20px
    }

    .ab_aec0f .ab_amc0f .ab_awc0f .ab_ayc0f {
        height: 100%;
        width: 100%;
        position: absolute;
        top: 0;
        left: 0;
        background-color: rgba(226,226,226,0.8);
        display: flex;
        justify-content: flex-end;
        align-items: center;
        padding-right: 20px;
        box-sizing: border-box;
        color: #304ffe;
        font-size: 14px
    }

    .ab_aec0f .ab_amc0f .ab_awc0f .ab_ayc0f span:hover {
        cursor: pointer
    }

    .ab_aec0f .ab_a0c0f {
        border: 1px solid #e2e2e2;
        border-radius: 4px;
        height: 56px;
        margin-bottom: 20px
    }

    .ab_aec0f .ab_a0c0f .ab_a2c0f {
        border-bottom: none;
        height: 100%;
        padding: 0;
        box-sizing: border-box;
        padding-left: 16px
    }

    .ab_aec0f .ab_a4c0f {
        border-color: #dd0017
    }

    .ab_aec0f .ab_a6c0f {
        height: 48px;
        width: 100%;
        background-color: #212121;
        color: #fff;
        font-size: 16px;
        border-radius: 4px;
        margin-top: 40px
    }

    .a8_baffe .a8_bcffe {
        display: flex;
        justify-content: center
    }

    .a8_baffe .a8_bcffe input {
        height: 56px;
        font-size: 22px;
        text-align: center;
        border-radius: 4px;
        margin-right: 10px
    }

    .a8_baffe .a8_bfffe {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 40px;
        font-size: 14px
    }

    .a8_baffe .a8_bfffe .a8_bhffe {
        margin-left: 10px;
        color: #304ffe;
        cursor: pointer
    }

    .a8_bjffe {
        padding: 18px 24px 0 24px;
        text-align: center;
        color: #49ad49
    }

    .a8_bjffe .a8_blffe {
        cursor: pointer;
        color: #304ffe
    }

    .a8_bnffe {
        color: #dd0017;
        text-align: center;
        margin-top: 5px;
        font-size: 14px
    }

    .b_eb25 {
        width: 100%;
        height: 100%;
        position: absolute;
        background-color: #fff;
        top: 0;
        left: 0;
        transform: translateX(100%);
        transition: transform 0.6s cubic-bezier(0.27, 0.37, 0.16, 0.99)
    }

    .b_gb25 {
        transform: translateX(0)
    }

    .b_ea6e {
        width: 100%;
        height: 100%;
        position: absolute;
        background-color: #fff;
        top: 0;
        left: 0;
        transform: translateX(100%);
        transition: transform 0.5s cubic-bezier(0.27, 0.37, 0.16, 0.99);
    }

    .b_ga6e {
        transform: translateX(0);
    }

    .DSpRXNFT {
        width: 550px;
        border-radius: 4px !important;
        height: calc(100vh - 24px)
    }

    @media only screen and (max-width: 768px) {
        .DSpRXNFT {
            height:100%;
            width: 100%;
            border-radius: 0px
        }
    }

    @use "sass:map";@use "sass:list";.BmAWhO8m {
        position: relative
    }

    .kfwvkc91 {
        height: 95vh;
        min-height: 95vh;
        min-width: 740px;
        border: none;
        max-height: 95vh
    }

    @media screen and (max-width: 768px) {
        .kfwvkc91 {
            height:100%;
            min-height: 0;
            min-width: 100%;
            max-height: 100%
        }
    }

    .DDXxGUE3 {
        overflow-y: hidden;
        width: 640px
    }

    @media screen and (max-width: 768px) {
        .DDXxGUE3 {
            width:100%
        }
    }

    .DDXxGUE3>div {
        width: 546px
    }

    @media screen and (max-width: 768px) {
        .DDXxGUE3>div {
            width:100%
        }
    }

    .kHgw8di3 {
        height: 100% !important;
        width: 100% !important;
        min-width: 0 !important
    }

    .H2YQB3Ha {
        height: 100% !important;
        padding-bottom: 0 !important
    }

    .vALfifBw {
        text-align: center
    }

    .RJb37TvF {
        transition: all 0.6s
    }

    .tINhfUo9 {
        width: 100%;
        height: 100% !important;
        max-height: 100% !important;
        max-width: 100%;
        transform: none
    }

    .CuseaO_e {
        position: absolute !important;
        width: 100%;
        bottom: 0px !important;
        padding: 8px 24px !important;
        min-height: 74px !important;
        height: auto !important;
        line-height: initial !important;
        background-color: #d3353d !important;
        width: 100% !important;
        text-align: center;
        border-radius: 0px !important;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 500;
        z-index: 20 !important
    }

    .BIZ0zyXI {
        display: none
    }

    .wkNR4osv {
        padding: 10px !important;
        width: 30% !important;
        min-width: 450px !important;
        border-radius: 2px !important;
        text-align: center !important
    }

    @media screen and (max-width: 768px) {
        .wkNR4osv {
            top:50% !important;
            left: 50% !important;
            width: 90% !important;
            min-width: 0 !important;
            transform: translate(-50%, -50%) !important
        }
    }

    .XoHgD3pL {
        text-decoration: none;
        color: #fff;
        background-color: #03a9f4;
        width: 100px;
        display: inline-block;
        text-align: center;
        height: 30px;
        border-radius: 2px;
        padding-top: 4px;
        margin-top: 16px
    }

    .b_e9ea {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        transition: transform 0.5s cubic-bezier(0.27, 0.37, 0.16, 0.99);
        background-color: #d4d4d4;
        padding: 12px;
        box-sizing: border-box;
        z-index: 2;
    }

    .b_e9ea .b_g9ea {
        margin: 0;
        text-align: center;
    }

    .b_i9ea {
        transform: translateY(100%);
    }

    .b_k9ea {
        transform: translateY(0);
    }

    @use "sass:map";@use "sass:list";.vHUPv8qc {
        overflow-y: auto !important;
        width: 60% !important;
        height: 80%
    }

    @media only screen and (max-width: 768px) {
        .vHUPv8qc {
            width:100% !important;
            border-top-left-radius: 8px !important;
            border-top-right-radius: 8px !important
        }
    }

    .j39_xTNi {
        margin: 0px;
        padding: 24px 24px 20px;
        color: rgba(0,0,0,0.87);
        font-size: 22px;
        line-height: 32px;
        font-weight: 400;
        border-bottom: 1px solid #fafafa
    }

    .QsRAQ3HV {
        margin: 0;
        padding: 0;
        height: 80%
    }

    @media only screen and (max-width: 768px) {
        .QsRAQ3HV {
            height:calc(100% - 100px)
        }
    }

    .QsRAQ3HV li {
        background-position: center;
        transition: all 0.3s;
        cursor: pointer !important;
        margin: 0 !important;
        font-size: 16px;
        color: rgba(0,0,0,0.6);
        padding: 0px 24px;
        box-sizing: border-box;
        border-top: none;
        border-bottom: none;
        max-height: 239px
    }

    .QsRAQ3HV li:hover {
        background: #f5f5f5 radial-gradient(circle, transparent 1%, #eee 1%)
    }

    .QsRAQ3HV li:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .QsRAQ3HV label {
        width: 100% !important;
        display: inline-block !important;
        line-height: 42px !important
    }

    .jKQev8Pd .JE9a5fal {
        display: none
    }

    .jKQev8Pd input+.p5XyotJS:before {
        content: "n";
        font-family: ucglyphs !important;
        display: inline-block;
        color: #9e9e9e
    }

    .jKQev8Pd input:checked+.p5XyotJS:before {
        content: "m";
        font-family: ucglyphs !important;
        color: #304ffe
    }

    .jKQev8Pd .B8BV32tK {
        margin-left: 12px;
        color: #757575;
        font-size: 14px
    }

    [dir="rtl"] .jKQev8Pd .B8BV32tK {
        margin-left: initial;
        margin-right: 24px
    }

    .qEigo0km {
        height: 500px;
        width: 500px
    }

    @media screen and (max-width: 768px) {
        .qEigo0km {
            height:100%;
            width: 100%
        }
    }

    .fb6GA3Nc {
        text-align: center
    }

    .fb6GA3Nc a {
        color: #075fc9
    }

    .iS3YmfM3 {
        max-width: 480px;
        height: 100%;
        position: relative;
        margin: auto
    }

    .yIkzuJHE {
        height: 100%;
        background-color: #f0f0f0
    }

    .P_2p8Fhu {
        position: fixed;
        bottom: 64px;
        right: 8px;
        z-index: 10;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 8px 16px;
        margin-left: 0px;
        width: 96%;
        height: 48px;
        background: #FDF3F2;
        border: 1px solid #F9D9D7;
        border-radius: 8px
    }

    .P_2p8Fhu .uG2a_FyD {
        font-weight: normal;
        font-size: 12px;
        line-height: 16px;
        text-align: center;
        color: #B32306
    }

    @use "sass:map";@use "sass:list";.OLfcK6JI {
        padding-bottom: 0 !important;
        height: 100% !important;
        width: 100% !important;
        background-color: #ffffff !important
    }

    .U_Z3oSYu {
        border: none;
        width: 100%;
        height: 100%;
        overflow-y: auto
    }

    @media (max-width: 768px) {
        .U_Z3oSYu {
            width:90% !important;
            height: 100% !important;
            max-height: 90% !important;
            display: block;
            margin: auto;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%)
        }
    }

    .KtaL65IB {
        border: none;
        width: 100%;
        height: 100%;
        overflow-y: auto
    }

    @media (max-width: 768px) {
        .KtaL65IB {
            width:100% !important;
            height: 100% !important;
            max-height: 100% !important;
            display: block;
            margin: auto;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%)
        }
    }

    .jqEMatf2 {
        border: none;
        width: 480px;
        height: 100%;
        overflow-y: auto
    }

    @media (max-width: 768px) {
        .jqEMatf2 {
            width:90% !important;
            height: 100% !important;
            max-height: 90% !important;
            display: block;
            margin: auto;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%)
        }
    }

    .aekVOS1r {
        width: 1136px;
        margin: 0 auto;
        width: 60%;
        padding: 96px 0;
        opacity: 0
    }

    @media (max-width: 768px) {
        .aekVOS1r {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .aekVOS1r {
            width:calc(100% - 32px);
            margin: 0 auto;
            padding: 32px 0
        }
    }

    .aekVOS1r .LegXGdxC {
        margin-bottom: 48px
    }

    @media (max-width: 768px) {
        .aekVOS1r .LegXGdxC {
            margin-bottom:34px
        }
    }

    .aekVOS1r .MT5aiLf8 {
        width: 100%
    }

    .aekVOS1r .MT5aiLf8 .ySDv1UYF {
        border-top: 1px solid #e3e3e3;
        padding: 22px 0px
    }

    .aekVOS1r .MT5aiLf8 .ySDv1UYF:nth-child(1) {
        border: none;
        padding-top: 0px
    }

    .aekVOS1r .MT5aiLf8 .ySDv1UYF .RlvyDAPX {
        cursor: pointer
    }

    .aekVOS1r .MT5aiLf8 .ySDv1UYF .RlvyDAPX .z050fZa9 {
        font-family: "ucglyphs" !important;
        font-size: 14px;
        color: #0f0f0f
    }

    .aekVOS1r .MT5aiLf8 .ySDv1UYF .RlvyDAPX .GgdKHPxp {
        padding-right: 24px
    }

    .aekVOS1r .MT5aiLf8 .ySDv1UYF .tPvnYAYW .nbauYNqE {
        font-style: normal;
        font-weight: normal;
        color: #545454;
        padding-top: 16px;
        font-size: 16px;
        line-height: 24px
    }

    @media (max-width: 768px) {
        .aekVOS1r .MT5aiLf8 .ySDv1UYF .tPvnYAYW .nbauYNqE {
            font-size:14px !important;
            line-height: 24px !important
        }
    }

    .aekVOS1r .MT5aiLf8 .ySDv1UYF .Iv19S5cw {
        margin-top: 0px
    }

    .B7GTI7qN {
        width: 1136px;
        margin: 0 auto
    }

    @media (max-width: 768px) {
        .B7GTI7qN {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (min-width: 768px) {
        .B7GTI7qN {
            display:flex;
            flex-direction: row;
            padding: 120px 0px
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .B7GTI7qN {
            width:768px;
            margin: 0 auto;
            flex-direction: column;
            padding: 64px 0px
        }
    }

    @media (max-width: 768px) {
        .B7GTI7qN {
            flex-direction:column;
            padding: 48px 0
        }
    }

    .B7GTI7qN .LegXGdxC {
        font-size: 64px;
        font-weight: 600;
        letter-spacing: -0.02em;
        line-height: 80px;
        flex: 1
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .B7GTI7qN .LegXGdxC {
            margin-bottom:24px;
            font-size: 40px;
            line-height: 50px
        }
    }

    @media (max-width: 768px) {
        .B7GTI7qN .LegXGdxC {
            margin-bottom:24px;
            font-size: 40px;
            line-height: 50px
        }
    }

    .B7GTI7qN .MT5aiLf8 {
        width: 100%;
        flex: 1;
        line-height: 24px;
        font-weight: 600;
        color: #0f0f0f
    }

    .B7GTI7qN .MT5aiLf8 .ySDv1UYF {
        border-top: 1px solid #e3e3e3;
        padding: 22px 0px
    }

    .B7GTI7qN .MT5aiLf8 .ySDv1UYF:nth-child(1) {
        border: none;
        padding-top: 0px
    }

    .B7GTI7qN .MT5aiLf8 .ySDv1UYF .RlvyDAPX {
        cursor: pointer;
        align-items: flex-start
    }

    .B7GTI7qN .MT5aiLf8 .ySDv1UYF .RlvyDAPX .z050fZa9 {
        font-family: "ucglyphs" !important;
        font-size: 14px;
        color: #757575
    }

    @media (max-width: 768px) {
        .B7GTI7qN .MT5aiLf8 .ySDv1UYF .RlvyDAPX .z050fZa9 {
            font-size:10px
        }
    }

    .B7GTI7qN .MT5aiLf8 .ySDv1UYF .RlvyDAPX .GgdKHPxp {
        padding-right: 24px
    }

    .B7GTI7qN .MT5aiLf8 .ySDv1UYF .tPvnYAYW .nbauYNqE {
        font-style: normal;
        white-space: pre-line;
        font-weight: normal;
        color: #545454;
        padding-top: 16px;
        font-size: 16px;
        line-height: 24px
    }

    @media (max-width: 768px) {
        .B7GTI7qN .MT5aiLf8 .ySDv1UYF .tPvnYAYW .nbauYNqE {
            font-size:14px !important;
            line-height: 24px !important
        }
    }

    .B7GTI7qN .MT5aiLf8 .ySDv1UYF .Iv19S5cw {
        margin-top: 0px
    }

    ._1T9Oayy {
        animation: z6H8zsQB 0.6s cubic-bezier(0.39, 0.575, 0.565, 1) both
    }

    @keyframes z6H8zsQB {
        0% {
            transform: translateY(50px);
            opacity: 0
        }

        100% {
            transform: translateY(0);
            opacity: 1
        }
    }

    .NJq2w36v {
        font-family: "OpenSauceOne"
    }

    .TSiakGXq {
        font-size: 48px;
        line-height: 60px
    }

    @media (max-width: 768px) {
        .TSiakGXq {
            font-size:32px;
            line-height: 40px
        }
    }

    .YHdiIX9d {
        font-size: 36px;
        line-height: 48px
    }

    @media (max-width: 768px) {
        .YHdiIX9d {
            font-size:24px;
            line-height: 32px
        }
    }

    .gusyqjk2 {
        font-size: 32px;
        line-height: 48px
    }

    @media (max-width: 768px) {
        .gusyqjk2 {
            font-size:28px;
            line-height: 40px
        }
    }

    .VIt4wiUn {
        font-size: 24px;
        line-height: 36px
    }

    @media (max-width: 768px) {
        .VIt4wiUn {
            font-size:20px;
            line-height: 28px
        }
    }

    .Joqz4Y0y {
        font-size: 20px;
        line-height: 32px
    }

    @media (max-width: 768px) {
        .Joqz4Y0y {
            font-size:16px;
            line-height: 24px
        }
    }

    .KkBQu1fj {
        font-size: 16px;
        line-height: 28px
    }

    @media (max-width: 768px) {
        .KkBQu1fj {
            font-size:14px;
            line-height: 24px
        }
    }

    .dkhlIXk0 {
        font-size: 14px;
        line-height: 20px
    }

    @media (max-width: 768px) {
        .dkhlIXk0 {
            font-size:12px;
            line-height: 16px
        }
    }

    .ErcT9xhj {
        font-size: 12px;
        line-height: 16px
    }

    @media (max-width: 768px) {
        .ErcT9xhj {
            font-size:10px;
            line-height: 14px
        }
    }

    .aygT2SIo {
        font-size: 16px;
        line-height: 24px
    }

    @media (max-width: 768px) {
        .aygT2SIo {
            font-size:14px;
            line-height: 20px
        }
    }

    .k6QhgM7H {
        font-size: 64px;
        line-height: 76px;
        letter-spacing: -0.02em
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .k6QhgM7H {
            font-size:48px;
            line-height: 60px
        }
    }

    @media (max-width: 768px) {
        .k6QhgM7H {
            font-size:32px;
            line-height: 40px
        }
    }

    .MrUhEjps {
        font-size: 24px;
        line-height: 36px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .MrUhEjps {
            font-size:16px;
            line-height: 24px
        }
    }

    @media (max-width: 768px) {
        .MrUhEjps {
            font-size:16px;
            line-height: 24px
        }
    }

    .b_eeaa {
        margin: 0;
        padding: 0;
    }

    .b_eeaa .b_geaa {
        overflow: hidden;
    }

    .b_eeaa .b_geaa .b_ieaa {
        display: flex;
        align-items: center;
    }

    .b_eeaa .b_geaa .b_ieaa .b_keaa {
        flex: 1;
    }

    .b_eeaa .b_geaa .b_ieaa .b_meaa {
        transition: transform 0.3s ease-out;
    }

    .b_eeaa .b_geaa .b_ieaa .b_oeaa {
        transform: rotateZ(180deg);
    }

    .b_eeaa .b_geaa .b_qeaa {
        opacity: 1;
        transition: max-height 0.3s ease-out, opacity 0.15s ease-out 0.15s;
    }

    .b_eeaa .b_geaa .b_seaa {
        opacity: 0;
    }

    .omgvuAcB {
        width: 1136px;
        margin: 0 auto;
        opacity: 0;
        margin-top: 64px
    }

    @media (max-width: 768px) {
        .omgvuAcB {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .omgvuAcB {
            padding-bottom:32px;
            margin-top: 32px
        }
    }

    .omgvuAcB .ObLJVF2s {
        margin-bottom: 32px
    }

    .omgvuAcB ul {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        column-gap: 24px
    }

    @media (max-width: 768px) {
        .omgvuAcB ul {
            display:flex;
            flex-direction: column
        }
    }

    .omgvuAcB ul li {
        display: flex;
        flex-direction: column;
        padding: 24px;
        border-radius: 8px;
        transition: box-shadow 0.5s ease
    }

    @media (max-width: 768px) {
        .omgvuAcB ul li {
            padding:0px;
            border-radius: 0px;
            transition: none
        }
    }

    .omgvuAcB ul li:hover {
        box-shadow: 0px 0px 24px rgba(15,15,15,0.06)
    }

    @media (max-width: 768px) {
        .omgvuAcB ul li:hover {
            box-shadow:none
        }
    }

    .omgvuAcB ul li:hover .Rj1RGCwM {
        background-color: #6e43e5;
        color: #ffffff
    }

    @media (max-width: 768px) {
        .omgvuAcB ul li .Rj1RGCwM {
            align-self:flex-start
        }
    }

    .omgvuAcB ul li .PzZTslm9 {
        width: 64px;
        height: 64px;
        margin-bottom: 24px
    }

    .omgvuAcB ul li .PzZTslm9 img {
        width: 100%;
        height: 100%;
        object-fit: contain
    }

    .omgvuAcB ul li .g5LxRYiz {
        flex: 1
    }

    .omgvuAcB ul li .g5LxRYiz .W7RgWPsE {
        margin-bottom: 16px
    }

    @media (max-width: 768px) {
        .omgvuAcB ul li .g5LxRYiz .W7RgWPsE {
            margin-bottom:8px
        }
    }

    .omgvuAcB ul li .g5LxRYiz .C8_qawaQ {
        margin-bottom: 24px
    }

    .omgvuAcB ul li .Rj1RGCwM {
        transition: background-color 0.3s ease, color 0.3s ease
    }

    @media (max-width: 768px) {
        .omgvuAcB ul li .Rj1RGCwM {
            transition:none
        }
    }

    @media (max-width: 768px) {
        .omgvuAcB ul li .VjVWHVdk {
            margin:24px 0 48px
        }
    }

    .sKTXuDQH {
        animation: eLoGSct_ 0.6s cubic-bezier(0.39, 0.575, 0.565, 1) both
    }

    @keyframes eLoGSct_ {
        0% {
            transform: translateY(50px);
            opacity: 0
        }

        100% {
            transform: translateY(0);
            opacity: 1
        }
    }

    .EQxRuUQL {
        position: relative
    }

    .dY73_Elr {
        width: 1136px;
        margin: 0 auto;
        margin: 64px auto 0 !important
    }

    @media (max-width: 768px) {
        .dY73_Elr {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .dY73_Elr {
            width:100%;
            margin: 32px auto 0 !important
        }
    }

    .Q3hJUDGp {
        position: relative
    }

    .Q3hJUDGp .AVxqbHs4 {
        content: "";
        position: absolute;
        top: -48px;
        left: -48px;
        border-radius: 50%;
        width: 96px;
        height: 96px;
        border: 1px solid #ffffff;
        transform: scale(1);
        animation: KwkB79xq 2s cubic-bezier(0.39, 0.575, 0.565, 1) infinite both;
        animation-delay: 0s
    }

    @keyframes KwkB79xq {
        0% {
            transform: scale(1);
            opacity: 1
        }

        100% {
            transform: scale(2);
            opacity: 0
        }
    }

    .Q3hJUDGp .AVxqbHs4:nth-child(2) {
        animation: KwkB79xq 2s cubic-bezier(0.39, 0.575, 0.565, 1) infinite both;
        animation-delay: .7s
    }

    @keyframes KwkB79xq {
        0% {
            transform: scale(1);
            opacity: 1
        }

        100% {
            transform: scale(2);
            opacity: 0
        }
    }

    @media (max-width: 768px) {
        .Q3hJUDGp .AVxqbHs4 {
            top:-32px;
            left: -32px;
            width: 64px;
            height: 64px
        }
    }

    .Ma621DpR {
        position: absolute;
        top: -48px;
        left: -48px;
        width: 96px;
        height: 96px;
        background: #6e43e5;
        border-radius: 50%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        transform: scale(1);
        transition: transform 1s ease;
        color: #fff !important
    }

    @media (max-width: 768px) {
        .Ma621DpR {
            top:-32px;
            left: -32px;
            width: 64px;
            height: 64px
        }
    }

    .Ma621DpR .kc57rKiQ {
        border-width: 19px 0px 19px 32px;
        border-style: solid;
        border-left-color: #fff;
        border-top-color: transparent;
        border-right-color: transparent;
        border-bottom-color: transparent;
        margin-left: 9.5px;
        margin-top: 2px;
        color: #fff !important
    }

    @media (max-width: 768px) {
        .Ma621DpR .kc57rKiQ {
            border-width:13px 0px 13px 22px;
            margin-left: 6.5px;
            margin-top: 2px
        }
    }

    .Ma621DpR:hover {
        transform: scale(1.4)
    }

    @use "sass:map";@use "sass:list";.ZbCDMRlH {
        font-family: "ucglyphs" !important
    }

    .ygHoKAlN {
        transform: scaleX(0.85);
        margin-top: 3px;
        margin-left: 4px
    }

    .emSM5k3C {
        font-family: "OpenSauceOne";
        margin: 0;
        padding: 0;
        outline: 0;
        background-color: #ffffff;
        cursor: pointer
    }

    .C3UAdYnH {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        border: 1px solid #e3e3e3;
        background-color: #ffffff;
        color: #0f0f0f;
        display: flex;
        justify-content: center;
        align-items: center
    }

    .K28g0Fr8 {
        font-family: "OpenSauceOne";
        padding: 12px 24px;
        background-color: #6e43e5;
        border-radius: 8px;
        color: #ffffff;
        font-weight: 500;
        font-size: 16px;
        transition: background-color 0.5s
    }

    .K28g0Fr8:hover {
        background-color: #562ad0
    }

    .P8MDGtQz {
        font-family: "OpenSauceOne";
        background-color: #ffffff;
        color: #0f0f0f
    }

    .P8MDGtQz:hover {
        background-color: #ffffffe5
    }

    .msnXEIQ1 {
        font-family: "OpenSauceOne";
        color: #545454;
        position: relative
    }

    .msnXEIQ1::after {
        content: "";
        position: absolute;
        bottom: 0;
        background-color: #6e43e5;
        left: 0;
        right: 0;
        height: 2px;
        transform: scaleX(0);
        transition: transform 0.6s ease
    }

    .msnXEIQ1:hover {
        color: #6e43e5;
        font-weight: 600
    }

    .msnXEIQ1:hover::after {
        transform: scaleX(1)
    }

    .CtpzhPL9 {
        font-family: "OpenSauceOne";
        color: #6e43e5;
        font-weight: 600
    }

    .CtpzhPL9::after {
        transform: scaleX(1)
    }

    .auejJ_br {
        font-family: "OpenSauceOne";
        color: #6e43e5;
        font-weight: 600;
        font-size: 12px;
        line-height: 16px
    }

    .J7BakcOz {
        font-family: "OpenSauceOne";
        padding: 8px 16px;
        background-color: #6e43e5;
        border-radius: 8px;
        color: #ffffff;
        font-weight: 600;
        font-size: 12px;
        transition: background-color 0.5s
    }

    .J7BakcOz:hover {
        background-color: #562ad0
    }

    .kTWFNvWE {
        font-family: "OpenSauceOne";
        background-color: #ffffff;
        color: #0f0f0f
    }

    .kTWFNvWE:hover {
        background-color: #ffffffe5
    }

    .btjV3ymp {
        font-family: "OpenSauceOne";
        padding: 8px 16px;
        background-color: #262626;
        border-radius: 8px;
        color: #ffffff;
        font-weight: 600;
        font-size: 12px;
        transition: background-color 0.5s;
        border: 1px solid #545454
    }

    .Fx4uZSB8 {
        font-family: "OpenSauceOne";
        color: white;
        font-weight: 600;
        font-size: 12px;
        line-height: 16px;
        background-color: transparent
    }

    .xSZmi6V8 {
        width: 1px;
        background-color: #e3e3e3
    }

    .FzlhuNnq {
        height: 1px;
        background-color: #e3e3e3
    }

    .hDocf2rO {
        width: 1136px;
        margin: 0 auto;
        margin: 96px auto !important
    }

    @media (max-width: 768px) {
        .hDocf2rO {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    .UWMMt1th {
        width: 100%
    }

    .GEOoPwhE {
        width: 1136px;
        margin: 0 auto;
        opacity: 0
    }

    @media (max-width: 768px) {
        .GEOoPwhE {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .GEOoPwhE {
            padding-top:32px;
            padding-bottom: 32px
        }
    }

    .GEOoPwhE .nqrqoKGN {
        margin-bottom: 70px
    }

    @media (max-width: 768px) {
        .GEOoPwhE .nqrqoKGN {
            margin-bottom:32px
        }
    }

    .GEOoPwhE .Bzr1GOnK {
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center
    }

    @media (max-width: 768px) {
        .GEOoPwhE .Bzr1GOnK {
            flex-direction:column;
            align-items: flex-start
        }
    }

    .GEOoPwhE .Bzr1GOnK .XyK0WxZ7 {
        flex: 1;
        margin-right: 160px
    }

    @media (max-width: 768px) {
        .GEOoPwhE .Bzr1GOnK .XyK0WxZ7 {
            margin-right:0px
        }
    }

    .GEOoPwhE .Bzr1GOnK .XyK0WxZ7 .ukmDBfCB {
        width: 100%;
        margin: 32px 0
    }

    @media (max-width: 768px) {
        .GEOoPwhE .Bzr1GOnK .NoWgAfmA {
            margin-top:48px
        }

        .GEOoPwhE .Bzr1GOnK .NoWgAfmA:nth-child(1) {
            margin-top: 0px
        }
    }

    .GEOoPwhE .Bzr1GOnK .NoWgAfmA .bNiNvW0G {
        margin-top: 4px;
        color: #545454 !important
    }

    .GEOoPwhE .Bzr1GOnK .NoWgAfmA .bNiNvW0G>span {
        color: #545454 !important
    }

    @media (max-width: 768px) {
        .GEOoPwhE .Bzr1GOnK .NoWgAfmA .bNiNvW0G {
            margin-top:8px
        }
    }

    .GEOoPwhE .Bzr1GOnK .NoWgAfmA .Ao31jw0d {
        color: #0f0f0f !important
    }

    .GEOoPwhE .Bzr1GOnK .NoWgAfmA .Ao31jw0d>span {
        color: #0f0f0f !important
    }

    .GEOoPwhE .Bzr1GOnK .NoWgAfmA .v8QLp6nd span {
        color: #6e43e5 !important
    }

    .tIRGH4TQ {
        width: 460px
    }

    @media (max-width: 768px) {
        .tIRGH4TQ {
            width:100%;
            height: 370px;
            margin-bottom: 24px
        }
    }

    .tIRGH4TQ img {
        width: 100%;
        height: 100%;
        object-fit: contain
    }

    .pWFyDiGW {
        animation: o0HjlHOY 0.6s cubic-bezier(0.39, 0.575, 0.565, 1) both
    }

    @keyframes o0HjlHOY {
        0% {
            transform: translateY(50px);
            opacity: 0
        }

        100% {
            transform: translateY(0);
            opacity: 1
        }
    }

    .b_e8c7 {
        position: relative;
        margin: 0 auto;
        height: 100%;
        user-select: none;
    }

    .b_e8c7 .b_g8c7 {
        overflow: hidden;
        height: 100%;
    }

    .b_e8c7 .b_g8c7 .b_i8c7 {
        padding: 0;
        clear: both;
        width: 10000px;
        -webkit-transition: -webkit-transform 0.5s;
        transition: transform 0.5s;
        will-change: transform;
        margin: 0;
        height: 100%;
    }

    .b_e8c7 .b_g8c7 .b_i8c7 .b_k8c7 {
        display: inline-block;
        float: left;
        height: 100%;
    }

    .b_e8c7 .b_g8c7 .b_i8c7 .b_k8c7:first-child {
        margin-left: 0 !important;
    }

    .b_e8c7 .b_g8c7 .b_i8c7 .b_k8c7:last-child {
        margin-right: 0 !important;
    }

    .b_e8c7 .b_m8c7 {
        position: absolute;
        top: 50%;
        left: -20px;
        cursor: pointer;
        z-index: 1;
        font-size: 36px;
        transform: rotate(-180deg) translate(50%, 50%);
    }

    .b_e8c7 .b_m8c7 .b_o8c7:before {
        content: attr(data-icon);
    }

    .b_e8c7 .b_q8c7 {
        right: -40px;
        position: absolute;
        top: 50%;
        font-size: 36px;
        color: #666;
        z-index: 1;
        cursor: pointer;
    }

    .b_e8c7 .b_q8c7 .b_s8c7:before {
        content: attr(data-icon);
    }

    .b_e8c7 .b_u8c7 {
        color: #ddd !important;
    }

    .b_e8c7 .b_w8c7 {
        position: absolute;
        bottom: 10px;
        width: 100%;
    }

    .b_e8c7 .b_w8c7 ul {
        padding: 0;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .b_e8c7 .b_w8c7 ul .b_y8c7 {
        background-color: #fd5c63;
    }

    .b_e8c7 .b_w8c7 ul li {
        width: 6px;
        height: 6px;
        background-color: #fff;
        border-radius: 10px;
        margin-right: 5px;
        box-sizing: content-box;
        display: inline-block;
    }

    @media screen and (min-width: 768px) {
        .b_e8c7 .b_w8c7 ul li:hover {
            cursor: pointer;
        }
    }

    .b_08c7 .b_m8c7, .b_08c7 .b_q8c7 {
        transition: opacity 0.2s;
        will-change: opacity;
        opacity: 0 !important;
    }

    .b_08c7:hover .b_m8c7, .b_08c7:hover .b_q8c7 {
        opacity: 1 !important;
    }

    @media (max-width: 768px) {
        .fLMH3Sv8 {
            margin-top:24px;
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center
        }

        .fLMH3Sv8 li {
            height: 8px;
            width: 8px;
            border-radius: 50%;
            background-color: #e3e3e3;
            margin-left: 12px;
            transition: width 0.3s ease, border-radius 0.3s ease, background-color 0.3s ease
        }

        .fLMH3Sv8 li:nth-child(1) {
            margin-left: 0px
        }

        .fLMH3Sv8 li.EHbZ1P2T {
            background-color: #545454;
            width: 32px;
            border-radius: 8px
        }
    }

    @use "sass:map";@use "sass:list";.uHyv4b_t {
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center
    }

    .uHyv4b_t .vCYArHMd {
        width: 144px;
        margin-right: 16px
    }

    .uHyv4b_t .vCYArHMd img {
        width: 100%;
        height: 100%;
        object-fit: cover
    }

    .uHyv4b_t .hKtGwd8y {
        font-family: "ucglyphs" !important;
        font-size: 24px;
        line-height: 24px
    }

    @use "sass:map";@use "sass:list";@media (max-width: 768px) {
        .tjgnS6Rb {
            background-color:#ffffff !important;
            padding-bottom: 32px
        }
    }

    .tjgnS6Rb ._n2w6qO7 {
        animation: Mnz2B3l1 0.6s cubic-bezier(0.39, 0.575, 0.565, 1) both;
        width: 1136px;
        margin: 0 auto
    }

    @keyframes Mnz2B3l1 {
        0% {
            transform: translateY(50px);
            opacity: 0
        }

        100% {
            transform: translateY(0);
            opacity: 1
        }
    }

    @media (max-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (min-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 {
            display:flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center
        }
    }

    @media (max-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 {
            display:flex;
            flex-direction: column-reverse;
            width: 100%
        }
    }

    .tjgnS6Rb ._n2w6qO7 .SgqeLlXg {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-start
    }

    @media (min-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 .SgqeLlXg {
            flex-shrink:1;
            margin-right: 80px
        }
    }

    @media (max-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 .SgqeLlXg {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    .tjgnS6Rb ._n2w6qO7 .SgqeLlXg .QksGkPL3 {
        width: calc(100% - 5px)
    }

    @media (max-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 .SgqeLlXg .QksGkPL3 {
            width:100%;
            padding-right: 8px
        }
    }

    .tjgnS6Rb ._n2w6qO7 .SgqeLlXg .LtqUqUzg {
        width: calc(100% - 120px);
        margin-top: 16px
    }

    @media (max-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 .SgqeLlXg .LtqUqUzg {
            width:100%
        }
    }

    .tjgnS6Rb ._n2w6qO7 .SgqeLlXg .J5fJytBW {
        margin-top: 24px
    }

    @media (min-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 .mDNTZXL6 {
            width:464px;
            height: 600px
        }
    }

    .tjgnS6Rb ._n2w6qO7 .mDNTZXL6 img {
        width: 100%;
        height: 100%;
        object-fit: cover
    }

    @media (max-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 .mDNTZXL6 {
            width:100%;
            height: 250px;
            margin-bottom: 32px
        }
    }

    .tjgnS6Rb ._n2w6qO7 .eQZd4UK0 {
        margin-top: 32px
    }

    @media (max-width: 768px) {
        .tjgnS6Rb ._n2w6qO7 .eQZd4UK0 {
            margin-top:24px
        }
    }

    .tjgnS6Rb .jCSTwdTG {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: #ffffff;
        box-shadow: 0px -2px 8px rgba(15,15,15,0.06);
        padding: 8px;
        display: flex;
        z-index: 6
    }

    .tjgnS6Rb .jCSTwdTG .J5fJytBW {
        width: 100%;
        flex: 1;
        text-align: center
    }

    .VHMDf9np {
        width: 1136px;
        margin: 0 auto;
        margin-top: 64px;
        background-position: center;
        background-size: cover !important;
        border-radius: 8px;
        padding: 48px 32px;
        display: flex;
        flex-direction: column;
        justify-content: flex-start
    }

    @media (max-width: 768px) {
        .VHMDf9np {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    .VHMDf9np .ENpPClHe {
        margin-bottom: 16px;
        line-height: 36px;
        width: 40%
    }

    @use "sass:map";@use "sass:list";.txLfe13V {
        font-family: "OpenSauceOne";
        z-index: 5;
        background: #ffffff;
        box-shadow: 0px 1px 0px #e3e3e3;
        position: sticky;
        top: -1px
    }

    .txLfe13V .ITOpb1z5 {
        width: 1136px;
        margin: 0 auto;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center
    }

    @media (max-width: 768px) {
        .txLfe13V .ITOpb1z5 {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .txLfe13V .ITOpb1z5 {
            overflow-x:scroll
        }
    }

    .txLfe13V .ITOpb1z5 .xDcKXobc {
        margin: 14px 0
    }

    .txLfe13V .ITOpb1z5 ul {
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        align-self: stretch;
        overflow-x: scroll
    }

    @media (min-width: 768px) {
        .txLfe13V .ITOpb1z5 ul {
            margin-right:52px
        }
    }

    .txLfe13V .ITOpb1z5 ul::-webkit-scrollbar {
        -webkit-appearance: none;
        width: 0;
        display: none
    }

    .txLfe13V .ITOpb1z5 ul li {
        margin-left: 32px;
        align-self: stretch
    }

    @media (min-width: 768px) {
        .txLfe13V .ITOpb1z5 ul li {
            flex-shrink:0
        }
    }

    .txLfe13V .ITOpb1z5 ul li:nth-child(1) {
        margin-left: 0px
    }

    @media (max-width: 768px) {
        .txLfe13V .ITOpb1z5 ul li {
            flex:1 0 auto
        }
    }

    .txLfe13V .ITOpb1z5 ul li .XRBwSsl_ {
        display: flex;
        height: 100%;
        align-items: center;
        padding: 20px 0px
    }

    @media (max-width: 768px) {
        .txLfe13V .ITOpb1z5 ul li .XRBwSsl_>* {
            padding:20px 0
        }
    }

    .e6LMam03 {
        width: 1136px;
        margin: 0 auto;
        margin: 96px auto !important;
        opacity: 0
    }

    @media (max-width: 768px) {
        .e6LMam03 {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .e6LMam03 {
            margin:0 auto !important;
            padding-top: 32px;
            padding-bottom: 32px
        }
    }

    .e6LMam03 .R3Zjiofr {
        margin-bottom: 60px
    }

    @media (max-width: 768px) {
        .e6LMam03 .R3Zjiofr {
            margin-bottom:32px
        }
    }

    .e6LMam03 .hAbNLhYJ {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        column-gap: 60px
    }

    @media (max-width: 768px) {
        .e6LMam03 .hAbNLhYJ {
            display:flex;
            flex-direction: column
        }
    }

    .e6LMam03 .hAbNLhYJ .Z8wRqupU {
        width: 600px;
        height: calc(600px / (16 / 9));
        border-radius: 8px
    }

    .e6LMam03 .hAbNLhYJ .Z8wRqupU img {
        width: 100%;
        height: 100%;
        object-fit: cover
    }

    @media (max-width: 768px) {
        .e6LMam03 .hAbNLhYJ .Z8wRqupU {
            width:100%;
            height: 200px
        }
    }

    @media (max-width: 768px) {
        .e6LMam03 .hAbNLhYJ .ZF1TzJ35 {
            margin-top:32px
        }
    }

    .e6LMam03 .hAbNLhYJ .ZF1TzJ35 .qMgD4G7N {
        margin-bottom: 24px
    }

    .e6LMam03 .mcxxCWzZ {
        font-size: 17px !important;
        width: 48px;
        height: 48px;
        background-color: #ededed;
        border-radius: 50%;
        color: #0f0f0f !important;
        display: flex;
        justify-content: center;
        align-items: center;
        right: 404px;
        left: unset !important;
        bottom: -24px;
        top: unset !important
    }

    @media (max-width: 768px) {
        .e6LMam03 .mcxxCWzZ {
            right:unset;
            left: 16px !important;
            bottom: -97px
        }
    }

    .e6LMam03 .mcxxCWzZ>span {
        font-size: 17px;
        line-height: 17px;
        margin-top: 4px;
        margin-left: 2px
    }

    .e6LMam03 .ruXmzFYB {
        font-size: 17px !important;
        width: 48px;
        height: 48px;
        background-color: #ededed;
        border-radius: 50%;
        color: #0f0f0f !important;
        display: flex;
        justify-content: center;
        align-items: center;
        right: 345px !important;
        left: unset !important;
        bottom: 0;
        top: unset !important
    }

    @media (max-width: 768px) {
        .e6LMam03 .ruXmzFYB {
            right:unset !important;
            left: 72px !important;
            bottom: -72px
        }
    }

    .e6LMam03 .ruXmzFYB>span {
        font-size: 17px;
        line-height: 17px;
        margin-top: 4px;
        margin-left: 2px
    }

    .e6LMam03 .Ev7A0tXJ {
        color: #cccccc !important
    }

    .e6LMam03 .Ev7A0tXJ>span {
        color: #cccccc !important
    }

    .o_X1m5pk {
        animation: wAtF0BgP 0.6s cubic-bezier(0.39, 0.575, 0.565, 1) both
    }

    @keyframes wAtF0BgP {
        0% {
            transform: translateY(50px);
            opacity: 0
        }

        100% {
            transform: translateY(0);
            opacity: 1
        }
    }

    .CZNERkNe {
        width: 48px;
        height: 48px;
        background-color: #ffffff;
        border-radius: 100%;
        box-shadow: 0px 2px 8px rgba(121,121,121,0.12);
        color: #0f0f0f;
        position: absolute;
        right: -70px;
        display: flex;
        justify-content: center;
        align-items: center
    }

    .CZNERkNe>span {
        margin-top: 5px
    }

    @media (max-width: 768px) {
        .CZNERkNe {
            top:-64px;
            right: 16px
        }
    }

    @media (min-width: 768px) {
        .IQwsipV5 {
            overflow:scroll
        }
    }

    @media (min-width: 768px) {
        .IQwsipV5 .O1ytyUyi {
            border-radius:16px;
            overflow: visible;
            animation: none;
            top: 10%
        }
    }

    @media (max-width: 768px) {
        .IQwsipV5 .O1ytyUyi {
            border-radius:0px;
            width: 100%;
            max-height: calc(100% - 112px);
            overflow: auto;
            animation: none;
            top: unset;
            bottom: calc(100% - 112px)
        }
    }

    .IQwsipV5 .O1ytyUyi .P0Exasxq {
        width: 100%;
        height: 400px;
        border-radius: 16px 16px 0px 0px;
        overflow: hidden
    }

    @media (max-width: 768px) {
        .IQwsipV5 .O1ytyUyi .P0Exasxq {
            height:200px;
            border-radius: 0px
        }
    }

    .IQwsipV5 .O1ytyUyi .P0Exasxq img {
        width: 100%;
        height: 100%;
        object-fit: cover
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm {
        padding: 32px 48px 48px 32px
    }

    @media (max-width: 768px) {
        .IQwsipV5 .O1ytyUyi .NDSL5vgm {
            padding:24px 16px
        }
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm .lJHVuXod {
        margin-bottom: 16px
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm .RaZ0tPxw {
        line-height: 28px
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm ul {
        margin-top: 48px
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li {
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: flex-start;
        margin-top: 48px
    }

    @media (max-width: 768px) {
        .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li {
            flex-direction:column
        }
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li:nth-child(1) {
        margin-top: 0px
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li .DEr665bM {
        width: 64px;
        height: 64px
    }

    @media (max-width: 768px) {
        .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li .DEr665bM {
            margin-bottom:16px
        }
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li .DEr665bM img {
        width: 100%;
        height: 100%;
        object-fit: contain
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li .yaUX2WxW {
        margin-left: 32px;
        flex: 1
    }

    @media (max-width: 768px) {
        .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li .yaUX2WxW {
            margin-left:0px
        }
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li .yaUX2WxW .J6ecU3Nc {
        margin-bottom: 4px
    }

    .IQwsipV5 .O1ytyUyi .NDSL5vgm ul li .yaUX2WxW .AjJcOChT {
        line-height: 28px
    }

    .KoPELE4J {
        z-index: 11;
        width: 48px;
        height: 48px;
        background-color: #ffffff;
        border-radius: 100%;
        box-shadow: 0px 2px 8px rgba(121,121,121,0.12);
        color: #0f0f0f;
        position: fixed;
        top: 10%;
        right: calc(50% - 432px);
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer
    }

    .KoPELE4J>span {
        margin-top: 5px
    }

    @media (max-width: 768px) {
        .KoPELE4J {
            top:unset;
            bottom: calc(100% - 72px);
            right: 16px
        }
    }

    .hkovJZhX {
        z-index: 11;
        position: fixed;
        bottom: calc(100% - 112px);
        right: 0px;
        left: 0px;
        background-color: #ffffff;
        border-radius: 16px 16px 0px 0px;
        padding: 12px 0px
    }

    .hkovJZhX>div {
        width: 40px;
        height: 4px;
        background-color: #cccccc;
        border-radius: 4px;
        margin: 0 auto
    }

    .L_i1Nzqy {
        width: 1136px;
        margin: 0 auto;
        opacity: 0
    }

    @media (max-width: 768px) {
        .L_i1Nzqy {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .L_i1Nzqy {
            padding-top:32px;
            padding-bottom: 32px
        }
    }

    .L_i1Nzqy .GkJZUb3H {
        margin-bottom: 41px
    }

    @media (max-width: 768px) {
        .L_i1Nzqy .GkJZUb3H {
            margin-bottom:36px
        }
    }

    .L_i1Nzqy .TbLvtvDo {
        margin-top: 16px
    }

    @media (max-width: 768px) {
        .L_i1Nzqy .TbLvtvDo {
            margin-top:24px
        }
    }

    .L_i1Nzqy .c4Ys8SEG {
        display: grid
    }

    @media (max-width: 768px) {
        .L_i1Nzqy .c4Ys8SEG {
            display:block
        }
    }

    .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ {
        display: flex;
        align-items: center;
        padding: 24px 0px;
        margin: 0 auto
    }

    .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ:nth-child(1) {
        margin: 0 0
    }

    @media (max-width: 768px) {
        .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ {
            display:grid;
            grid-template-columns: 2fr 1fr;
            padding: 0 0;
            margin: 0 0 16px !important;
            height: 64px
        }
    }

    .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ .Ee6phb38 {
        width: 184px;
        height: 64px;
        object-fit: contain
    }

    .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ .Ee6phb38 img {
        width: 100%;
        height: 100%
    }

    @media (max-width: 768px) {
        .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ .A7lSxwqS {
            display:flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center
        }
    }

    @media (max-width: 768px) {
        .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ .A7lSxwqS .vAHe7cKP {
            width:42px;
            height: 42px;
            background-color: #ededed;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 700
        }

        .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ .A7lSxwqS .vAHe7cKP:nth-child(1) {
            transform: rotate(180deg)
        }
    }

    .L_i1Nzqy .c4Ys8SEG .ziFNb8zJ .A7lSxwqS .TJefW7PS {
        opacity: 0.4
    }

    .L_i1Nzqy .c4Ys8SEG .iV62D80n {
        margin: 0 auto;
        padding: 24px 0px
    }

    .L_i1Nzqy .c4Ys8SEG .iV62D80n:nth-child(1) {
        margin: 0 0
    }

    @media (max-width: 768px) {
        .L_i1Nzqy .c4Ys8SEG .iV62D80n {
            display:grid;
            grid-template-columns: 2fr 1fr;
            padding: 11px 0;
            margin: 0 0
        }
    }

    .L_i1Nzqy .c4Ys8SEG .iV62D80n .Ee6phb38 {
        width: 24px;
        height: 24px;
        object-fit: contain
    }

    @media (max-width: 768px) {
        .L_i1Nzqy .c4Ys8SEG .iV62D80n .Ee6phb38 {
            margin:0 auto
        }
    }

    .L_i1Nzqy .c4Ys8SEG .iV62D80n .Ee6phb38 img {
        width: 100%;
        height: 100%
    }

    .k_D7opRL {
        animation: sevbnAES 0.6s cubic-bezier(0.39, 0.575, 0.565, 1) both
    }

    @keyframes sevbnAES {
        0% {
            transform: translateY(50px);
            opacity: 0
        }

        100% {
            transform: translateY(0);
            opacity: 1
        }
    }

    .w475Vsfz {
        width: 1136px;
        margin: 0 auto;
        opacity: 0
    }

    @media (max-width: 768px) {
        .w475Vsfz {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .w475Vsfz {
            padding-top:32px;
            padding-bottom: 32px
        }
    }

    .w475Vsfz .FUJNqJQ8 {
        margin-bottom: 48px
    }

    @media (max-width: 768px) {
        .w475Vsfz .FUJNqJQ8 {
            margin-bottom:32px
        }
    }

    .w475Vsfz ul {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        column-gap: 24px
    }

    @media (max-width: 768px) {
        .w475Vsfz ul {
            grid-template-columns:1fr;
            column-gap: none
        }
    }

    @media (max-width: 768px) {
        .w475Vsfz ul li {
            display:flex;
            flex-direction: row;
            justify-content: flex-start;
            align-items: flex-start;
            height: 130px;
            margin-top: 20px
        }

        .w475Vsfz ul li:nth-child(1) {
            margin-top: 0px
        }

        .w475Vsfz ul li:last-child {
            height: unset
        }
    }

    .w475Vsfz ul li .DJIofqwH {
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        margin-bottom: 24px
    }

    @media (max-width: 768px) {
        .w475Vsfz ul li .DJIofqwH {
            flex-direction:column;
            align-self: stretch;
            margin-bottom: 0px;
            margin-right: 16px
        }
    }

    .w475Vsfz ul li .DJIofqwH .znDUiH17 {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        color: #ffffff;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #e3e3e3;
        transition: background-color 0.6s ease
    }

    @media (max-width: 768px) {
        .w475Vsfz ul li .DJIofqwH .znDUiH17 {
            width:40px;
            height: 40px
        }
    }

    .w475Vsfz ul li .DJIofqwH .m7cWS5YP {
        background-color: #e3e3e3
    }

    .w475Vsfz ul li .DJIofqwH .GdoazX9I {
        flex: 1;
        margin: 0 0 0 16px;
        transition: transform 1s ease 1s
    }

    @media (min-width: 768px) {
        .w475Vsfz ul li .DJIofqwH .GdoazX9I {
            transform-origin:left;
            transform: scaleX(0)
        }
    }

    @media (max-width: 768px) {
        .w475Vsfz ul li .DJIofqwH .GdoazX9I {
            align-self:stretch;
            width: 2px;
            margin: 5px auto 0;
            transform-origin: top;
            transform: scaleY(0)
        }
    }

    .w475Vsfz ul li .WRsbQXjH {
        margin-top: 4px
    }

    @media (max-width: 768px) {
        .w475Vsfz ul li .WRsbQXjH {
            margin-top:8px
        }
    }

    .PzZGvasJ {
        animation: HwWjwcy5 0.6s cubic-bezier(0.39, 0.575, 0.565, 1) both
    }

    @keyframes HwWjwcy5 {
        0% {
            transform: translateY(50px);
            opacity: 0
        }

        100% {
            transform: translateY(0);
            opacity: 1
        }
    }

    .PzZGvasJ ul li .GdoazX9I {
        transform: scaleX(1) !important
    }

    @media (max-width: 768px) {
        .PzZGvasJ ul li .GdoazX9I {
            transform:scaleY(1) !important
        }
    }

    .PzZGvasJ ul li:nth-child(1) .znDUiH17 {
        background-color: #0f0f0f
    }

    .PzZGvasJ ul li:nth-child(2) .znDUiH17 {
        background-color: #0f0f0f;
        transition-delay: 2s
    }

    .PzZGvasJ ul li:nth-child(2) .GdoazX9I {
        transition-delay: 2s
    }

    .PzZGvasJ ul li:nth-child(3) .znDUiH17 {
        background-color: #0f0f0f;
        transition-delay: 3s
    }

    .PzZGvasJ ul li:nth-child(3) .GdoazX9I {
        transition-delay: 3s
    }

    .PzZGvasJ ul li:nth-child(4) .znDUiH17 {
        background-color: #24a346;
        transition-delay: 4s
    }

    .yVPI8bfm {
        width: 1136px;
        margin: 0 auto;
        padding: 72px 0px
    }

    @media (max-width: 768px) {
        .yVPI8bfm {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .yVPI8bfm {
            padding-top:32px;
            padding-bottom: 32px
        }
    }

    .yVPI8bfm ul {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center
    }

    @media (max-width: 768px) {
        .yVPI8bfm ul {
            flex-direction:column;
            align-items: flex-start
        }
    }

    .yVPI8bfm ul li {
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: center
    }

    @media (max-width: 768px) {
        .yVPI8bfm ul li {
            margin-top:32px;
            align-items: flex-start
        }

        .yVPI8bfm ul li:nth-child(1) {
            margin-top: 0px
        }
    }

    .yVPI8bfm ul .DmIxZsSr {
        align-self: stretch;
        margin: 0 70px
    }

    .yVPI8bfm ul .M2_tpQzr {
        margin-top: 5px
    }

    @use "sass:map";@use "sass:list";.ANPXFN0z {
        font-family: "OpenSauceOne";
        background: #0f0f0f;
        padding: 96px 0px
    }

    @media (max-width: 768px) {
        .ANPXFN0z {
            padding:32px 0px 48px
        }
    }

    .ANPXFN0z .iTCJ_6Rr {
        width: 1136px;
        margin: 0 auto;
        opacity: 0
    }

    @media (max-width: 768px) {
        .ANPXFN0z .iTCJ_6Rr {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    .ANPXFN0z .iTCJ_6Rr .PIRgqE9K {
        width: 90%;
        margin-bottom: 48px
    }

    @media (max-width: 768px) {
        .ANPXFN0z .iTCJ_6Rr .PIRgqE9K {
            width:100%
        }
    }

    .ANPXFN0z .iTCJ_6Rr .sSYyWLgn {
        margin-top: 48px
    }

    .ANPXFN0z .iTCJ_6Rr .tRNlN1qJ {
        font-size: 48px;
        line-height: 72px;
        font-weight: 600;
        color: #cccccc
    }

    @media (max-width: 768px) {
        .ANPXFN0z .iTCJ_6Rr .tRNlN1qJ {
            font-size:32px;
            line-height: 48px
        }
    }

    .ANPXFN0z .iTCJ_6Rr .tRNlN1qJ .K2bvoVJw {
        color: #ffffff !important;
        position: relative
    }

    .ANPXFN0z .iTCJ_6Rr .tRNlN1qJ .K2bvoVJw>section {
        position: absolute;
        top: 5px;
        left: 30px
    }

    @media (max-width: 768px) {
        .ANPXFN0z .iTCJ_6Rr .tRNlN1qJ .K2bvoVJw>section {
            left:21px
        }
    }

    .ANPXFN0z .iTCJ_6Rr .tRNlN1qJ .K2bvoVJw .fPktBGED {
        color: #cccccc !important;
        position: absolute;
        width: 224px
    }

    .NoqrPN8x {
        position: relative;
        cursor: pointer
    }

    @media (max-width: 768px) {
        .NoqrPN8x {
            display:inline-block
        }
    }

    .NoqrPN8x .cOYmSSQz {
        font-weight: 600;
        text-decoration: underline;
        color: #ffffff
    }

    .NoqrPN8x .YNqeQYjb {
        font-family: "ucglyphs" !important;
        font-size: 20px;
        line-height: 20px;
        margin-left: 10px;
        color: #ffffff;
        display: inline-block;
        transition: transform 0.3s ease-out;
        transform: translateY(-7px)
    }

    .NoqrPN8x .rTUBA62j {
        transform: translateY(-7px) rotateZ(180deg)
    }

    .NoqrPN8x .ARCgkL2S {
        position: absolute;
        top: 64px;
        left: 0px;
        right: 0px;
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0px 4px 12px rgba(15,15,15,0.08);
        z-index: 3;
        max-height: 332px;
        overflow: scroll;
        padding: 8px 0px
    }

    @media (max-width: 768px) {
        .NoqrPN8x .ARCgkL2S {
            top:48px
        }
    }

    .NoqrPN8x .ARCgkL2S .LWCsCu6x {
        padding: 8px 16px;
        cursor: pointer;
        display: flex;
        align-items: center
    }

    .NoqrPN8x .ARCgkL2S .LWCsCu6x:hover {
        background-color: #f5f5f5
    }

    .NoqrPN8x .ARCgkL2S .LWCsCu6x:nth-child(1) {
        border-radius: 8px 8px 0 0
    }

    .NoqrPN8x .ARCgkL2S .LWCsCu6x:last-child {
        border-radius: 0 0 8px 8px
    }

    .NoqrPN8x .ARCgkL2S .LWCsCu6x>span {
        font-size: 16px;
        font-weight: normal;
        line-height: 28px;
        color: #0f0f0f
    }

    @media (max-width: 768px) {
        .NoqrPN8x .ARCgkL2S .LWCsCu6x>span {
            font-size:14px;
            line-height: 24px
        }
    }

    .NoqrPN8x .ARCgkL2S .LWCsCu6x .Mzc01VTa {
        font-family: "ucglyphs" !important;
        font-size: 25px;
        line-height: 25px;
        margin-left: 10px;
        margin-top: -3px
    }

    .dzzcRU0h {
        animation: wPpPmnBB 0.6s cubic-bezier(0.39, 0.575, 0.565, 1) both
    }

    @keyframes wPpPmnBB {
        0% {
            transform: translateY(50px);
            opacity: 0
        }

        100% {
            transform: translateY(0);
            opacity: 1
        }
    }

    .lB3xR3O1 {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 8px 16px;
        font-family: "OpenSauceOne";
        font-size: 14px;
        line-height: 20px;
        color: white
    }

    @media (max-width: 768px) {
        .lB3xR3O1 {
            font-size:12px;
            line-height: 16px
        }
    }

    .lB3xR3O1 .jD6APFMH {
        font-weight: 600;
        text-decoration: underline;
        cursor: pointer
    }

    @use "sass:map";@use "sass:list";.nQUlUTVH {
        background-color: #0d0d0d;
        font-family: "OpenSauceOne"
    }

    .nQUlUTVH .G9vzRvSr {
        width: 1136px;
        margin: 0 auto;
        padding: 48px 0 64px 0;
        display: flex;
        gap: 32px;
        flex-direction: row
    }

    @media (max-width: 768px) {
        .nQUlUTVH .G9vzRvSr {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .nQUlUTVH .G9vzRvSr {
            width:768px;
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .nQUlUTVH .G9vzRvSr {
            padding:48px 0 0 0;
            flex-direction: column
        }
    }

    .nQUlUTVH .G9vzRvSr .JhAUryfI {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: center
    }

    @media (max-width: 768px) {
        .nQUlUTVH .G9vzRvSr .JhAUryfI {
            align-items:center;
            text-align: center
        }
    }

    .nQUlUTVH .G9vzRvSr .JhAUryfI .YqtQWyGk {
        height: 18px;
        width: 174px;
        margin-bottom: 48px
    }

    @media (max-width: 768px) {
        .nQUlUTVH .G9vzRvSr .JhAUryfI .YqtQWyGk {
            height:12px;
            width: 116px;
            margin-bottom: 16px
        }
    }

    .nQUlUTVH .G9vzRvSr .JhAUryfI .YqtQWyGk .qqX_iTnl {
        height: 100%;
        width: 100%;
        object-fit: contain
    }

    .nQUlUTVH .G9vzRvSr .JhAUryfI .KcpWQ2cD {
        font-size: 32px;
        line-height: 40px;
        color: #b0b0b0;
        font-weight: 400;
        letter-spacing: -0.02em;
        margin-bottom: 8px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .nQUlUTVH .G9vzRvSr .JhAUryfI .KcpWQ2cD {
            font-size:24px;
            line-height: 32px
        }
    }

    @media (max-width: 768px) {
        .nQUlUTVH .G9vzRvSr .JhAUryfI .KcpWQ2cD {
            font-size:20px;
            line-height: 25px;
            margin-bottom: 16px
        }
    }

    .nQUlUTVH .G9vzRvSr .JhAUryfI .JYVDLKdz {
        font-size: 64px;
        line-height: 76px;
        font-weight: 500;
        color: white;
        letter-spacing: -0.02em;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .nQUlUTVH .G9vzRvSr .JhAUryfI .JYVDLKdz {
            font-size:40px;
            line-height: 48px
        }
    }

    @media (max-width: 768px) {
        .nQUlUTVH .G9vzRvSr .JhAUryfI .JYVDLKdz {
            font-size:40px;
            line-height: 48px
        }
    }

    .nQUlUTVH .G9vzRvSr .UqcilK5J {
        flex: 1;
        width: 544px;
        height: 544px;
        object-fit: contain;
        border-radius: 8px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .nQUlUTVH .G9vzRvSr .UqcilK5J {
            width:434px;
            height: 434px
        }
    }

    @media (max-width: 768px) {
        .nQUlUTVH .G9vzRvSr .UqcilK5J {
            width:100%;
            object-fit: cover
        }
    }

    .nQUlUTVH ._51O6y846 {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 14px 0;
        font-size: 14px;
        line-height: 20px;
        font-weight: 600;
        background-color: #333333;
        color: white
    }

    .nQUlUTVH ._51O6y846:hover {
        cursor: pointer
    }

    .nQUlUTVH ._51O6y846 .FmSR7ne7 {
        font-family: "ucglyphs" !important;
        font-size: 16px;
        line-height: 16px;
        margin-left: 8px
    }

    @use "sass:map";@use "sass:list";.VT2HXHrY {
        width: 100%;
        height: 65px;
        background-color: #0f0f0f;
        z-index: 5;
        position: sticky;
        top: -1px
    }

    .VT2HXHrY .UC7xeAGG {
        font-family: "OpenSauceOne";
        width: 1136px;
        margin: 0 auto;
        height: 100%;
        padding: 16px 0;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center
    }

    @media (max-width: 768px) {
        .VT2HXHrY .UC7xeAGG {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .VT2HXHrY .UC7xeAGG {
            padding:14px 0
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .VT2HXHrY .UC7xeAGG {
            width:768px;
            margin: 0 auto
        }
    }

    .VT2HXHrY .UC7xeAGG .wPFxn_yg {
        height: 32px
    }

    .VT2HXHrY .UC7xeAGG .wPFxn_yg:hover {
        cursor: pointer
    }

    .VT2HXHrY .UC7xeAGG .wPFxn_yg .lSh_fuL4 {
        height: 100%;
        object-fit: contain
    }

    .VT2HXHrY .UC7xeAGG .EorUciZR {
        flex: 1;
        display: flex;
        flex-direction: row-reverse;
        gap: 24px;
        align-items: center
    }

    .GtqqIF6F {
        padding: 120px 0;
        font-family: "OpenSauceOne"
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .GtqqIF6F {
            padding:64px 0px
        }
    }

    @media (max-width: 768px) {
        .GtqqIF6F {
            padding:48px 0px
        }
    }

    .GtqqIF6F .C4DLzGLD {
        width: 1136px;
        margin: 0 auto
    }

    @media (max-width: 768px) {
        .GtqqIF6F .C4DLzGLD {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .GtqqIF6F .C4DLzGLD {
            width:768px;
            margin: 0 auto
        }
    }

    .GtqqIF6F .C4DLzGLD .D6kqEdt4 {
        font-size: 16px;
        line-height: 24px;
        font-weight: 600;
        margin-bottom: 24px
    }

    @media (max-width: 768px) {
        .GtqqIF6F .C4DLzGLD .D6kqEdt4 {
            font-size:20px;
            line-height: 28px;
            margin-bottom: 8px
        }
    }

    .GtqqIF6F .C4DLzGLD .Vx4fAanN {
        display: flex;
        flex-direction: row;
        font-weight: 400;
        font-size: 14px;
        line-height: 21px;
        color: #545454;
        gap: 32px
    }

    @media (max-width: 768px) {
        .GtqqIF6F .C4DLzGLD .Vx4fAanN {
            flex-direction:column;
            gap: 24px;
            font-size: 12px;
            line-height: 20px
        }
    }

    .Yt7W3ffN {
        padding: 120px 0;
        width: 1136px;
        margin: 0 auto;
        background-color: white;
        display: flex;
        flex-direction: row;
        gap: 24px;
        font-family: "OpenSauceOne"
    }

    @media (max-width: 768px) {
        .Yt7W3ffN {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .Yt7W3ffN {
            width:768px;
            margin: 0 auto;
            padding: 64px 0;
            flex-direction: column
        }
    }

    @media (max-width: 768px) {
        .Yt7W3ffN {
            padding:48px 0px;
            flex-direction: column
        }
    }

    .Yt7W3ffN .nay_otMZ {
        font-size: 64px;
        line-height: 150%;
        font-weight: 600;
        flex: 1
    }

    @media (max-width: 768px) {
        .Yt7W3ffN .nay_otMZ {
            font-size:40px;
            line-height: 50px
        }
    }

    .Yt7W3ffN .jBhz89bh {
        display: flex;
        flex: 1;
        flex-direction: column;
        gap: 32px;
        color: #545454
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .Yt7W3ffN .jBhz89bh {
            gap:16px
        }
    }

    @media (max-width: 768px) {
        .Yt7W3ffN .jBhz89bh {
            gap:16px
        }
    }

    .Yt7W3ffN .jBhz89bh .tM1Birqn {
        height: 48px;
        width: 192px
    }

    .Yt7W3ffN .jBhz89bh .tM1Birqn .YdCBm5JA {
        height: 100%;
        width: 100%;
        object-fit: contain
    }

    .sIwkSS0r {
        margin-bottom: 48px;
        font-size: 16px;
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 32px
    }

    @media (max-width: 768px) {
        .sIwkSS0r {
            margin-bottom:32px;
            display: flex;
            flex-direction: column-reverse;
            gap: 24px
        }
    }

    .sIwkSS0r .SJ61LnAX .wU8lYOs4 {
        font-size: 4rem;
        line-height: 78px;
        font-weight: 600;
        letter-spacing: -0.02em;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .sIwkSS0r .SJ61LnAX .wU8lYOs4 {
            font-size:2.5rem;
            line-height: 50px;
            white-space: normal
        }
    }

    @media (max-width: 768px) {
        .sIwkSS0r .SJ61LnAX .wU8lYOs4 {
            font-size:2.5rem;
            line-height: 50px;
            white-space: normal
        }
    }

    .sIwkSS0r .SJ61LnAX .qskwM7os {
        font-size: 1.5rem;
        line-height: 150%;
        font-weight: 400;
        margin-top: 16px;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .sIwkSS0r .SJ61LnAX .qskwM7os {
            white-space:normal;
            font-size: 1rem;
            line-height: 150%;
            margin-top: 8px;
            white-space: normal
        }
    }

    @media (max-width: 768px) {
        .sIwkSS0r .SJ61LnAX .qskwM7os {
            font-size:1rem;
            line-height: 150%;
            margin-top: 8px;
            white-space: normal
        }
    }

    .sIwkSS0r .DmJWeSV2 {
        max-width: 730px
    }

    .sIwkSS0r .DmJWeSV2 .wU8lYOs4 {
        font-size: 48px;
        line-height: 60px;
        font-weight: 600;
        letter-spacing: -0.02em;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .sIwkSS0r .DmJWeSV2 .wU8lYOs4 {
            font-size:32px;
            line-height: 40px
        }
    }

    @media (max-width: 768px) {
        .sIwkSS0r .DmJWeSV2 .wU8lYOs4 {
            font-size:32px;
            line-height: 40px
        }
    }

    .sIwkSS0r .DmJWeSV2 .qskwM7os {
        font-size: 24px;
        line-height: 150%;
        font-weight: 400;
        margin-top: 16px;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .sIwkSS0r .DmJWeSV2 .qskwM7os {
            white-space:normal;
            font-size: 16px;
            margin-top: 8px
        }
    }

    @media (max-width: 768px) {
        .sIwkSS0r .DmJWeSV2 .qskwM7os {
            font-size:16px;
            margin-top: 8px;
            white-space: normal
        }
    }

    .sIwkSS0r .fXNbicRx {
        display: flex;
        flex-direction: row-reverse
    }

    @media (max-width: 768px) {
        .sIwkSS0r .fXNbicRx {
            flex-direction:row
        }
    }

    .sIwkSS0r .fXNbicRx .dpSWdIXw {
        width: 160px;
        height: 160px;
        object-fit: cover
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .sIwkSS0r .fXNbicRx .dpSWdIXw {
            width:128px;
            height: 128px
        }
    }

    @media (max-width: 768px) {
        .sIwkSS0r .fXNbicRx .dpSWdIXw {
            width:96px;
            height: 96px
        }
    }

    .OSSvAC5G {
        width: 1136px;
        margin: 0 auto;
        font-family: "OpenSauceOne";
        padding: 120px 0
    }

    @media (max-width: 768px) {
        .OSSvAC5G {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G {
            padding:48px 0
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G {
            padding:64px 0;
            width: 768px;
            margin: 0 auto
        }
    }

    .OSSvAC5G .f7R2RGer {
        display: grid;
        column-gap: 32px;
        row-gap: 32px;
        margin-bottom: 32px
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer {
            display:flex;
            flex-direction: column;
            gap: 24px
        }
    }

    .OSSvAC5G .f7R2RGer .OdFHVEHS {
        width: 100%;
        height: 100%;
        position: relative
    }

    .OSSvAC5G .f7R2RGer .OdFHVEHS .e0wvWuzq {
        width: 100%;
        object-fit: cover
    }

    .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 {
        font-family: "OpenSauceOne";
        position: absolute;
        height: 100%;
        top: 0;
        left: 0;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: flex-start;
        padding: 32px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 {
            padding:24px
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 {
            width:100%;
            padding: 24px
        }
    }

    .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 .hwO6uNy2 {
        font-size: 24px;
        line-height: 36px;
        font-weight: 500;
        max-width: 320px;
        color: white;
        padding-bottom: 8px;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 .hwO6uNy2 {
            font-size:20px;
            line-height: 28px;
            white-space: normal
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 .hwO6uNy2 {
            font-size:20px;
            line-height: 28px;
            white-space: normal
        }
    }

    .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 .S2P28MZO {
        font-size: 16px;
        line-height: 24px;
        max-width: 320px;
        color: #cccccc;
        font-weight: 400
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 .S2P28MZO {
            font-size:14px;
            line-height: 20px
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer .OdFHVEHS ._1L5Adc6 .S2P28MZO {
            font-size:14px;
            line-height: 20px
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD {
        background-color: #000000;
        border-radius: 8px;
        display: flex;
        flex-direction: row;
        width: 100%
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD {
            flex-direction:column
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ {
        flex: 1;
        flex-direction: column;
        display: flex;
        padding-top: 48px;
        padding-left: 52px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ {
            padding-top:24px;
            padding-left: 24px
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ {
            padding:24px 24px 0px 24px
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .wKBpAsOJ {
        flex: 1;
        max-width: 460px
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .wKBpAsOJ .hwO6uNy2 {
        font-size: 64px;
        line-height: 76px;
        color: white;
        font-weight: 500;
        letter-spacing: -0.02em;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .wKBpAsOJ .hwO6uNy2 {
            font-size:48px;
            line-height: 58px
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .wKBpAsOJ .hwO6uNy2 {
            font-size:48px;
            line-height: 58px;
            margin-bottom: 8px
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .wKBpAsOJ .S2P28MZO {
        font-size: 64px;
        line-height: 76px;
        color: white;
        font-weight: 500;
        letter-spacing: -0.02em;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .wKBpAsOJ .S2P28MZO {
            font-size:48px;
            line-height: 58px
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .wKBpAsOJ .S2P28MZO {
            font-size:48px;
            line-height: 58px;
            margin-bottom: 8px
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .EVw6EPqV {
        flex: 1;
        display: flex;
        flex-direction: column-reverse
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .EVw6EPqV .hpkd8kDC {
        font-size: 16px;
        line-height: 24px;
        color: #e2e2e2;
        font-weight: 400;
        margin-bottom: 48px;
        max-width: 400px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .EVw6EPqV .hpkd8kDC {
            margin-bottom:24px
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .gqwTYRy_ .EVw6EPqV .hpkd8kDC {
            font-size:14px;
            line-height: 20px;
            margin-top: 8px;
            margin-bottom: 0px
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 {
        flex: 1;
        flex-direction: column;
        display: flex;
        padding-top: 48px;
        padding-left: 48px
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 {
            padding:24px 24px 0px 24px
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 {
            padding-top:24px;
            padding-left: 24px
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 .hwO6uNy2 {
        font-size: 24px;
        line-height: 36px;
        font-weight: 500;
        margin-bottom: 8px;
        max-width: 400px;
        color: white
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 .hwO6uNy2 {
            max-width:320px;
            font-size: 20px;
            line-height: 28px
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 .hwO6uNy2 {
            font-size:20px;
            line-height: 28px
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 .S2P28MZO {
        font-size: 16px;
        line-height: 24px;
        color: #cccccc;
        font-weight: 400;
        max-width: 400px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 .S2P28MZO {
            max-width:320px
        }
    }

    @media (max-width: 768px) {
        .OSSvAC5G .f7R2RGer ._m7iE8VD .J1QHxKv4 .S2P28MZO {
            font-size:14px;
            line-height: 20px
        }
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .zi95mNXV {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: flex-end
    }

    .OSSvAC5G .f7R2RGer ._m7iE8VD .zi95mNXV .RnzoHptI {
        object-fit: cover;
        width: 100%;
        border-radius: 8px
    }

    .MiPpIPnf {
        padding: 120px 0;
        background-color: #f5f5f5;
        font-family: "OpenSauceOne"
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .MiPpIPnf {
            padding:64px 0
        }
    }

    @media (max-width: 768px) {
        .MiPpIPnf {
            padding:48px 0
        }
    }

    .MiPpIPnf .pEEwpPkK {
        width: 1136px;
        margin: 0 auto
    }

    @media (max-width: 768px) {
        .MiPpIPnf .pEEwpPkK {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .MiPpIPnf .pEEwpPkK {
            width:768px;
            margin: 0 auto
        }
    }

    .MiPpIPnf .pEEwpPkK .aPHoTzP4 {
        border-top: 1px solid #e3e3e3;
        width: 100%;
        margin: 24px 0
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .MiPpIPnf .pEEwpPkK .aPHoTzP4 {
            margin:16px 0
        }
    }

    @media (max-width: 768px) {
        .MiPpIPnf .pEEwpPkK .aPHoTzP4 {
            margin:16px 0
        }
    }

    .MiPpIPnf .pEEwpPkK .kpNpcZ3q {
        display: grid;
        column-gap: 32px
    }

    @media (max-width: 768px) {
        .MiPpIPnf .pEEwpPkK .kpNpcZ3q {
            column-gap:12px
        }
    }

    .MiPpIPnf .pEEwpPkK .kpNpcZ3q .sLxfHmql {
        padding-bottom: 48px
    }

    @media (max-width: 768px) {
        .MiPpIPnf .pEEwpPkK .kpNpcZ3q .sLxfHmql {
            padding-bottom:32px
        }
    }

    .MiPpIPnf .pEEwpPkK .kpNpcZ3q .sLxfHmql .cVUUm0Jq {
        width: 48px;
        height: 48px;
        margin-bottom: 16px
    }

    @media (max-width: 768px) {
        .MiPpIPnf .pEEwpPkK .kpNpcZ3q .sLxfHmql .cVUUm0Jq {
            width:32px;
            height: 32px
        }
    }

    .MiPpIPnf .pEEwpPkK .kpNpcZ3q .sLxfHmql .pB71i7fz {
        font-size: 32px;
        font-weight: 500;
        line-height: 40px;
        letter-spacing: -0.02em;
        color: #0f0f0f
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .MiPpIPnf .pEEwpPkK .kpNpcZ3q .sLxfHmql .pB71i7fz {
            font-size:24px;
            line-height: 32px
        }
    }

    @media (max-width: 768px) {
        .MiPpIPnf .pEEwpPkK .kpNpcZ3q .sLxfHmql .pB71i7fz {
            font-size:20px;
            line-height: 28px
        }
    }

    .MiPpIPnf .pEEwpPkK .go1hNuf9 {
        font-size: 12px;
        line-height: 40px;
        font-weight: 400;
        color: #545454;
        margin-top: 48px
    }

    @media (max-width: 768px) {
        .MiPpIPnf .pEEwpPkK .go1hNuf9 {
            font-size:10px;
            line-height: 14px;
            margin-top: 32px
        }
    }

    .vys6e_FB {
        width: 1136px;
        margin: 0 auto;
        font-family: "OpenSauceOne";
        padding: 120px 0
    }

    @media (max-width: 768px) {
        .vys6e_FB {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB {
            width:768px;
            margin: 0 auto;
            padding: 64px 0
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB {
            padding:48px 0
        }
    }

    .vys6e_FB .UPMnLlkW {
        overflow-x: scroll
    }

    .vys6e_FB .UPMnLlkW::-webkit-scrollbar {
        -webkit-appearance: none;
        width: 0;
        display: none
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .IUw_gZlq {
        vertical-align: top;
        text-align: left;
        padding: 24px 0;
        min-width: 272px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .IUw_gZlq {
            min-width:176px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .IUw_gZlq {
            min-width:128px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .IUw_gZlq .HHC9C1I2 {
        font-size: 16px;
        font-weight: 500;
        line-height: 24px;
        color: #0f0f0f
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .IUw_gZlq .HHC9C1I2 {
            font-size:14px;
            line-height: 20px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .IUw_gZlq .HHC9C1I2 {
            font-size:14px;
            line-height: 20px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD {
        padding: 24px 16px;
        vertical-align: top;
        text-align: left;
        min-width: 288px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD {
            min-width:212px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD {
            padding:24px 8px;
            min-width: 164px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .jC5I4ArU {
        width: 216px;
        height: 216px;
        margin-bottom: 16px
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .jC5I4ArU {
            width:128px;
            height: 128px;
            margin-bottom: 8px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .TJCgz2Ua {
        font-size: 32px;
        font-weight: 700;
        line-height: 40px;
        letter-spacing: -0.02em;
        color: #0f0f0f
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .TJCgz2Ua {
            font-size:20px;
            line-height: 28px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .TJCgz2Ua {
            font-size:20px;
            line-height: 28px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .R_BbXc8I {
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        color: #0f0f0f;
        margin-top: 8px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .R_BbXc8I {
            font-size:12px;
            line-height: 20px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .R_BbXc8I {
            font-size:12px;
            line-height: 20px;
            margin-top: 4px;
            min-height: 40px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .RXosY1yV {
        font-size: 24px;
        font-weight: 600;
        line-height: 30px;
        margin-top: 32px;
        color: #0f0f0f
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .RXosY1yV {
            font-size:14px;
            line-height: 20px;
            margin-top: 16px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .RXosY1yV {
            font-size:14px;
            line-height: 20px;
            margin-top: 16px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .IgxxPK80 {
        margin-top: 32px;
        height: 50px;
        flex-direction: column;
        display: flex;
        align-items: flex-start
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .IgxxPK80 {
            margin-top:16px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .GS6w9K_9 .IgxxPK80 {
            margin-top:16px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .jC5I4ArU {
        width: 48px;
        height: 48px;
        margin-bottom: 4px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .jC5I4ArU {
            font-size:36px;
            line-height: 36px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .jC5I4ArU {
            width:36px;
            height: 36px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .TJCgz2Ua {
        font-size: 16px;
        font-weight: 500;
        line-height: 24px;
        color: #0f0f0f
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .TJCgz2Ua {
            font-size:14px;
            line-height: 20px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .TJCgz2Ua {
            font-size:14px;
            line-height: 20px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .R_BbXc8I {
        font-size: 16px;
        font-weight: 500;
        line-height: 24px;
        color: #545454
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .R_BbXc8I {
            font-size:14px;
            line-height: 20px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .R_BbXc8I {
            font-size:14px;
            line-height: 20px
        }
    }

    .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .RXosY1yV {
        font-size: 14px;
        line-height: 20px;
        font-weight: 300;
        color: #545454;
        margin-top: 4px;
        white-space: pre-line
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .RXosY1yV {
            font-size:12px;
            line-height: 20px
        }
    }

    @media (max-width: 768px) {
        .vys6e_FB .UPMnLlkW ._Mawhihk .Ua4YB6XD .wohDXLkt .RXosY1yV {
            font-size:12px;
            line-height: 20px
        }
    }

    .b5WkYtRq {
        background-color: #f0ecfc
    }

    .b5WkYtRq .wG6srIiV {
        padding: 120px 0px;
        width: 1136px;
        margin: 0 auto;
        font-family: "OpenSauceOne"
    }

    @media (max-width: 768px) {
        .b5WkYtRq .wG6srIiV {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .b5WkYtRq .wG6srIiV {
            width:768px;
            margin: 0 auto;
            padding: 64px 0
        }
    }

    @media (max-width: 768px) {
        .b5WkYtRq .wG6srIiV {
            padding:48px 0px 64px 0px
        }
    }

    .b5WkYtRq .wG6srIiV .pzMblPtB {
        display: grid;
        gap: 32px;
        margin-top: 48px
    }

    @media (max-width: 768px) {
        .b5WkYtRq .wG6srIiV .pzMblPtB {
            display:flex;
            flex-direction: column;
            gap: 24px
        }
    }

    @media (max-width: 768px) {
        .b5WkYtRq .wG6srIiV .pzMblPtB .Jb8551Kw {
            display:flex;
            flex-direction: row;
            gap: 16px;
            align-items: center
        }
    }

    .b5WkYtRq .wG6srIiV .pzMblPtB .Jb8551Kw .PXWa4Rkj {
        width: 48px;
        height: 48px;
        margin-bottom: 16px;
        border-radius: 4px
    }

    @media (max-width: 768px) {
        .b5WkYtRq .wG6srIiV .pzMblPtB .Jb8551Kw .PXWa4Rkj {
            width:36px;
            height: 36px;
            margin-bottom: 0px
        }
    }

    .b5WkYtRq .wG6srIiV .pzMblPtB .Jb8551Kw .WxD1cVC_ {
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        color: #0f0f0f
    }

    @media (max-width: 768px) {
        .b5WkYtRq .wG6srIiV .pzMblPtB .Jb8551Kw .WxD1cVC_ {
            font-size:16px;
            line-height: 24px
        }
    }

    .RSJDJjqb {
        width: 1136px;
        margin: 0 auto;
        font-family: "OpenSauceOne"
    }

    @media (max-width: 768px) {
        .RSJDJjqb {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .RSJDJjqb {
            width:768px;
            margin: 0 auto
        }
    }

    .RSJDJjqb .olHrukWC {
        background-color: #f5f5f5;
        border-radius: 8px;
        padding: 24px 96px 24px 24px;
        display: flex;
        flex-direction: row;
        gap: 48px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .RSJDJjqb .olHrukWC {
            padding:16px 16px;
            gap: 16px
        }
    }

    @media (max-width: 768px) {
        .RSJDJjqb .olHrukWC {
            display:flex;
            flex-direction: column;
            padding: 16px 16px;
            gap: 16px
        }
    }

    .RSJDJjqb .olHrukWC .f2K_6Wa1 {
        display: flex;
        flex-direction: row;
        gap: 8px
    }

    .RSJDJjqb .olHrukWC .f2K_6Wa1 .bqw3y4D7 {
        width: 48px;
        height: 48px
    }

    .RSJDJjqb .olHrukWC .EAeGgDIk {
        font-size: 16px;
        line-height: 24px;
        color: #0f0f0f
    }

    @media (max-width: 768px) {
        .RSJDJjqb .olHrukWC .EAeGgDIk {
            font-size:12px;
            line-height: 18px
        }
    }

    .LfD7GXv9 {
        padding: 80px 0;
        width: 1136px;
        margin: 0 auto;
        font-family: "OpenSauceOne"
    }

    @media (max-width: 768px) {
        .LfD7GXv9 {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .LfD7GXv9 {
            width:768px;
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .LfD7GXv9 {
            padding:48px 0
        }
    }

    .LfD7GXv9 .XreloIxG {
        background-color: #0f0f0f;
        border-radius: 8px;
        display: flex;
        flex-direction: row;
        gap: 8%;
        width: 100%;
        padding: 0px 12% 0px 18%
    }

    @media (max-width: 768px) {
        .LfD7GXv9 .XreloIxG {
            flex-direction:column;
            padding: 24px 16px;
            gap: 32px
        }
    }

    .LfD7GXv9 .XreloIxG .aAsNbL8Z {
        flex-direction: column;
        display: flex;
        padding-top: 64px;
        padding-bottom: 64px
    }

    @media (max-width: 768px) {
        .LfD7GXv9 .XreloIxG .aAsNbL8Z {
            padding-top:0;
            padding-bottom: 0
        }
    }

    .LfD7GXv9 .XreloIxG .aAsNbL8Z .U8Kl0naq {
        letter-spacing: -0.02em;
        font-size: 32px;
        line-height: 40px;
        font-weight: 600;
        color: white;
        margin-bottom: 8px
    }

    @media (max-width: 768px) {
        .LfD7GXv9 .XreloIxG .aAsNbL8Z .U8Kl0naq {
            font-size:24px;
            line-height: 32px;
            font-weight: 700
        }
    }

    .LfD7GXv9 .XreloIxG .aAsNbL8Z .LU7SaePA {
        font-size: 16px;
        line-height: 24px;
        color: #e3e3e3;
        margin-bottom: 24px;
        font-weight: 400
    }

    @media (max-width: 768px) {
        .LfD7GXv9 .XreloIxG .aAsNbL8Z .LU7SaePA {
            font-size:14px;
            line-height: 20px
        }
    }

    .LfD7GXv9 .XreloIxG .D1OQnrxF {
        width: 300px;
        object-fit: contain
    }

    @media (max-width: 768px) {
        .LfD7GXv9 .XreloIxG .D1OQnrxF {
            width:100%;
            align-items: center;
            justify-content: center
        }
    }

    .JdMY1gdj {
        padding: 120px 0px;
        width: 1136px;
        margin: 0 auto;
        font-family: "OpenSauceOne"
    }

    @media (max-width: 768px) {
        .JdMY1gdj {
            width:calc(100% - 32px);
            margin: 0 auto
        }
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .JdMY1gdj {
            width:768px;
            margin: 0 auto
        }
    }

    @media (max-width: 768px) {
        .JdMY1gdj {
            padding:48px 0px
        }
    }

    .JdMY1gdj .Z3HGdcho {
        display: flex;
        gap: 32px;
        flex-direction: row
    }

    @media (max-width: 768px) {
        .JdMY1gdj .Z3HGdcho {
            flex-direction:column
        }
    }

    .JdMY1gdj .Z3HGdcho .qqKIfpy6 {
        flex: 1;
        display: flex;
        flex-direction: column
    }

    .JdMY1gdj .Z3HGdcho .qqKIfpy6 .nnMJ1wFW {
        width: 133px;
        height: 28px;
        object-fit: contain;
        border-radius: 4px;
        margin-bottom: 8px
    }

    .JdMY1gdj .Z3HGdcho .qqKIfpy6 .v1IHn7zr {
        font-size: 48px;
        line-height: 60px;
        color: #0f0f0f;
        font-weight: 600;
        letter-spacing: -0.02em;
        margin-bottom: 16px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .JdMY1gdj .Z3HGdcho .qqKIfpy6 .v1IHn7zr {
            font-size:32px;
            line-height: 40px
        }
    }

    @media (max-width: 768px) {
        .JdMY1gdj .Z3HGdcho .qqKIfpy6 .v1IHn7zr {
            font-size:32px;
            line-height: 40px
        }
    }

    .JdMY1gdj .Z3HGdcho .qqKIfpy6 .rqbFHhVE {
        display: grid;
        margin-top: 48px;
        gap: 32px;
        grid-template-columns: repeat(3, 1fr)
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .JdMY1gdj .Z3HGdcho .qqKIfpy6 .rqbFHhVE {
            margin-top:32px
        }
    }

    @media (max-width: 768px) {
        .JdMY1gdj .Z3HGdcho .qqKIfpy6 .rqbFHhVE {
            margin-top:32px;
            grid-template-columns: repeat(1, 1fr);
            gap: 24px
        }
    }

    @media (max-width: 768px) {
        .JdMY1gdj .Z3HGdcho .qqKIfpy6 .rqbFHhVE .yE146ee9 {
            display:flex;
            flex-direction: row;
            gap: 16px;
            align-items: center
        }
    }

    .JdMY1gdj .Z3HGdcho .qqKIfpy6 .rqbFHhVE .yE146ee9 .MMivYCds {
        width: 48px;
        height: 48px;
        margin-bottom: 16px
    }

    @media (max-width: 768px) {
        .JdMY1gdj .Z3HGdcho .qqKIfpy6 .rqbFHhVE .yE146ee9 .MMivYCds {
            width:36px;
            height: 36px;
            margin-bottom: 0px
        }
    }

    .JdMY1gdj .Z3HGdcho .qqKIfpy6 .rqbFHhVE .yE146ee9 .bJgmJI3X {
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        color: #0f0f0f
    }

    .JdMY1gdj .Z3HGdcho .zipIC_cU {
        flex: 1;
        display: flex;
        flex-direction: row-reverse
    }

    .JdMY1gdj .Z3HGdcho .zipIC_cU .zPORc4MB {
        width: 448px;
        height: 448px;
        object-fit: contain;
        border-radius: 16px
    }

    @media (max-width: 1136px) and (min-width: 769px) {
        .JdMY1gdj .Z3HGdcho .zipIC_cU .zPORc4MB {
            width:328px;
            height: 328px;
            border-radius: 16px
        }
    }

    @media (max-width: 768px) {
        .JdMY1gdj .Z3HGdcho .zipIC_cU .zPORc4MB {
            width:100%;
            height: auto;
            object-fit: cover;
            border-radius: 8px
        }
    }

    @font-face {
        font-family: "ucglyphs";
        font-display: swap;
        src: url(https://static.urbanclap.com/dist-product-web/client/89f5c055f5fe820cc077.eot);
        src: url(https://static.urbanclap.com/dist-product-web/client/89f5c055f5fe820cc077.eot?#iefix) format("embedded-opentype"),url(https://static.urbanclap.com/dist-product-web/client/7248e683da7e3d796939.woff) format("woff"),url(https://static.urbanclap.com/dist-product-web/client/c2c802662860c8f752b8.ttf) format("truetype"),url(https://static.urbanclap.com/dist-product-web/client/21fa1fcb3083d336809d.svg#ucglyphs) format("svg");
        font-weight: normal;
        font-style: normal
    }

    [data-icon]:before {
        font-family: "ucglyphs" !important;
        content: attr(data-icon);
        font-style: normal !important;
        font-weight: normal !important;
        font-variant: normal !important;
        text-transform: none !important;
        speak: none;
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale
    }

    @font-face {
        font-family: "ucglyphs" !important;
        src: url(https://static.urbanclap.com/dist-product-web/client/89f5c055f5fe820cc077.eot);
        src: url(https://static.urbanclap.com/dist-product-web/client/89f5c055f5fe820cc077.eot?#iefix) format("embedded-opentype"),url(https://static.urbanclap.com/dist-product-web/client/7248e683da7e3d796939.woff) format("woff"),url(https://static.urbanclap.com/dist-product-web/client/c2c802662860c8f752b8.ttf) format("truetype"),url(https://static.urbanclap.com/dist-product-web/client/21fa1fcb3083d336809d.svg#ucglyphs) format("svg");
        font-weight: normal;
        font-style: normal
    }

    button,input,optgroup,select,textarea {
        font: inherit;
        font-size: 100%;
        line-height: 1.15;
        margin: 0
    }

    button,input {
        overflow: visible
    }

    button,select {
        text-transform: none
    }

    button,[type="button"],[type="reset"],[type="submit"] {
        -webkit-appearance: button
    }

    @media only screen and (max-width: 768px) {
        div[data-key="quickLinksSeo"] a,div[data-key="customerSection"] a,div[data-key="partnerSection"] a,div[data-key="companySection"] a {
            padding:20px 4px
        }

        div[data-key="categoryHeaderStory"]>div>div>div {
            height: calc(100vw / 16 * 9) !important
        }

        div[data-key="categoryHeaderStory"]>div>div>div>div {
            width: 100% !important
        }
    }

    .SA9zAf3R {
        height: 55px;
        background: #fff;
        box-shadow: 0px -2px 8px 0px rgba(0,0,0,0.16);
        display: flex;
        position: sticky;
        width: 100%;
        bottom: -1px;
        z-index: 3
    }

    .SA9zAf3R .QaIwAvMO {
        flex: 1;
        display: flex
    }

    .SA9zAf3R .QaIwAvMO>div {
        width: 100%
    }

    .OJtY1r__ {
        flex: 1;
        display: flex;
        height: 100%;
        justify-content: center;
        align-items: center;
        flex-direction: column
    }

    .OJtY1r__ .DmLP9Oxr,.OJtY1r__ svg {
        line-height: 16px;
        font-size: 11px;
        opacity: 0.3
    }

    .u2tAc7TX svg,.u2tAc7TX .DmLP9Oxr {
        opacity: 1
    }

    .b_e36c {
        position: relative;
        overflow: hidden;
        display: inline-block;
    }

    .b_e36c .b_g36c {
        position: absolute;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: rgba(0, 0, 0, 0.1);
        opacity: 0;
    }

    .b_e36c .b_i36c {
        animation: b_i36c .5s ease-out;
    }

    @keyframes b_i36c {
        0% {
            transform: scale(1, 1);
            z-index: -1;
            opacity: 0;
        }

        50% {
            transform: scale(80, 80);
            z-index: 1;
            opacity: 1;
        }

        99% {
            transform: scale(100, 100);
            z-index: 1;
            opacity: 0;
        }

        100% {
            transform: scale(1, 1);
            z-index: -1;
            opacity: 0;
        }
    }

    .cR8MNPkD {
        height: 95vh;
        min-height: 95vh;
        min-width: 740px;
        border: none;
        max-height: 95vh
    }

    @media screen and (max-width: 768px) {
        .cR8MNPkD {
            height:100%;
            min-height: 0;
            min-width: 100%;
            max-height: 100%;
            top: 0 !important;
            z-index: 45 !important
        }
    }

    .qgY5tuuJ {
        height: 100%;
        overflow-y: scroll;
        -webkit-overflow-scrolling: touch
    }

    .qgY5tuuJ .pJaRoAPM {
        padding-top: 60px
    }

    .qgY5tuuJ .khpMYLy3 {
        padding: 0 0 0 16px;
        text-align: left;
        width: 100%;
        color: #333333;
        border: 0;
        border-radius: 0
    }

    [dir="rtl"] .qgY5tuuJ .khpMYLy3 {
        padding-right: 16px;
        padding-left: 0;
        text-align: right
    }

    .qgY5tuuJ .khpMYLy3 .YpbxLf7i {
        display: flex;
        height: 80px;
        align-items: center
    }

    .qgY5tuuJ .khpMYLy3 .ZHHD_b9K {
        width: 60px;
        height: 60px;
        object-fit: cover;
        object-position: center;
        border-radius: 4px;
        margin-right: 16px
    }

    [dir="rtl"] .qgY5tuuJ .khpMYLy3 .ZHHD_b9K {
        margin-right: initial;
        margin-left: 16px
    }

    @media (min-width: 768px) {
        .qgY5tuuJ .khpMYLy3 .ZHHD_b9K {
            height:48px;
            width: 48px
        }
    }

    .qgY5tuuJ .khpMYLy3 .NACoqfGw {
        font-size: 14px;
        flex: 1;
        display: flex;
        align-items: center;
        border-bottom: 1px solid #f0f0f0;
        height: 80px;
        justify-content: space-between
    }

    .qgY5tuuJ .khpMYLy3 .NACoqfGw .QGXIbnE7 {
        font-size: 12px;
        color: #9e9e9e;
        margin-right: 24px
    }

    [dir="rtl"] .qgY5tuuJ .khpMYLy3 .NACoqfGw .QGXIbnE7 {
        margin-right: initial;
        margin-left: 24px
    }

    @media screen and (min-width: 768px) {
        .OwQlEgrx {
            box-shadow:none !important;
            border-bottom: 1px solid #f0f0f0 !important
        }
    }

    @use "sass:map";@use "sass:list";.IcSr2U56 {
        position: absolute;
        width: 100%;
        top: 0;
        left: 0;
        display: flex;
        align-items: center;
        box-shadow: 0 2px 4px 0 rgba(0,0,0,0.08);
        z-index: 4;
        background-color: #ffffff;
        color: #212121
    }

    [dir="rtl"] .IcSr2U56 {
        right: 0;
        left: initial
    }

    .IcSr2U56 .Zfl1utQQ {
        font-family: "ucglyphs" !important;
        font-size: 16px;
        line-height: 24px;
        background-position: center;
        transition: all 0.3s;
        padding: 16px
    }

    .IcSr2U56 .Zfl1utQQ:hover {
        background: #f5f5f5 radial-gradient(circle, transparent 1%, #eee 1%)
    }

    .IcSr2U56 .Zfl1utQQ:active {
        background-color: #fff;
        background-size: 100%;
        transition: background 0s
    }

    .IcSr2U56 .s3Lk1TUB {
        flex: 1;
        padding: 16px;
        padding-left: 0;
        font-size: 16px;
        line-height: 24px
    }

    [dir="rtl"] .IcSr2U56 .s3Lk1TUB {
        padding-right: 0;
        padding-left: 16px
    }

    .tHTfyMM3 {
        height: 100%;
        width: 100%;
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        overflow: hidden;
        border-radius: 8px
    }

    .LpwVvA6z {
        display: flex;
        height: 100%;
        width: 100%
    }

    .YY_uBy3w {
        position: absolute;
        bottom: 16px;
        width: 100%;
        height: 8px;
        z-index: 2;
        font-size: 10px
    }

    .H0pqXNPV,.twxH0NFg {
        position: absolute;
        height: 100%;
        width: 15%;
        z-index: 2
    }

    .H0pqXNPV {
        left: 0
    }

    .twxH0NFg {
        right: 0
    }

    .UDTXLd59 {
        display: flex
    }

    .W4WybuqR,.V7vUZ7TI,.G8M70ISY {
        position: relative;
        width: 7px;
        height: 7px;
        border-radius: 3.5px;
        background-color: #E5E5E5;
        margin: 0 2.5px;
        animation: xLsWg0fm 1.1s cubic-bezier(0.6, 0, 0.7, 1) infinite
    }

    .V7vUZ7TI {
        animation-delay: 0.113636s
    }

    .G8M70ISY {
        animation-delay: 0.227272s
    }

    @keyframes xLsWg0fm {
        0% {
            transform: translateY(0)
        }

        27.2727% {
            transform: translateY(-8px);
            animation-timing: cubic-bezier(0.3, 1, 0.4, 0)
        }

        50%,100% {
            transform: translateY(0)
        }
    }

    .np0B4N2u {
        width: 100%;
        height: 100%;
        background: #E4E4E4;
        animation: np0B4N2u 1s cubic-bezier(0.2, 0, 0.6, 1) infinite
    }

    @keyframes np0B4N2u {
        0% {
            background: #E4E4E4
        }

        50% {
            background: #F5F5F5
        }

        100% {
            background: #E4E4E4
        }
    }

    .vPKj7TVM {
        width: 100%;
        height: 100%;
        position: absolute;
        overflow: hidden
    }

    .t1Qt_D8S {
        position: absolute;
        top: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.4);
        backdrop-filter: blur(2px)
    }

    .erzIQpeB {
        background: rgba(0,0,0,0.3);
        position: absolute;
        bottom: 50%;
        right: 50%;
        transform: translate(50%, 50%);
        height: 48px;
        z-index: 10;
        width: 48px;
        border-radius: 50%;
        transition: all 0.1s ease;
        display: flex;
        padding: 8px
    }

    .uhoWkKDs {
        transform-origin: center center;
        object-fit: cover
    }

    .PMJaxbEb {
        width: 100%;
        object-fit: cover;
        height: 100%
    }

    .yrCDSzgx {
        position: relative;
        width: 100%;
        height: 100%
    }

    .Ios4PbZp {
        position: absolute;
        bottom: 15%;
        right: 5%;
        z-index: 10
    }

    .IFCrSXZL {
        padding: 0 12px;
        height: 100%;
        display: flex;
        z-index: 10
    }

    .pV7KdS4e {
        background-color: rgba(255,255,255,0.4);
        width: 100%;
        height: 8px;
        margin: 0 4px;
        border-radius: 4px;
        position: relative;
        overflow: hidden
    }

    .iI1FQ1lX {
        background-color: white;
        height: 100%;
        width: 100%;
        border-radius: 400px;
        transform: translateX(-100%)
    }

    .y5OIRbkR {
        background-color: white;
        height: 100%;
        width: 100%
    }

    .ecOXLOUS {
        height: 100%;
        width: 100%
    }

    .swBpBqff {
        pointer-events: none
    }

    .swBpBqff img {
        width: 35px;
        pointer-events: none
    }

    .swBpBqff .cN2R8iRA {
        width: 40px
    }

    .qLLnrTby {
        width: 100%;
        height: 100%;
        position: relative
    }

    .qLLnrTby .WC53EcV0 {
        height: 100%;
        width: 100%
    }

    .qLLnrTby .rele06Ng {
        position: absolute;
        bottom: 12px;
        right: 12px;
        width: 32px;
        height: 32px;
        box-shadow: 0 2px 4px 0 rgba(0,0,0,0.32);
        background-color: #ffffff;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px
    }

    .qLLnrTby .rele06Ng span {
        display: flex
    }

    .qLLnrTby .PuYioFoF {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(calc(-50% + 4px), calc(-50% - 12px))
    }

    .qw5WRWZF {
        position: absolute;
        top: 200%;
        left: 42%;
        transform: translate(calc(-50% + 4px), calc(-50% - 12px));
        background: #262626;
        border-radius: 8px;
        width: 184px;
        height: 52px;
        padding: 10px 16px
    }

    .qw5WRWZF:after {
        content: "";
        position: absolute;
        top: -7px;
        left: 92px;
        transform: translate(-50%, 0);
        width: 0;
        height: 0;
        border-left: 6px solid transparent;
        border-right: 6px solid transparent;
        border-bottom: 8px solid #212121
    }

    [dir="rtl"] .qw5WRWZF:after {
        left: initial;
        right: 0;
        transform: translate(50%, 0)
    }

    .Js1IlUos {
        color: #ffffff;
        font-weight: normal;
        font-size: 12px;
        line-height: 16px
    }

    .d55xH6Z8 {
        width: 36px;
        position: absolute;
        bottom: 5%;
        right: 5%;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 6px;
        background-color: white;
        border-radius: 100%
    }

    .IE4VPgCp {
        position: absolute;
        bottom: 8px;
        right: 8px;
        z-index: 10;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 8px 16px;
        margin-left: 0px;
        width: 96%;
        height: 48px;
        background: #FDF3F2;
        border: 1px solid #F9D9D7;
        border-radius: 8px
    }

    .IE4VPgCp .bk2yNaFL {
        font-weight: normal;
        font-size: 12px;
        line-height: 16px;
        text-align: center;
        color: #B32306
    }

    .dm2tF4k6 {
        height: 100%
    }

    .UPdzMG8M {
        height: 100%;
        width: 100%;
        border-radius: 8px;
        background-color: 'white';
        display: flex;
        border: 1px solid #E3E3E3
    }

    .xQoxORhi {
        height: 100%;
        width: 100%;
        border-radius: 8px;
        object-fit: cover
    }

    .WrrN7Hdj {
        height: 100%;
        width: 100%;
        border-radius: 8px;
        object-fit: cover
    }

    .O8bmdZic {
        height: 40%;
        width: 40%;
        align-self: center;
        margin: 0 auto
    }

    .QnB9ryEw {
        height: 50%;
        width: 50%;
        margin: auto;
        display: flex;
        flex-direction: column;
        align-items: center
    }

    .vaXTsBWb {
        font-size: 12px;
        font-weight: 600;
        text-align: center
    }

    .zceFeqmZ {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        width: 50px;
        height: 50px
    }

    .WKQxLG2e {
        width: 2rem;
        height: 2rem;
        background-color: #fff;
        margin: auto;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        border-radius: 50%
    }

    .SK7rj6tC {
        border-radius: inherit;
        background-image: conic-gradient(#fff, rgba(200,200,200,0.3), #646464);
        position: absolute;
        z-index: -1;
        margin: auto;
        top: -0.2rem;
        bottom: -0.2rem;
        left: -0.2rem;
        right: -0.2rem;
        animation: JVlyULam 0.6s linear infinite
    }

    @keyframes JVlyULam {
        0% {
            transform: rotate(0deg)
        }

        100% {
            transform: rotate(360deg)
        }
    }

    .jqfAJuuC {
        width: 100%;
        height: 100%
    }

    .HoOWFu8L {
        position: absolute;
        bottom: 8px;
        width: 100%;
        height: 8px;
        z-index: 2;
        font-size: 10px
    }

    .it8byAFr {
        position: relative;
        display: flex;
        height: 100%
    }

    .lM9KBmRr {
        position: absolute;
        top: 0;
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        background: rgba(0,0,0,0.4);
        backdrop-filter: blur(2px)
    }

    .jWfc_Fdk {
        width: 100%;
        height: 100%
    }

    .ComE6xXk {
        background: rgba(0,0,0,0.3);
        position: absolute;
        bottom: 50%;
        right: 50%;
        transform: translate(50%, 50%);
        height: 48px;
        z-index: 10;
        width: 48px;
        border-radius: 50%;
        transition: all 0.1s ease;
        display: flex;
        padding: 8px
    }
</style>
<style type="text/css" data-href="https://static.urbanclap.com/dist-product-webhttps://static.urbanclap.com/dist-product-web/client/CustomerAppReactNativeChunk-f3d791937120523d8d14.css" id="https://static.urbanclap.com/dist-product-web/client/CustomerAppReactNativeChunk-f3d791937120523d8d14.css">
    @font-face {
        font-family: 'rnfonts';
        src: url(https://static.urbanclap.com/dist-product-web/client/d449b5bca7543107ef82.eot);
        src: url(https://static.urbanclap.com/dist-product-web/client/d449b5bca7543107ef82.eot?#iefix) format('embedded-opentype'), url(https://static.urbanclap.com/dist-product-web/client/8092b18836f1afd098a6.woff2) format('woff2'), url(https://static.urbanclap.com/dist-product-web/client/b11ca1a200c6b3c10c01.woff) format('woff'), url(https://static.urbanclap.com/dist-product-web/client/9cf0a9be7ad19d0ec241.ttf) format('truetype'), url(https://static.urbanclap.com/dist-product-web/client/2e3a33f92edb03a597e9.svg?#rnfonts) format('svg');
        font-weight: normal;
        font-style: normal;
    }

    /* Chrome hack: SVG is rendered more smooth in Windozze. 100% magic, uncomment if you need it. */
    /* Note, that will break hinting! In other OS-es font will be not as sharp as it could be */
    /*
@media screen and (-webkit-min-device-pixel-ratio:0) {
  @font-face {
    font-family: 'rnfonts';
    src: url('../font/rnfonts.svg?84564923#rnfonts') format('svg');
  }
}
*/
    [class^="icon-"]:before, [class*=" icon-"]:before {
        font-family: "rnfonts";
        font-style: normal;
        font-weight: normal;
        speak: never;
        display: inline-block;
        text-decoration: inherit;
        width: 1em;
        margin-right: .2em;
        text-align: center;
        /* opacity: .8; */
        /* For safety - reset parent styles, that can break glyph codes*/
        font-variant: normal;
        text-transform: none;
        /* fix buttons height, for twitter bootstrap */
        line-height: 1em;
        /* Animation center compensation - margins should be symmetric */
        /* remove if not needed */
        margin-left: .2em;
        /* you can be more comfortable with increased icons size */
        /* font-size: 120%; */
        /* Font smoothing. That was taken from TWBS */
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        /* Uncomment for 3D effect */
        /* text-shadow: 1px 1px 1px rgba(127, 127, 127, 0.3); */
    }

    .icon-yoga-at-studio:before {
        content: '\e800';
    }

    /* '' */
    .icon-dog-trainer:before {
        content: '\e801';
    }

    /* '' */
    .icon-urbanclap-logo-new:before {
        content: '\e802';
    }

    /* '' */
    .icon-front-arrow-stemless-thin:before {
        content: '\e803';
    }

    /* '' */
    .icon-bollywood-dance-class:before {
        content: '\e804';
    }

    /* '' */
    .icon-contemporary-dance-class:before {
        content: '\e805';
    }

    /* '' */
    .icon-german:before {
        content: '\e806';
    }

    /* '' */
    .icon-french:before {
        content: '\e807';
    }

    /* '' */
    .icon-folk-dance-class:before {
        content: '\e808';
    }

    /* '' */
    .icon-family-photographer:before {
        content: '\e809';
    }

    /* '' */
    .icon-drum-classes:before {
        content: '\e80a';
    }

    /* '' */
    .icon-massage-at-home:before {
        content: '\e80b';
    }

    /* '' */
    .icon-hip-hop-dance-class:before {
        content: '\e80c';
    }

    /* '' */
    .icon-kathak-dance-class:before {
        content: '\e80d';
    }

    /* '' */
    .icon-online-dietician:before {
        content: '\e80e';
    }

    /* '' */
    .icon-maternity-photographers:before {
        content: '\e80f';
    }

    /* '' */
    .icon-party-caterers:before {
        content: '\e810';
    }

    /* '' */
    .icon-party-photographers:before {
        content: '\e811';
    }

    /* '' */
    .icon-pest-control:before {
        content: '\e812';
    }

    /* '' */
    .icon-physiotherapist:before {
        content: '\e813';
    }

    /* '' */
    .icon-plumbers:before {
        content: '\e814';
    }

    /* '' */
    .icon-pre-wedding-photographers:before {
        content: '\e815';
    }

    /* '' */
    .icon-salon-at-home:before {
        content: '\e816';
    }

    /* '' */
    .icon-valet-services:before {
        content: '\e817';
    }

    /* '' */
    .icon-wedding-photographers:before {
        content: '\e818';
    }

    /* '' */
    .icon-new-categories:before {
        content: '\e819';
    }

    /* '' */
    .icon-marketing-categories:before {
        content: '\e81a';
    }

    /* '' */
    .icon-piano-classes:before {
        content: '\e81b';
    }

    /* '' */
    .icon-tiffin-services:before {
        content: '\e81c';
    }

    /* '' */
    .icon-water-tanker-cleaner:before {
        content: '\e81d';
    }

    /* '' */
    .icon-wedding-caterer:before {
        content: '\e81e';
    }

    /* '' */
    .icon-zumba-dance-class:before {
        content: '\e81f';
    }

    /* '' */
    .icon-fitness-trainer:before {
        content: '\e820';
    }

    /* '' */
    .icon-guitar-lessons:before {
        content: '\e821';
    }

    /* '' */
    .icon-guitar-lessons-at-home:before {
        content: '\e822';
    }

    /* '' */
    .icon-interior-designers:before {
        content: '\e823';
    }

    /* '' */
    .icon-jazz-dance:before {
        content: '\e824';
    }

    /* '' */
    .icon-keyboard-lessons:before {
        content: '\e825';
    }

    /* '' */
    .icon-keyboard-lessons-at-home:before {
        content: '\e826';
    }

    /* '' */
    .icon-kitchen-cleaning:before {
        content: '\e827';
    }

    /* '' */
    .icon-laptop-repair:before {
        content: '\e828';
    }

    /* '' */
    .icon-laundry:before {
        content: '\e829';
    }

    /* '' */
    .icon-lawyers:before {
        content: '\e82a';
    }

    /* '' */
    .icon-make-up:before {
        content: '\e82b';
    }

    /* '' */
    .icon-mobile-repair:before {
        content: '\e82c';
    }

    /* '' */
    .icon-nutritionist:before {
        content: '\e82d';
    }

    /* '' */
    .icon-packers-and-movers:before {
        content: '\e82e';
    }

    /* '' */
    .icon-sofa-cleaners:before {
        content: '\e82f';
    }

    /* '' */
    .icon-weight-loss:before {
        content: '\e830';
    }

    /* '' */
    .icon-yoga-at-home:before {
        content: '\e831';
    }

    /* '' */
    .icon-ac-repair:before {
        content: '\e832';
    }

    /* '' */
    .icon-baby-kids-photographers:before {
        content: '\e833';
    }

    /* '' */
    .icon-bathroom-cleaning:before {
        content: '\e834';
    }

    /* '' */
    .icon-brithday-party-caterers:before {
        content: '\e835';
    }

    /* '' */
    .icon-carpet-cleaning:before {
        content: '\e836';
    }

    /* '' */
    .icon-corporate-party-caterers:before {
        content: '\e837';
    }

    /* '' */
    .icon-house-cleaning:before {
        content: '\e838';
    }

    /* '' */
    .icon-house-party-chef:before {
        content: '\e839';
    }

    /* '' */
    .icon-tick:before {
        content: '\e83a';
    }

    /* '' */
    .icon-calendar-date:before {
        content: '\e83b';
    }

    /* '' */
    .icon-current-location-ios:before {
        content: '\e83c';
    }

    /* '' */
    .icon-salsa:before {
        content: '\e83d';
    }

    /* '' */
    .icon-empty-chats:before {
        content: '\e83e';
    }

    /* '' */
    .icon-empty-requests:before {
        content: '\e83f';
    }

    /* '' */
    .icon-back-arrow-stemless:before {
        content: '\e840';
    }

    /* '' */
    .icon-ic-search:before {
        content: '\e841';
    }

    /* '' */
    .icon-check-box-tick-hollow:before {
        content: '\e842';
    }

    /* '' */
    .icon-checkbox-selected:before {
        content: '\e843';
    }

    /* '' */
    .icon-checkbox-unselected:before {
        content: '\e844';
    }

    /* '' */
    .icon-close-cross:before {
        content: '\e845';
    }

    /* '' */
    .icon-cross-in-circle:before {
        content: '\e846';
    }

    /* '' */
    .icon-edit-profile:before {
        content: '\e847';
    }

    /* '' */
    .icon-hired-professional-recent-history:before {
        content: '\e848';
    }

    /* '' */
    .icon-log-in:before {
        content: '\e849';
    }

    /* '' */
    .icon-log-out:before {
        content: '\e84a';
    }

    /* '' */
    .icon-phone-call:before {
        content: '\e84b';
    }

    /* '' */
    .icon-radio-button-selected:before {
        content: '\e84c';
    }

    /* '' */
    .icon-radio-button-unselected:before {
        content: '\e84d';
    }

    /* '' */
    .icon-share:before {
        content: '\e84e';
    }

    /* '' */
    .icon-tick-in-circle:before {
        content: '\e84f';
    }

    /* '' */
    .icon-apple-products-repair:before {
        content: '\e850';
    }

    /* '' */
    .icon-appliance-repair:before {
        content: '\e851';
    }

    /* '' */
    .icon-birthday-planner:before {
        content: '\e852';
    }

    /* '' */
    .icon-car-cleaning:before {
        content: '\e853';
    }

    /* '' */
    .icon-carpenters:before {
        content: '\e854';
    }

    /* '' */
    .icon-chartered-accountant:before {
        content: '\e855';
    }

    /* '' */
    .icon-dj:before {
        content: '\e856';
    }

    /* '' */
    .icon-drivers:before {
        content: '\e857';
    }

    /* '' */
    .icon-electricians:before {
        content: '\e858';
    }

    /* '' */
    .icon-event-planner:before {
        content: '\e859';
    }

    /* '' */
    .icon-search:before {
        content: '\e85a';
    }

    /* '' */
    .icon-empty-hired-professionals:before {
        content: '\e85b';
    }

    /* '' */
    .icon-uc-wordmark:before {
        content: '\e85c';
    }

    /* '' */
    .icon-facebook:before {
        content: '\e85d';
    }

    /* '' */
    .icon-onehalf:before {
        content: '\e85e';
    }

    /* '' */
    .icon-threequarters:before {
        content: '\e85f';
    }

    /* '' */
    .icon-questiondown:before {
        content: '\e860';
    }

    /* '' */
    .icon-Agrave:before {
        content: '\e861';
    }

    /* '' */
    .icon-Aacute:before {
        content: '\e862';
    }

    /* '' */
    .icon-Acircumflex:before {
        content: '\e863';
    }

    /* '' */
    .icon-Atilde:before {
        content: '\e864';
    }

    /* '' */
    .icon-Adieresis:before {
        content: '\e865';
    }

    /* '' */
    .icon-Aring:before {
        content: '\e866';
    }

    /* '' */
    .icon-AE:before {
        content: '\e867';
    }

    /* '' */
    .icon-Ccedilla:before {
        content: '\e868';
    }

    /* '' */
    .icon-Egrave:before {
        content: '\e869';
    }

    /* '' */
    .icon-Eacute:before {
        content: '\e86a';
    }

    /* '' */
    .icon-Ecircumflex:before {
        content: '\e86b';
    }

    /* '' */
    .icon-Edieresis:before {
        content: '\e86c';
    }

    /* '' */
    .icon-Igrave:before {
        content: '\e86d';
    }

    /* '' */
    .icon-Iacute:before {
        content: '\e86e';
    }

    /* '' */
    .icon-Icircumflex:before {
        content: '\e86f';
    }

    /* '' */
    .icon-Idieresis:before {
        content: '\e870';
    }

    /* '' */
    .icon-Eth:before {
        content: '\e871';
    }

    /* '' */
    .icon-Ntilde:before {
        content: '\e872';
    }

    /* '' */
    .icon-Oacute:before {
        content: '\e873';
    }

    /* '' */
    .icon-Ocircumflex:before {
        content: '\e874';
    }

    /* '' */
    .icon-Otilde:before {
        content: '\e875';
    }

    /* '' */
    .icon-Odieresis:before {
        content: '\e876';
    }

    /* '' */
    .icon-multiply:before {
        content: '\e877';
    }

    /* '' */
    .icon-Oslash:before {
        content: '\e878';
    }

    /* '' */
    .icon-Ugrave:before {
        content: '\e879';
    }

    /* '' */
    .icon-Uacute:before {
        content: '\e87a';
    }

    /* '' */
    .icon-Ucircumflex:before {
        content: '\e87b';
    }

    /* '' */
    .icon-Udieresis:before {
        content: '\e87c';
    }

    /* '' */
    .icon-Yacute:before {
        content: '\e87d';
    }

    /* '' */
    .icon-Thorn:before {
        content: '\e87e';
    }

    /* '' */
    .icon-germandbls:before {
        content: '\e87f';
    }

    /* '' */
    .icon-agrave:before {
        content: '\e880';
    }

    /* '' */
    .icon-aacute:before {
        content: '\e881';
    }

    /* '' */
    .icon-acircumflex:before {
        content: '\e882';
    }

    /* '' */
    .icon-atilde:before {
        content: '\e883';
    }

    /* '' */
    .icon-adieresis:before {
        content: '\e884';
    }

    /* '' */
    .icon-aring:before {
        content: '\e885';
    }

    /* '' */
    .icon-ae:before {
        content: '\e886';
    }

    /* '' */
    .icon-ccedilla:before {
        content: '\e887';
    }

    /* '' */
    .icon-egrave:before {
        content: '\e888';
    }

    /* '' */
    .icon-eacute:before {
        content: '\e889';
    }

    /* '' */
    .icon-ecircumflex:before {
        content: '\e88a';
    }

    /* '' */
    .icon-edieresis:before {
        content: '\e88b';
    }

    /* '' */
    .icon-igrave:before {
        content: '\e88c';
    }

    /* '' */
    .icon-iacute:before {
        content: '\e88d';
    }

    /* '' */
    .icon-icircumflex:before {
        content: '\e88e';
    }

    /* '' */
    .icon-idieresis:before {
        content: '\e88f';
    }

    /* '' */
    .icon-eth:before {
        content: '\e890';
    }

    /* '' */
    .icon-ntilde:before {
        content: '\e891';
    }

    /* '' */
    .icon-ograve:before {
        content: '\e892';
    }

    /* '' */
    .icon-oacute:before {
        content: '\e893';
    }

    /* '' */
    .icon-ocircumflex:before {
        content: '\e894';
    }

    /* '' */
    .icon-otilde:before {
        content: '\e895';
    }

    /* '' */
    .icon-odieresis:before {
        content: '\e896';
    }

    /* '' */
    .icon-divide:before {
        content: '\e897';
    }

    /* '' */
    .icon-oslash:before {
        content: '\e898';
    }

    /* '' */
    .icon-ugrave:before {
        content: '\e899';
    }

    /* '' */
    .icon-uacute:before {
        content: '\e89a';
    }

    /* '' */
    .icon-ucircumflex:before {
        content: '\e89b';
    }

    /* '' */
    .icon-udieresis:before {
        content: '\e89c';
    }

    /* '' */
    .icon-yacute:before {
        content: '\e89d';
    }

    /* '' */
    .icon-thorn:before {
        content: '\e89e';
    }

    /* '' */
    .icon-ydieresis:before {
        content: '\e89f';
    }

    /* '' */
    .icon-Amacron:before {
        content: '\e8a0';
    }

    /* '' */
    .icon-amacron:before {
        content: '\e8a1';
    }

    /* '' */
    .icon-Abreve:before {
        content: '\e8a2';
    }

    /* '' */
    .icon-abreve:before {
        content: '\e8a3';
    }

    /* '' */
    .icon-Aogonek:before {
        content: '\e8a4';
    }

    /* '' */
    .icon-aogonek:before {
        content: '\e8a5';
    }

    /* '' */
    .icon-Cacute:before {
        content: '\e8a6';
    }

    /* '' */
    .icon-cacute:before {
        content: '\e8a7';
    }

    /* '' */
    .icon-Ccircumflex:before {
        content: '\e8a8';
    }

    /* '' */
    .icon-ccircumflex:before {
        content: '\e8a9';
    }

    /* '' */
    .icon-Cdotaccent:before {
        content: '\e8aa';
    }

    /* '' */
    .icon-cdotaccent:before {
        content: '\e8ab';
    }

    /* '' */
    .icon-Ccaron:before {
        content: '\e8ac';
    }

    /* '' */
    .icon-ccaron:before {
        content: '\e8ad';
    }

    /* '' */
    .icon-Dcaron:before {
        content: '\e8ae';
    }

    /* '' */
    .icon-dcaron:before {
        content: '\e8af';
    }

    /* '' */
    .icon-Dcroat:before {
        content: '\e8b0';
    }

    /* '' */
    .icon-dcroat:before {
        content: '\e8b1';
    }

    /* '' */
    .icon-Emacron:before {
        content: '\e8b2';
    }

    /* '' */
    .icon-emacron:before {
        content: '\e8b3';
    }

    /* '' */
    .icon-Ebreve:before {
        content: '\e8b4';
    }

    /* '' */
    .icon-ebreve:before {
        content: '\e8b5';
    }

    /* '' */
    .icon-Edotaccent:before {
        content: '\e8b6';
    }

    /* '' */
    .icon-edotaccent:before {
        content: '\e8b7';
    }

    /* '' */
    .icon-Eogonek:before {
        content: '\e8b8';
    }

    /* '' */
    .icon-eogonek:before {
        content: '\e8b9';
    }

    /* '' */
    .icon-Ecaron:before {
        content: '\e8ba';
    }

    /* '' */
    .icon-ecaron:before {
        content: '\e8bb';
    }

    /* '' */
    .icon-Gcircumflex:before {
        content: '\e8bc';
    }

    /* '' */
    .icon-gcircumflex:before {
        content: '\e8bd';
    }

    /* '' */
    .icon-Gbreve:before {
        content: '\e8be';
    }

    /* '' */
    .icon-gbreve:before {
        content: '\e8bf';
    }

    /* '' */
    .icon-Gdotaccent:before {
        content: '\e8c0';
    }

    /* '' */
    .icon-gdotaccent:before {
        content: '\e8c1';
    }

    /* '' */
    .icon-uni0122:before {
        content: '\e8c2';
    }

    /* '' */
    .icon-uni0123:before {
        content: '\e8c3';
    }

    /* '' */
    .icon-Hcircumflex:before {
        content: '\e8c4';
    }

    /* '' */
    .icon-hcircumflex:before {
        content: '\e8c5';
    }

    /* '' */
    .icon-Hbar:before {
        content: '\e8c6';
    }

    /* '' */
    .icon-hbar:before {
        content: '\e8c7';
    }

    /* '' */
    .icon-Itilde:before {
        content: '\e8c8';
    }

    /* '' */
    .icon-itilde:before {
        content: '\e8c9';
    }

    /* '' */
    .icon-Imacron:before {
        content: '\e8ca';
    }

    /* '' */
    .icon-imacron:before {
        content: '\e8cb';
    }

    /* '' */
    .icon-Ibreve:before {
        content: '\e8cc';
    }

    /* '' */
    .icon-ibreve:before {
        content: '\e8cd';
    }

    /* '' */
    .icon-Iogonek:before {
        content: '\e8ce';
    }

    /* '' */
    .icon-iogonek:before {
        content: '\e8cf';
    }

    /* '' */
    .icon-Idotaccent:before {
        content: '\e8d0';
    }

    /* '' */
    .icon-dotlessi:before {
        content: '\e8d1';
    }

    /* '' */
    .icon-IJ:before {
        content: '\e8d2';
    }

    /* '' */
    .icon-ij:before {
        content: '\e8d3';
    }

    /* '' */
    .icon-Jcircumflex:before {
        content: '\e8d4';
    }

    /* '' */
    .icon-jcircumflex:before {
        content: '\e8d5';
    }

    /* '' */
    .icon-uni0136:before {
        content: '\e8d6';
    }

    /* '' */
    .icon-time-clock:before {
        content: '\e8d7';
    }

    /* '' */
    .icon-profile:before {
        content: '\e8d8';
    }

    /* '' */
    .icon-help-chat:before {
        content: '\e8d9';
    }

    /* '' */
    .icon-delete-trash-can:before {
        content: '\e8da';
    }

    /* '' */
    .icon-current-location-fill:before {
        content: '\e8db';
    }

    /* '' */
    .icon-lcoation-line:before {
        content: '\e8dc';
    }

    /* '' */
    .icon-microwave-repair:before {
        content: '\e8dd';
    }

    /* '' */
    .icon-painter:before {
        content: '\e8de';
    }

    /* '' */
    .icon-tv-repair:before {
        content: '\e8df';
    }

    /* '' */
    .icon-ro-water-purifier:before {
        content: '\e8e0';
    }

    /* '' */
    .icon-refridgerator-repair:before {
        content: '\e8e1';
    }

    /* '' */
    .icon-washing-machine-repair:before {
        content: '\e8e2';
    }

    /* '' */
    .icon-mehendi:before {
        content: '\e8e3';
    }

    /* '' */
    .icon-share-app-invite-friends:before {
        content: '\e8e4';
    }

    /* '' */
    .icon-geyser-repair:before {
        content: '\e8e5';
    }

    /* '' */
    .icon-cart-empty:before {
        content: '\e8e6';
    }

    /* '' */
    .icon-cart-full:before {
        content: '\e8e7';
    }

    /* '' */
    .icon-circle:before {
        content: '\e8e8';
    }

    /* '' */
    .icon-play-video:before {
        content: '\e8e9';
    }

    /* '' */
    .icon-accounts-tutors:before {
        content: '\e8ea';
    }

    /* '' */
    .icon-architect:before {
        content: '\e8eb';
    }

    /* '' */
    .icon-astrologer:before {
        content: '\e8ec';
    }

    /* '' */
    .icon-cctv-dealer:before {
        content: '\e8ed';
    }

    /* '' */
    .icon-couples-counselling:before {
        content: '\e8ee';
    }

    /* '' */
    .icon-economics-tutor:before {
        content: '\e8ef';
    }

    /* '' */
    .icon-english-tutors:before {
        content: '\e8f0';
    }

    /* '' */
    .icon-live-band:before {
        content: '\e8f1';
    }

    /* '' */
    .icon-math-tutor:before {
        content: '\e8f2';
    }

    /* '' */
    .icon-pan-card:before {
        content: '\e8f3';
    }

    /* '' */
    .icon-passport:before {
        content: '\e8f4';
    }

    /* '' */
    .icon-science-tutor:before {
        content: '\e8f5';
    }

    /* '' */
    .icon-wedding-cards-at-home:before {
        content: '\e8f6';
    }

    /* '' */
    .icon-web-development:before {
        content: '\e8f7';
    }

    /* '' */
    .icon-chat:before {
        content: '\e8f8';
    }

    /* '' */
    .icon-double-tick-ios:before {
        content: '\e8f9';
    }

    /* '' */
    .icon-cross-thick:before {
        content: '\e8fa';
    }

    /* '' */
    .icon-star:before {
        content: '\e8fb';
    }

    /* '' */
    .icon-wallet:before {
        content: '\e8fc';
    }

    /* '' */
    .icon-filter-line:before {
        content: '\e8fd';
    }

    /* '' */
    .icon-arrow-down-stemless:before {
        content: '\e8fe';
    }

    /* '' */
    .icon-arrow-left-stemless:before {
        content: '\e8ff';
    }

    /* '' */
    .icon-arrow-right-stemless:before {
        content: '\e900';
    }

    /* '' */
    .icon-arrow-up-stemless:before {
        content: '\e901';
    }

    /* '' */
    .icon-chat-1:before {
        content: '\e902';
    }

    /* '' */
    .icon-chat-line:before {
        content: '\e903';
    }

    /* '' */
    .icon-filter-applied:before {
        content: '\e904';
    }

    /* '' */
    .icon-filter-applied-fill:before {
        content: '\e905';
    }

    /* '' */
    .icon-filter-fill:before {
        content: '\e906';
    }

    /* '' */
    .icon-location-fill:before {
        content: '\e907';
    }

    /* '' */
    .icon-price-rupees:before {
        content: '\e908';
    }

    /* '' */
    .icon-pro:before {
        content: '\e909';
    }

    /* '' */
    .icon-pro-line:before {
        content: '\e90a';
    }

    /* '' */
    .icon-reply:before {
        content: '\e90b';
    }

    /* '' */
    .icon-reply-line:before {
        content: '\e90c';
    }

    /* '' */
    .icon-bartenders:before {
        content: '\e90d';
    }

    /* '' */
    .icon-chimmney-repair:before {
        content: '\e90e';
    }

    /* '' */
    .icon-construction-renovation:before {
        content: '\e90f';
    }

    /* '' */
    .icon-consumer-lawyer:before {
        content: '\e910';
    }

    /* '' */
    .icon-corporate-lawyer:before {
        content: '\e911';
    }

    /* '' */
    .icon-criminal-lawyer:before {
        content: '\e912';
    }

    /* '' */
    .icon-debt-lawyer:before {
        content: '\e913';
    }

    /* '' */
    .icon-doorstep-car-repair:before {
        content: '\e914';
    }

    /* '' */
    .icon-doorstep-two-wheeler-repair:before {
        content: '\e915';
    }

    /* '' */
    .icon-family-lawyer:before {
        content: '\e916';
    }

    /* '' */
    .icon-property-lawyer:before {
        content: '\e917';
    }

    /* '' */
    .icon-traffic-lawyer:before {
        content: '\e918';
    }

    /* '' */
    .icon-ups-inverter-repair:before {
        content: '\e919';
    }

    /* '' */
    .icon-arrow-right-stemless-circle:before {
        content: '\e91a';
    }

    /* '' */
    .icon-arrow-left-stemless-circle:before {
        content: '\e91b';
    }

    /* '' */
    .icon-video:before {
        content: '\e91c';
    }

    /* '' */
    .icon-chat-2:before {
        content: '\e91d';
    }

    /* '' */
    .icon-current-location-crosshair-android:before {
        content: '\e91e';
    }

    /* '' */
    .icon-menu-circles-android:before {
        content: '\e91f';
    }

    /* '' */
    .icon-back-arrow-stem-new:before {
        content: '\e920';
    }

    /* '' */
    .icon-arrow-forward-stem:before {
        content: '\e921';
    }

    /* '' */
    .icon-share-fill:before {
        content: '\e922';
    }

    /* '' */
    .icon-timeout:before {
        content: '\e923';
    }

    /* '' */
    .icon-holidays:before {
        content: '\e924';
    }

    /* '' */
    .icon-call-phone-droid2x:before {
        content: '\e925';
    }

    /* '' */
    .icon-message:before {
        content: '\e926';
    }

    /* '' */
    .icon-lock:before {
        content: '\e927';
    }

    /* '' */
    .icon-referral:before {
        content: '\e928';
    }

    /* '' */
    .icon-all-tutors:before {
        content: '\e929';
    }

    /* '' */
    .icon-more-ios:before {
        content: '\e92a';
    }

    /* '' */
    .icon-mehendi-henna:before {
        content: '\e92b';
    }

    /* '' */
    .icon-map-pin-location:before {
        content: '\e92c';
    }

    /* '' */
    .icon-share-fill-1:before {
        content: '\e92d';
    }

    /* '' */
    .icon-help-question:before {
        content: '\e92e';
    }

    /* '' */
    .icon-add:before {
        content: '\e92f';
    }

    /* '' */
    .icon-at-home:before {
        content: '\e930';
    }

    /* '' */
    .icon-best-brands:before {
        content: '\e931';
    }

    /* '' */
    .icon-alert:before {
        content: '\e932';
    }

    /* '' */
    .icon-all:before {
        content: '\e933';
    }

    /* '' */
    .icon-ask-query:before {
        content: '\e934';
    }

    /* '' */
    .icon-birthday-planner-1:before {
        content: '\e935';
    }

    /* '' */
    .icon-calender:before {
        content: '\e936';
    }

    /* '' */
    .icon-chat-3:before {
        content: '\e937';
    }

    /* '' */
    .icon-done:before {
        content: '\e938';
    }

    /* '' */
    .icon-dry-cleaning:before {
        content: '\e939';
    }

    /* '' */
    .icon-hide:before {
        content: '\e93a';
    }

    /* '' */
    .icon-hobbiesinterest:before {
        content: '\e93b';
    }

    /* '' */
    .icon-keyboard:before {
        content: '\e93c';
    }

    /* '' */
    .icon-location-pin:before {
        content: '\e93d';
    }

    /* '' */
    .icon-notification:before {
        content: '\e93e';
    }

    /* '' */
    .icon-plumber:before {
        content: '\e93f';
    }

    /* '' */
    .icon-price:before {
        content: '\e940';
    }

    /* '' */
    .icon-rating:before {
        content: '\e941';
    }

    /* '' */
    .icon-salon:before {
        content: '\e942';
    }

    /* '' */
    .icon-saved-chat:before {
        content: '\e943';
    }

    /* '' */
    .icon-selected:before {
        content: '\e944';
    }

    /* '' */
    .icon-show:before {
        content: '\e945';
    }

    /* '' */
    .icon-time:before {
        content: '\e946';
    }

    /* '' */
    .icon-yoga:before {
        content: '\e947';
    }

    /* '' */
    .icon-filter:before {
        content: '\e948';
    }

    /* '' */
    .icon-business-service:before {
        content: '\e949';
    }

    /* '' */
    .icon-hobbies:before {
        content: '\e94a';
    }

    /* '' */
    .icon-movers:before {
        content: '\e94b';
    }

    /* '' */
    .icon-paint:before {
        content: '\e94c';
    }

    /* '' */
    .icon-arrow-down:before {
        content: '\e94d';
    }

    /* '' */
    .icon-round-checkbox-1:before {
        content: '\e94e';
    }

    /* '' */
    .icon-round-checkbox-selected:before {
        content: '\e94f';
    }

    /* '' */
    .icon-share-1:before {
        content: '\e950';
    }

    /* '' */
    .icon-square-checkbox:before {
        content: '\e951';
    }

    /* '' */
    .icon-square-checkbox-selected:before {
        content: '\e952';
    }

    /* '' */
    .icon-arrow-up:before {
        content: '\e953';
    }

    /* '' */
    .icon-list:before {
        content: '\e954';
    }

    /* '' */
    .icon-best-match:before {
        content: '\e955';
    }

    /* '' */
    .icon-external-link:before {
        content: '\e956';
    }

    /* '' */
    .icon-morning:before {
        content: '\e957';
    }

    /* '' */
    .icon-male:before {
        content: '\e958';
    }

    /* '' */
    .icon-location-qna:before {
        content: '\e959';
    }

    /* '' */
    .icon-early-morning:before {
        content: '\e95a';
    }

    /* '' */
    .icon-evening:before {
        content: '\e95b';
    }

    /* '' */
    .icon-all-services:before {
        content: '\e95c';
    }

    /* '' */
    .icon-female:before {
        content: '\e95d';
    }

    /* '' */
    .icon-afternoon:before {
        content: '\e95e';
    }

    /* '' */
    .icon-divorcelawyer:before {
        content: '\e95f';
    }

    /* '' */
    .icon-digital-marketing:before {
        content: '\e960';
    }

    /* '' */
    .icon-foreign-currency-exchange:before {
        content: '\e961';
    }

    /* '' */
    .icon-iosandroid-developers:before {
        content: '\e962';
    }

    /* '' */
    .icon-recommended:before {
        content: '\e963';
    }

    /* '' */
    .icon-star-1:before {
        content: '\e964';
    }

    /* '' */
    .icon-express-cleaning:before {
        content: '\e965';
    }

    /* '' */
    .icon-become-a-pro:before {
        content: '\e966';
    }

    /* '' */
    .icon-messages:before {
        content: '\e967';
    }

    /* '' */
    .icon-chat-with-us:before {
        content: '\e968';
    }

    /* '' */
    .icon-call:before {
        content: '\e969';
    }

    /* '' */
    .icon-projects:before {
        content: '\e96a';
    }

    /* '' */
    .icon-rate:before {
        content: '\e96b';
    }

    /* '' */
    .icon-shoe-spa:before {
        content: '\e96c';
    }

    /* '' */
    .icon-wallet-1:before {
        content: '\e96d';
    }

    /* '' */
    .icon-share-earn:before {
        content: '\e96e';
    }

    /* '' */
    .icon-onboarding-arrow:before {
        content: '\e96f';
    }

    /* '' */
    .icon-fitness-trainer-1:before {
        content: '\e970';
    }

    /* '' */
    .icon-maid-service:before {
        content: '\e971';
    }

    /* '' */
    .icon-nurse-at-home:before {
        content: '\e972';
    }

    /* '' */
    .icon-insurance-agent:before {
        content: '\e973';
    }

    /* '' */
    .icon-health-checkup:before {
        content: '\e974';
    }

    /* '' */
    .icon-vastu:before {
        content: '\e975';
    }

    /* '' */
    .icon-add-image-ios:before {
        content: '\e976';
    }

    /* '' */
    .icon-single-tick-ios:before {
        content: '\e977';
    }

    /* '' */
    .icon-call-ios:before {
        content: '\e978';
    }

    /* '' */
    .icon-message-pro-ios:before {
        content: '\e979';
    }

    /* '' */
    .icon-pro-profile-video:before {
        content: '\e97a';
    }

    /* '' */
    .icon-listing-name-hover:before {
        content: '\e97b';
    }

    /* '' */
    .icon-clean-area:before {
        content: '\e97c';
    }

    /* '' */
    .icon-dry-time:before {
        content: '\e97d';
    }

    /* '' */
    .icon-dry-time-copy:before {
        content: '\e97e';
    }

    /* '' */
    .icon-duration:before {
        content: '\e97f';
    }

    /* '' */
    .icon-equipment:before {
        content: '\e980';
    }

    /* '' */
    .icon-pricing:before {
        content: '\e981';
    }

    /* '' */
    .icon-disposable:before {
        content: '\e982';
    }

    /* '' */
    .icon-service-guarantee:before {
        content: '\e983';
    }

    /* '' */
    .icon-team-size:before {
        content: '\e984';
    }

    /* '' */
    .icon-salon-equipment:before {
        content: '\e985';
    }

    /* '' */
    .icon-browse-pros:before {
        content: '\e986';
    }

    /* '' */
    .icon-match-pros:before {
        content: '\e987';
    }

    /* '' */
    .icon-review-pros:before {
        content: '\e988';
    }

    /* '' */
    .icon-schedule-call:before {
        content: '\e989';
    }

    /* '' */
    .icon-tell-requirements:before {
        content: '\e98a';
    }

    /* '' */
    .icon-cancel:before {
        content: '\e98b';
    }

    /* '' */
    .icon-reschedule:before {
        content: '\e98c';
    }

    /* '' */
    .icon-sent:before {
        content: '\e98d';
    }

    /* '' */
    .icon-swipe:before {
        content: '\e98e';
    }

    /* '' */
    .icon-vieworder:before {
        content: '\e98f';
    }

    /* '' */
    .icon-1:before {
        content: '\e990';
    }

    /* '' */
    .icon-2:before {
        content: '\e991';
    }

    /* '' */
    .icon-3:before {
        content: '\e992';
    }

    /* '' */
    .icon-4:before {
        content: '\e993';
    }

    /* '' */
    .icon-5:before {
        content: '\e994';
    }

    /* '' */
    .icon-wedding-makeup:before {
        content: '\e995';
    }

    /* '' */
    .icon-diwali-lights:before {
        content: '\e996';
    }

    /* '' */
    .icon-salon-1:before {
        content: '\e997';
    }

    /* '' */
    .icon-at-home-1:before {
        content: '\e998';
    }

    /* '' */
    .icon-salon-rebook:before {
        content: '\e999';
    }

    /* '' */
    .icon-addition:before {
        content: '\e99a';
    }

    /* '' */
    .icon-cart-filled:before {
        content: '\e99b';
    }

    /* '' */
    .icon-info:before {
        content: '\e99c';
    }

    /* '' */
    .icon-subtract:before {
        content: '\e99d';
    }

    /* '' */
    .icon-net-bank:before {
        content: '\e99e';
    }

    /* '' */
    .icon-saved-card:before {
        content: '\e99f';
    }

    /* '' */
    .icon-wallet-2:before {
        content: '\e9a0';
    }

    /* '' */
    .icon-planner-catering:before {
        content: '\e9a1';
    }

    /* '' */
    .icon-planner-decoration:before {
        content: '\e9a2';
    }

    /* '' */
    .icon-planner-entertainment:before {
        content: '\e9a3';
    }

    /* '' */
    .icon-planner-gift:before {
        content: '\e9a4';
    }

    /* '' */
    .icon-planner-photography:before {
        content: '\e9a5';
    }

    /* '' */
    .icon-planner-venue:before {
        content: '\e9a6';
    }

    /* '' */
    .icon-savemoney:before {
        content: '\e9a7';
    }

    /* '' */
    .icon-savetime:before {
        content: '\e9a8';
    }

    /* '' */
    .icon-card:before {
        content: '\e9a9';
    }

    /* '' */
    .icon-failure:before {
        content: '\e9aa';
    }

    /* '' */
    .icon-receipt:before {
        content: '\e9ab';
    }

    /* '' */
    .icon-success:before {
        content: '\e9ac';
    }

    /* '' */
    .icon-success-fill:before {
        content: '\e9ad';
    }

    /* '' */
    .icon-failure-fill:before {
        content: '\e9ae';
    }

    /* '' */
    .icon-construction:before {
        content: '\e9af';
    }

    /* '' */
    .icon-flooring:before {
        content: '\e9b0';
    }

    /* '' */
    .icon-glasswork:before {
        content: '\e9b1';
    }

    /* '' */
    .icon-masonry:before {
        content: '\e9b2';
    }

    /* '' */
    .icon-minorrepair:before {
        content: '\e9b3';
    }

    /* '' */
    .icon-pop:before {
        content: '\e9b4';
    }

    /* '' */
    .icon-renovation:before {
        content: '\e9b5';
    }

    /* '' */
    .icon-studyabroad:before {
        content: '\e9b6';
    }

    /* '' */
    .icon-waterproofing:before {
        content: '\e9b7';
    }

    /* '' */
    .icon-woodwork-furniture:before {
        content: '\e9b8';
    }

    /* '' */
    .icon-cash:before {
        content: '\e9b9';
    }

    /* '' */
    .icon-metal-fabrication:before {
        content: '\e9ba';
    }

    /* '' */
    .icon-verified-professionals:before {
        content: '\e9bb';
    }

    /* '' */
    .icon-info-1:before {
        content: '\e9bc';
    }

    /* '' */
    .icon-left-chevron:before {
        content: '\e9bd';
    }

    /* '' */
    .icon-left-right:before {
        content: '\e9be';
    }

    /* '' */
    .icon-star-filled:before {
        content: '\e9bf';
    }

    /* '' */
    .icon-star-empty:before {
        content: '\e9c0';
    }

    /* '' */
    .icon-next:before {
        content: '\e9c1';
    }

    /* '' */
    .icon-matched-pro:before {
        content: '\e9c2';
    }

    /* '' */
    .icon-location-dropdown:before {
        content: '\e9c3';
    }

    /* '' */
    .icon-location:before {
        content: '\e9c4';
    }

    /* '' */
    .icon-highquality:before {
        content: '\e9c5';
    }

    /* '' */
    .icon-hasslefree:before {
        content: '\e9c6';
    }

    /* '' */
    .icon-back:before {
        content: '\e9c7';
    }

    /* '' */
    .icon-beauty-health:before {
        content: '\e9c8';
    }

    /* '' */
    .icon-business-services:before {
        content: '\e9c9';
    }

    /* '' */
    .icon-events-weddings:before {
        content: '\e9ca';
    }

    /* '' */
    .icon-lessons-hobbies:before {
        content: '\e9cb';
    }

    /* '' */
    .icon-personal-more:before {
        content: '\e9cc';
    }

    /* '' */
    .icon-home-repair:before {
        content: '\e9cd';
    }

    /* '' */
    .icon-back-ios:before {
        content: '\e9ce';
    }

    /* '' */
    .icon-cross:before {
        content: '\e9cf';
    }

    /* '' */
    .icon-menu:before {
        content: '\e9d0';
    }

    /* '' */
    .icon-menu-1:before {
        content: '\e9d1';
    }

    /* '' */
    .icon-back-ios-1:before {
        content: '\e9d2';
    }

    /* '' */
    .icon-cross-1:before {
        content: '\e9d3';
    }

    /* '' */
    .icon-mail-profile:before {
        content: '\e9d4';
    }

    /* '' */
    .icon-fb-profile:before {
        content: '\e9d5';
    }

    /* '' */
    .icon-twitter-profile:before {
        content: '\e9d6';
    }

    /* '' */
    .icon-link-profile:before {
        content: '\e9d7';
    }

    /* '' */
    .icon-chat-2-1:before {
        content: '\e9d8';
    }

    /* '' */
    .icon-diet-list:before {
        content: '\e9d9';
    }

    /* '' */
    .icon-happiness:before {
        content: '\e9da';
    }

    /* '' */
    .icon-verified-1:before {
        content: '\e9db';
    }

    /* '' */
    .icon-link-profile-1:before {
        content: '\e9dc';
    }

    /* '' */
    .icon-cash-1:before {
        content: '\e9dd';
    }

    /* '' */
    .icon-cc-dc:before {
        content: '\e9de';
    }

    /* '' */
    .icon-coupons:before {
        content: '\e9df';
    }

    /* '' */
    .icon-info-3:before {
        content: '\e9e0';
    }

    /* '' */
    .icon-netbanking:before {
        content: '\e9e1';
    }

    /* '' */
    .icon-wallets:before {
        content: '\e9e2';
    }

    /* '' */
    .icon-paylater:before {
        content: '\e9e3';
    }

    /* '' */
    .icon-error:before {
        content: '\e9e4';
    }

    /* '' */
    .icon-info-2:before {
        content: '\e9e5';
    }

    /* '' */
    .icon-uc-logo:before {
        content: '\e9e6';
    }

    /* '' */
    .icon-facebook-1:before {
        content: '\e9e7';
    }

    /* '' */
</style>

    <!--section03-->
    <!---->
    <!---->
    <!---->
    <!---->
    <!---->
    <!---->
    <!---->
    <!---->
    <!---->
    <!---->


    

    <!--Mobi navbar-->
   
<section id="bottomBarNavbarContainer" class="BottomNavBar__bottomNavBarContainer--SA9zA noselect">
  <div class="BottomNavBar__equallySpacedContainer--QaIwA LinkComponent__isActive--u2tAc">
    <div class="b_e36c">
      <div onclick="location.href = '#';" class="LinkComponent__linkContainer--OJtY1">
        <span class="material-symbols-rounded LinkComponent__iconClass--ALESP">Home</span>
        <p class="LinkComponent__label--DmLP9">Home</p></div>
      <span class="b_g36c" style="top:-1px;left:-1px"></span>
    </div></div>
    <div onclick="location.href = '/final/booking/';" class="BottomNavBar__equallySpacedContainer--QaIwA ">
      <div class="b_e36c">
        
        <div onclick="location.href = '/final/booking/';" class="LinkComponent__linkContainer--OJtY1">
          <span class="material-symbols-rounded LinkComponent__iconClass--ALESP">assignment</span>
          <p class="LinkComponent__label--DmLP9">Booking</p></div>
          <span class="b_g36c" style="top:-1px;left:-1px"></span></div></div>
          <div class="BottomNavBar__equallySpacedContainer--QaIwA">
            <div class="b_e36c">

              <div onclick="location.href = '/helpcenter/';" class="LinkComponent__linkContainer--OJtY1">
                <span class="material-symbols-rounded LinkComponent__iconClass--ALESP">help</span>
                <p class="LinkComponent__label--DmLP9">Get Help</p></div>
                <span class="b_g36c" style="top:-1px;left:-1px"></span></div></div>
                <div class="BottomNavBar__equallySpacedContainer--QaIwA">
                  <div class="b_e36c">
                    <div onclick="location.href = 'profile.php';" class="LinkComponent__linkContainer--OJtY1">
                      <span class="material-symbols-rounded LinkComponent__iconClass--ALESP">account_circle</span>
                      <p class="LinkComponent__label--DmLP9">Profile</p></div>
                      <span class="b_g36c" style="top:-1px;left:-1px"></span></div></div>
                    </section>










    <!--JS LIST-->



    <!-- // Title text changer script-->
    <script src="./js/title.js"></script>
    <!--Image slider-->
    <script src="./js/image slider.js"></script>
</body>
</html>