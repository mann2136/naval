



// Title text changer
let titleText = ["Welcome to Man Navlakha", "M's Home Services", "M" , ];
let counter = 1;

setInterval(function() {
    document.title = titleText[ counter % titleText.length];
    counter++;
},2000
);